import { n as e, t } from "./rolldown-runtime-DtPi1Y-2.js";
import { t as n } from "./typeof-CcP5rTWg.js";
//#region node_modules/core-js/internals/global-this.js
var r = /* @__PURE__ */ t(((e, t) => {
	var n = function(e) {
		return e && e.Math === Math && e;
	};
	t.exports = n(typeof globalThis == "object" && globalThis) || n(typeof window == "object" && window) || n(typeof self == "object" && self) || n(typeof global == "object" && global) || n(typeof e == "object" && e) || (function() {
		return this;
	})() || Function("return this")();
})), i = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e) {
		try {
			return !!e();
		} catch {
			return !0;
		}
	};
})), a = /* @__PURE__ */ t(((e, t) => {
	t.exports = !i()(function() {
		return Object.defineProperty({}, 1, { get: function() {
			return 7;
		} })[1] !== 7;
	});
})), o = /* @__PURE__ */ t(((e, t) => {
	t.exports = !i()(function() {
		var e = function() {}.bind();
		return typeof e != "function" || e.hasOwnProperty("prototype");
	});
})), s = /* @__PURE__ */ t(((e, t) => {
	var n = o(), r = Function.prototype.call;
	t.exports = n ? r.bind(r) : function() {
		return r.apply(r, arguments);
	};
})), c = /* @__PURE__ */ t(((e) => {
	var t = {}.propertyIsEnumerable, n = Object.getOwnPropertyDescriptor;
	e.f = n && !t.call({ 1: 2 }, 1) ? function(e) {
		var t = n(this, e);
		return !!t && t.enumerable;
	} : t;
})), l = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e, t) {
		return {
			enumerable: !(e & 1),
			configurable: !(e & 2),
			writable: !(e & 4),
			value: t
		};
	};
})), u = /* @__PURE__ */ t(((e, t) => {
	var n = o(), r = Function.prototype, i = r.call, a = n && r.bind.bind(i, i);
	t.exports = n ? a : function(e) {
		return function() {
			return i.apply(e, arguments);
		};
	};
})), d = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = n({}.toString), i = n("".slice);
	t.exports = function(e) {
		return i(r(e), 8, -1);
	};
})), f = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = i(), a = d(), o = Object, s = n("".split);
	t.exports = r(function() {
		return !o("z").propertyIsEnumerable(0);
	}) ? function(e) {
		return a(e) === "String" ? s(e, "") : o(e);
	} : o;
})), p = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e) {
		return e == null;
	};
})), m = /* @__PURE__ */ t(((e, t) => {
	var n = p(), r = TypeError;
	t.exports = function(e) {
		if (n(e)) throw new r("Can't call method on " + e);
		return e;
	};
})), h = /* @__PURE__ */ t(((e, t) => {
	var n = f(), r = m();
	t.exports = function(e) {
		return n(r(e));
	};
})), g = /* @__PURE__ */ t(((e, t) => {
	var n = typeof document == "object" && document.all;
	t.exports = n === void 0 && n !== void 0 ? function(e) {
		return typeof e == "function" || e === n;
	} : function(e) {
		return typeof e == "function";
	};
})), _ = /* @__PURE__ */ t(((e, t) => {
	var n = g();
	t.exports = function(e) {
		return typeof e == "object" ? e !== null : n(e);
	};
})), v = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = g(), a = function(e) {
		return i(e) ? e : void 0;
	};
	t.exports = function(e, t) {
		return arguments.length < 2 ? a(n[e]) : n[e] && n[e][t];
	};
})), y = /* @__PURE__ */ t(((e, t) => {
	t.exports = u()({}.isPrototypeOf);
})), b = /* @__PURE__ */ t(((e, t) => {
	var n = r().navigator, i = n && n.userAgent;
	t.exports = i ? String(i) : "";
})), x = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = b(), a = n.process, o = n.Deno, s = a && a.versions || o && o.version, c = s && s.v8, l, u;
	c && (l = c.split("."), u = l[0] > 0 && l[0] < 4 ? 1 : +(l[0] + l[1])), !u && i && (l = i.match(/Edge\/(\d+)/), (!l || l[1] >= 74) && (l = i.match(/Chrome\/(\d+)/), l && (u = +l[1]))), t.exports = u;
})), S = /* @__PURE__ */ t(((e, t) => {
	var n = x(), a = i(), o = r().String;
	t.exports = !!Object.getOwnPropertySymbols && !a(function() {
		var e = Symbol("symbol detection");
		return !o(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && n && n < 41;
	});
})), C = /* @__PURE__ */ t(((e, t) => {
	t.exports = S() && !Symbol.sham && typeof Symbol.iterator == "symbol";
})), w = /* @__PURE__ */ t(((e, t) => {
	var n = v(), r = g(), i = y(), a = C(), o = Object;
	t.exports = a ? function(e) {
		return typeof e == "symbol";
	} : function(e) {
		var t = n("Symbol");
		return r(t) && i(t.prototype, o(e));
	};
})), T = /* @__PURE__ */ t(((e, t) => {
	var n = String;
	t.exports = function(e) {
		try {
			return n(e);
		} catch {
			return "Object";
		}
	};
})), E = /* @__PURE__ */ t(((e, t) => {
	var n = g(), r = T(), i = TypeError;
	t.exports = function(e) {
		if (n(e)) return e;
		throw new i(r(e) + " is not a function");
	};
})), D = /* @__PURE__ */ t(((e, t) => {
	var n = E(), r = p();
	t.exports = function(e, t) {
		var i = e[t];
		return r(i) ? void 0 : n(i);
	};
})), O = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = g(), i = _(), a = TypeError;
	t.exports = function(e, t) {
		var o, s;
		if (t === "string" && r(o = e.toString) && !i(s = n(o, e)) || r(o = e.valueOf) && !i(s = n(o, e)) || t !== "string" && r(o = e.toString) && !i(s = n(o, e))) return s;
		throw new a("Can't convert object to primitive value");
	};
})), k = /* @__PURE__ */ t(((e, t) => {
	t.exports = !1;
})), A = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = Object.defineProperty;
	t.exports = function(e, t) {
		try {
			i(n, e, {
				value: t,
				configurable: !0,
				writable: !0
			});
		} catch {
			n[e] = t;
		}
		return t;
	};
})), j = /* @__PURE__ */ t(((e, t) => {
	var n = k(), i = r(), a = A(), o = "__core-js_shared__", s = t.exports = i[o] || a(o, {});
	(s.versions ||= []).push({
		version: "3.50.0",
		mode: n ? "pure" : "global",
		copyright: "© 2013–2025 Denis Pushkarev (zloirock.ru), 2025–2026 CoreJS Company (core-js.io). All rights reserved.",
		license: "https://github.com/zloirock/core-js/blob/v3.50.0/LICENSE",
		source: "https://github.com/zloirock/core-js"
	});
})), M = /* @__PURE__ */ t(((e, t) => {
	var n = j(), r = Object.create || Object;
	t.exports = function(e, t) {
		return n[e] || (n[e] = t || r(null));
	};
})), N = /* @__PURE__ */ t(((e, t) => {
	var n = m(), r = Object;
	t.exports = function(e) {
		return r(n(e));
	};
})), P = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = N(), i = n({}.hasOwnProperty);
	t.exports = Object.hasOwn || function(e, t) {
		return i(r(e), t);
	};
})), F = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = 0, i = Math.random(), a = n(1.1.toString);
	t.exports = function(e) {
		return "Symbol(" + (e === void 0 ? "" : e) + ")_" + a(++r + i, 36);
	};
})), I = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = M(), a = P(), o = F(), s = S(), c = C(), l = n.Symbol, u = i("wks"), d = c ? l.for || l : l && l.withoutSetter || o;
	t.exports = function(e) {
		return a(u, e) || (u[e] = s && a(l, e) ? l[e] : d("Symbol." + e)), u[e];
	};
})), L = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = _(), i = w(), a = D(), o = O(), c = I(), l = TypeError, u = c("toPrimitive");
	t.exports = function(e, t) {
		if (!r(e) || i(e)) return e;
		var s = a(e, u), c;
		if (s) {
			if (t === void 0 && (t = "default"), c = n(s, e, t), !r(c) || i(c)) return c;
			throw new l("Can't convert object to primitive value");
		}
		return t === void 0 && (t = "number"), o(e, t);
	};
})), R = /* @__PURE__ */ t(((e, t) => {
	var n = L(), r = w();
	t.exports = function(e) {
		var t = n(e, "string");
		return r(t) ? t : t + "";
	};
})), z = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = _(), a = n.document, o = i(a) && i(a.createElement);
	t.exports = function(e) {
		return o ? a.createElement(e) : {};
	};
})), ee = /* @__PURE__ */ t(((e, t) => {
	var n = a(), r = i(), o = z();
	t.exports = !n && !r(function() {
		return Object.defineProperty(o("div"), "a", { get: function() {
			return 7;
		} }).a !== 7;
	});
})), te = /* @__PURE__ */ t(((e) => {
	var t = a(), n = s(), r = c(), i = l(), o = h(), u = R(), d = P(), f = ee(), p = Object.getOwnPropertyDescriptor;
	e.f = t ? p : function(e, t) {
		if (e = o(e), t = u(t), f) try {
			return p(e, t);
		} catch {}
		if (d(e, t)) return i(!n(r.f, e, t), e[t]);
	};
})), ne = /* @__PURE__ */ t(((e, t) => {
	var n = a(), r = i();
	t.exports = n && r(function() {
		return Object.defineProperty(function() {}, "prototype", {
			value: 42,
			writable: !1
		}).prototype !== 42;
	});
})), B = /* @__PURE__ */ t(((e, t) => {
	var n = _(), r = String, i = TypeError;
	t.exports = function(e) {
		if (n(e)) return e;
		throw new i(r(e) + " is not an object");
	};
})), re = /* @__PURE__ */ t(((e) => {
	var t = a(), n = ee(), r = ne(), i = B(), o = R(), s = TypeError, c = Object.defineProperty, l = Object.getOwnPropertyDescriptor, u = "enumerable", d = "configurable", f = "writable";
	e.f = t ? r ? function(e, t, n) {
		if (i(e), t = o(t), i(n), typeof e == "function" && t === "prototype" && "value" in n && f in n && !n[f]) {
			var r = l(e, t);
			r && r[f] && (e[t] = n.value, n = {
				configurable: d in n ? n[d] : r[d],
				enumerable: u in n ? n[u] : r[u],
				writable: !1
			});
		}
		return c(e, t, n);
	} : c : function(e, t, r) {
		if (i(e), t = o(t), i(r), n) try {
			return c(e, t, r);
		} catch {}
		if ("get" in r || "set" in r) throw new s("Accessors not supported");
		return "value" in r && (e[t] = r.value), e;
	};
})), ie = /* @__PURE__ */ t(((e, t) => {
	var n = a(), r = re(), i = l();
	t.exports = n ? function(e, t, n) {
		return r.f(e, t, i(1, n));
	} : function(e, t, n) {
		return e[t] = n, e;
	};
})), ae = /* @__PURE__ */ t(((e, t) => {
	var n = a(), r = P(), i = Function.prototype, o = n && Object.getOwnPropertyDescriptor, s = r(i, "name");
	t.exports = {
		EXISTS: s,
		PROPER: s && function() {}.name === "something",
		CONFIGURABLE: s && (!n || n && o(i, "name").configurable)
	};
})), oe = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = g(), i = j(), a = n(Function.toString);
	r(i.inspectSource) || (i.inspectSource = function(e) {
		return a(e);
	}), t.exports = i.inspectSource;
})), se = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = g(), a = n.WeakMap;
	t.exports = i(a) && /native code/.test(String(a));
})), ce = /* @__PURE__ */ t(((e, t) => {
	var n = M(), r = F(), i = n("keys");
	t.exports = function(e) {
		return i[e] || (i[e] = r(e));
	};
})), le = /* @__PURE__ */ t(((e, t) => {
	t.exports = {};
})), ue = /* @__PURE__ */ t(((e, t) => {
	var n = se(), i = r(), a = _(), o = ie(), s = P(), c = j(), l = ce(), u = le(), d = "Object already initialized", f = i.TypeError, p = i.WeakMap, m, h, g, v = function(e) {
		return g(e) ? h(e) : m(e, {});
	}, y = function(e) {
		return function(t) {
			var n;
			if (!a(t) || (n = h(t)).type !== e) throw new f("Incompatible receiver, " + e + " required");
			return n;
		};
	};
	if (n || c.state) {
		var b = c.state ||= new p();
		b.get = b.get, b.has = b.has, b.set = b.set, m = function(e, t) {
			if (b.has(e)) throw new f(d);
			return t.facade = e, b.set(e, t), t;
		}, h = function(e) {
			return b.get(e) || {};
		}, g = function(e) {
			return b.has(e);
		};
	} else {
		var x = l("state");
		u[x] = !0, m = function(e, t) {
			if (s(e, x)) throw new f(d);
			return t.facade = e, o(e, x, t), t;
		}, h = function(e) {
			return s(e, x) ? e[x] : {};
		}, g = function(e) {
			return s(e, x);
		};
	}
	t.exports = {
		set: m,
		get: h,
		has: g,
		enforce: v,
		getterFor: y
	};
})), de = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = i(), o = g(), s = P(), c = a(), l = ae().CONFIGURABLE, d = oe(), f = ue(), p = f.enforce, m = f.get, h = String, _ = Object.defineProperty, v = n("".slice), y = n("".replace), b = n([].join), x = c && !r(function() {
		return _(function() {}, "length", { value: 8 }).length !== 8;
	}), S = String(String).split("String"), C = t.exports = function(e, t, n) {
		v(h(t), 0, 7) === "Symbol(" && (t = "[" + y(h(t), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), n && n.getter && (t = "get " + t), n && n.setter && (t = "set " + t), (!s(e, "name") || l && e.name !== t) && (c ? _(e, "name", {
			value: t,
			configurable: !0
		}) : e.name = t), x && n && s(n, "arity") && e.length !== n.arity && _(e, "length", { value: n.arity });
		try {
			n && s(n, "constructor") && n.constructor ? c && _(e, "prototype", { writable: !1 }) : e.prototype &&= void 0;
		} catch {}
		var r = p(e);
		return s(r, "source") || (r.source = b(S, typeof t == "string" ? t : "")), e;
	};
	Function.prototype.toString = C(function() {
		return o(this) && m(this).source || d(this);
	}, "toString");
})), fe = /* @__PURE__ */ t(((e, t) => {
	var n = g(), r = re(), i = de(), a = A();
	t.exports = function(e, t, o, s) {
		s ||= {};
		var c = s.enumerable, l = s.name === void 0 ? t : s.name;
		if (n(o) && i(o, l, s), s.global) c ? e[t] = o : a(t, o);
		else {
			try {
				s.unsafe ? e[t] && (c = !0) : delete e[t];
			} catch {}
			c ? e[t] = o : r.f(e, t, {
				value: o,
				enumerable: !1,
				configurable: !s.nonConfigurable,
				writable: !s.nonWritable
			});
		}
		return e;
	};
})), pe = /* @__PURE__ */ t(((e, t) => {
	var n = Math.ceil, r = Math.floor;
	t.exports = Math.trunc || function(e) {
		var t = +e;
		return (t > 0 ? r : n)(t);
	};
})), me = /* @__PURE__ */ t(((e, t) => {
	var n = pe();
	t.exports = function(e) {
		var t = +e;
		return t !== t || t === 0 ? 0 : n(t);
	};
})), he = /* @__PURE__ */ t(((e, t) => {
	var n = me(), r = Math.max, i = Math.min;
	t.exports = function(e, t) {
		var a = n(e);
		return a < 0 ? r(a + t, 0) : i(a, t);
	};
})), V = /* @__PURE__ */ t(((e, t) => {
	var n = me(), r = Math.min;
	t.exports = function(e) {
		var t = n(e);
		return t > 0 ? r(t, 9007199254740991) : 0;
	};
})), ge = /* @__PURE__ */ t(((e, t) => {
	var n = V();
	t.exports = function(e) {
		return n(e.length);
	};
})), _e = /* @__PURE__ */ t(((e, t) => {
	var n = h(), r = he(), i = ge(), a = function(e) {
		return function(t, a, o) {
			var s = n(t), c = i(s);
			if (c === 0) return !e && -1;
			var l = r(o, c), u;
			if (e && a !== a) {
				for (; c > l;) if (u = s[l++], u !== u) return !0;
			} else for (; c > l; l++) if ((e || l in s) && s[l] === a) return e || l || 0;
			return !e && -1;
		};
	};
	t.exports = {
		includes: a(!0),
		indexOf: a(!1)
	};
})), H = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = P(), i = h(), a = _e().indexOf, o = le(), s = n([].push);
	t.exports = function(e, t) {
		var n = i(e), c = 0, l = [], u;
		for (u in n) !r(o, u) && r(n, u) && s(l, u);
		for (; t.length > c;) r(n, u = t[c++]) && (~a(l, u) || s(l, u));
		return l;
	};
})), ve = /* @__PURE__ */ t(((e, t) => {
	t.exports = [
		"constructor",
		"hasOwnProperty",
		"isPrototypeOf",
		"propertyIsEnumerable",
		"toLocaleString",
		"toString",
		"valueOf"
	];
})), ye = /* @__PURE__ */ t(((e) => {
	var t = H(), n = ve().concat("length", "prototype");
	e.f = Object.getOwnPropertyNames || function(e) {
		return t(e, n);
	};
})), be = /* @__PURE__ */ t(((e) => {
	e.f = Object.getOwnPropertySymbols;
})), xe = /* @__PURE__ */ t(((e, t) => {
	var n = v(), r = u(), i = ye(), a = be(), o = B(), s = r([].concat);
	t.exports = n("Reflect", "ownKeys") || function(e) {
		var t = i.f(o(e)), n = a.f;
		return n ? s(t, n(e)) : t;
	};
})), Se = /* @__PURE__ */ t(((e, t) => {
	var n = P(), r = xe(), i = te(), a = re();
	t.exports = function(e, t, o) {
		for (var s = r(t), c = a.f, l = i.f, u = 0; u < s.length; u++) {
			var d = s[u];
			!n(e, d) && !(o && n(o, d)) && c(e, d, l(t, d));
		}
	};
})), Ce = /* @__PURE__ */ t(((e, t) => {
	var n = i(), r = g(), a = /#|\.prototype\./, o = function(e, t) {
		var i = c[s(e)];
		return i === u ? !0 : i === l ? !1 : r(t) ? n(t) : !!t;
	}, s = o.normalize = function(e) {
		return String(e).replace(a, ".").toLowerCase();
	}, c = o.data = {}, l = o.NATIVE = "N", u = o.POLYFILL = "P";
	t.exports = o;
})), U = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = te().f, a = ie(), o = fe(), s = A(), c = Se(), l = Ce();
	t.exports = function(e, t) {
		var r = e.target, u = e.global, d = e.stat, f, p = u ? n : d ? n[r] || s(r, {}) : n[r] && n[r].prototype, m, h, g, _;
		if (p) for (m in t) {
			if (g = t[m], e.dontCallGetSet ? (_ = i(p, m), h = _ && _.value) : h = p[m], f = l(u ? m : r + (d ? "." : "#") + m, e.forced), !f && h !== void 0) {
				if (typeof g == typeof h) continue;
				c(g, h);
			}
			(e.sham || h && h.sham) && a(g, "sham", !0), o(p, m, g, e);
		}
	};
})), we = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = b(), a = d(), o = function(e) {
		return i.slice(0, e.length) === e;
	};
	t.exports = (function() {
		return o("Bun/") ? "BUN" : o("Cloudflare-Workers") ? "CLOUDFLARE" : o("Deno/") ? "DENO" : o("Node.js/") ? "NODE" : n.Bun && typeof Bun.version == "string" ? "BUN" : n.Deno && typeof Deno.version == "object" ? "DENO" : a(n.process) === "process" ? "NODE" : n.window && n.document ? "BROWSER" : "REST";
	})();
})), Te = /* @__PURE__ */ t(((e, t) => {
	t.exports = we() === "NODE";
})), Ee = /* @__PURE__ */ t(((e, t) => {
	t.exports = r();
})), De = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = E();
	t.exports = function(e, t, i) {
		try {
			return n(r(Object.getOwnPropertyDescriptor(e, t)[i]));
		} catch {}
	};
})), Oe = /* @__PURE__ */ t(((e, t) => {
	var n = _();
	t.exports = function(e) {
		return n(e) || e === null;
	};
})), ke = /* @__PURE__ */ t(((e, t) => {
	var n = Oe(), r = String, i = TypeError;
	t.exports = function(e) {
		if (n(e)) return e;
		throw new i("Can't set " + r(e) + " as a prototype");
	};
})), Ae = /* @__PURE__ */ t(((e, t) => {
	var n = De(), r = _(), i = m(), a = ke();
	t.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
		var e = !1, t = {}, o;
		try {
			o = n(Object.prototype, "__proto__", "set"), o(t, []), e = t instanceof Array;
		} catch {}
		return function(t, n) {
			return i(t), a(n), r(t) && (e ? o(t, n) : t.__proto__ = n), t;
		};
	}() : void 0);
})), je = /* @__PURE__ */ t(((e, t) => {
	var n = re().f, r = P(), i = I()("toStringTag");
	t.exports = function(e, t, a) {
		e && !a && (e = e.prototype), e && !r(e, i) && n(e, i, {
			configurable: !0,
			value: t
		});
	};
})), Me = /* @__PURE__ */ t(((e, t) => {
	var n = de(), r = re();
	t.exports = function(e, t, i) {
		return i.get && n(i.get, t, { getter: !0 }), i.set && n(i.set, t, { setter: !0 }), r.f(e, t, i);
	};
})), Ne = /* @__PURE__ */ t(((e, t) => {
	var n = v(), r = Me(), i = I(), o = a(), s = i("species");
	t.exports = function(e) {
		var t = n(e);
		o && t && !t[s] && r(t, s, {
			configurable: !0,
			get: function() {
				return this;
			}
		});
	};
})), W = /* @__PURE__ */ t(((e, t) => {
	var n = y(), r = TypeError;
	t.exports = function(e, t) {
		if (n(t, e)) return e;
		throw new r("Incorrect invocation");
	};
})), Pe = /* @__PURE__ */ t(((e, t) => {
	var n = I()("toStringTag"), r = {};
	r[n] = "z", t.exports = String(r) === "[object z]";
})), Fe = /* @__PURE__ */ t(((e, t) => {
	var n = Pe(), r = g(), i = d(), a = I()("toStringTag"), o = Object, s = i(function() {
		return arguments;
	}()) === "Arguments", c = function(e, t) {
		try {
			return e[t];
		} catch {}
	};
	t.exports = n ? i : function(e) {
		var t, n, l;
		return e === void 0 ? "Undefined" : e === null ? "Null" : typeof (n = c(t = o(e), a)) == "string" ? n : s ? i(t) : (l = i(t)) === "Object" && r(t.callee) ? "Arguments" : l;
	};
})), Ie = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = i(), a = g(), o = Fe(), s = v(), c = oe(), l = function() {}, d = s("Reflect", "construct"), f = /^\s*(?:class|function)\b/, p = n(f.exec), m = !f.test(l), h = function(e) {
		if (!a(e)) return !1;
		try {
			return d(l, [], e), !0;
		} catch {
			return !1;
		}
	}, _ = function(e) {
		if (!a(e)) return !1;
		switch (o(e)) {
			case "AsyncFunction":
			case "GeneratorFunction":
			case "AsyncGeneratorFunction": return !1;
		}
		try {
			return m || !!p(f, c(e));
		} catch {
			return !0;
		}
	};
	_.sham = !0, t.exports = !d || r(function() {
		var e;
		return h(h.call) || !h(Object) || !h(function() {
			e = !0;
		}) || e;
	}) ? _ : h;
})), Le = /* @__PURE__ */ t(((e, t) => {
	var n = Ie(), r = T(), i = TypeError;
	t.exports = function(e) {
		if (n(e)) return e;
		throw new i(r(e) + " is not a constructor");
	};
})), Re = /* @__PURE__ */ t(((e, t) => {
	var n = B(), r = Le(), i = p(), a = I()("species");
	t.exports = function(e, t) {
		var o = n(e).constructor, s;
		return o === void 0 || i(s = n(o)[a]) ? t : r(s);
	};
})), ze = /* @__PURE__ */ t(((e, t) => {
	var n = o(), r = Function.prototype, i = r.apply, a = r.call;
	t.exports = typeof Reflect == "object" && Reflect.apply || (n ? a.bind(i) : function() {
		return a.apply(i, arguments);
	});
})), Be = /* @__PURE__ */ t(((e, t) => {
	var n = d(), r = u();
	t.exports = function(e) {
		if (n(e) === "Function") return r(e);
	};
})), Ve = /* @__PURE__ */ t(((e, t) => {
	var n = Be(), r = E(), i = o(), a = n(n.bind);
	t.exports = function(e, t) {
		return r(e), t === void 0 ? e : i ? a(e, t) : function() {
			return e.apply(t, arguments);
		};
	};
})), He = /* @__PURE__ */ t(((e, t) => {
	t.exports = v()("document", "documentElement");
})), Ue = /* @__PURE__ */ t(((e, t) => {
	t.exports = u()([].slice);
})), We = /* @__PURE__ */ t(((e, t) => {
	var n = TypeError;
	t.exports = function(e, t) {
		if (e < t) throw new n("Not enough arguments");
		return e;
	};
})), Ge = /* @__PURE__ */ t(((e, t) => {
	var n = b();
	t.exports = /ipad|iphone|ipod/i.test(n) && /applewebkit/i.test(n);
})), Ke = /* @__PURE__ */ t(((e, t) => {
	var n = r(), a = ze(), o = Ve(), s = g(), c = P(), l = i(), u = He(), d = Ue(), f = z(), p = We(), m = Ge(), h = Te(), _ = n.setImmediate, v = n.clearImmediate, y = n.process, b = n.Dispatch, x = n.Function, S = n.MessageChannel, C = n.String, w = 0, T = {}, E = "onreadystatechange", D, O, k, A;
	l(function() {
		D = n.location;
	});
	var j = function(e) {
		if (c(T, e)) {
			var t = T[e];
			delete T[e], t();
		}
	}, M = function(e) {
		return function() {
			j(e);
		};
	}, N = function(e) {
		j(e.data);
	}, F = function(e) {
		n.postMessage(C(e), D.protocol + "//" + D.host);
	};
	(!_ || !v) && (_ = function(e) {
		p(arguments.length, 1);
		var t = s(e) ? e : x(e), n = d(arguments, 1);
		return T[++w] = function() {
			a(t, void 0, n);
		}, O(w), w;
	}, v = function(e) {
		delete T[e];
	}, h ? O = function(e) {
		y.nextTick(M(e));
	} : b && b.now ? O = function(e) {
		b.now(M(e));
	} : S && !m ? (k = new S(), A = k.port2, k.port1.onmessage = N, O = o(A.postMessage, A)) : n.addEventListener && s(n.postMessage) && !n.importScripts && D && D.protocol !== "file:" && !l(F) ? (O = F, n.addEventListener("message", N, !1)) : O = E in f("script") ? function(e) {
		u.appendChild(f("script"))[E] = function() {
			u.removeChild(this), j(e);
		};
	} : function(e) {
		setTimeout(M(e), 0);
	}), t.exports = {
		set: _,
		clear: v
	};
})), qe = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = a(), o = Object.getOwnPropertyDescriptor;
	t.exports = function(e) {
		if (!i) return n[e];
		var t = o(n, e);
		return t && t.value;
	};
})), Je = /* @__PURE__ */ t(((e, t) => {
	var n = function() {
		this.head = null, this.tail = null;
	};
	n.prototype = {
		add: function(e) {
			var t = {
				item: e,
				next: null
			}, n = this.tail;
			n ? n.next = t : this.head = t, this.tail = t;
		},
		get: function() {
			var e = this.head;
			if (e) return (this.head = e.next) === null && (this.tail = null), e.item;
		}
	}, t.exports = n;
})), Ye = /* @__PURE__ */ t(((e, t) => {
	var n = b();
	t.exports = /ipad|iphone|ipod/i.test(n) && typeof Pebble < "u";
})), Xe = /* @__PURE__ */ t(((e, t) => {
	var n = b();
	t.exports = /web0s(?!.*chrome)/i.test(n);
})), Ze = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = qe(), a = Ve(), o = Ke().set, s = Je(), c = Ge(), l = Ye(), u = Xe(), d = Te(), f = n.MutationObserver || n.WebKitMutationObserver, p = n.document, m = n.process, h = n.Promise, g = i("queueMicrotask"), _, v, y, b, x;
	if (!g) {
		var S = new s(), C = function() {
			var e, t;
			for (d && (e = m.domain) && e.exit(); t = S.get();) try {
				t();
			} catch (e) {
				throw S.head && _(), e;
			}
			e && e.enter();
		};
		!c && !d && !u && f && p ? (v = !0, y = p.createTextNode(""), new f(C).observe(y, { characterData: !0 }), _ = function() {
			y.data = v = !v;
		}) : !l && h && h.resolve ? (b = h.resolve(void 0), b.constructor = h, x = a(b.then, b), _ = function() {
			x(C);
		}) : d ? _ = function() {
			m.nextTick(C);
		} : (o = a(o, n), _ = function() {
			o(C);
		}), g = function(e) {
			S.head || _(), S.add(e);
		};
	}
	t.exports = g;
})), Qe = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e, t) {
		try {
			arguments.length === 1 ? console.error(e) : console.error(e, t);
		} catch {}
	};
})), $e = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e) {
		try {
			return {
				error: !1,
				value: e()
			};
		} catch (e) {
			return {
				error: !0,
				value: e
			};
		}
	};
})), et = /* @__PURE__ */ t(((e, t) => {
	t.exports = r().Promise;
})), tt = /* @__PURE__ */ t(((e, t) => {
	var n = r(), i = et(), a = g(), o = Ce(), s = oe(), c = I(), l = we(), u = k(), d = x(), f = i && i.prototype, p = c("species"), m = !1, h = a(n.PromiseRejectionEvent);
	t.exports = {
		CONSTRUCTOR: o("Promise", function() {
			var e = s(i), t = e !== String(i);
			if (!t && d === 66 || u && !(f.catch && f.finally)) return !0;
			if (!d || d < 51 || !/native code/.test(e)) {
				var n = new i(function(e) {
					e(1);
				}), r = function(e) {
					e(function() {}, function() {});
				}, a = n.constructor = {};
				if (a[p] = r, m = n.then(function() {}) instanceof r, !m) return !0;
			}
			return !t && (l === "BROWSER" || l === "DENO") && !h;
		}),
		REJECTION_EVENT: h,
		SUBCLASSING: m
	};
})), nt = /* @__PURE__ */ t(((e, t) => {
	var n = E(), r = TypeError, i = function(e) {
		var t, i;
		this.promise = new e(function(e, n) {
			if (t !== void 0 || i !== void 0) throw new r("Bad Promise constructor");
			t = e, i = n;
		}), this.resolve = n(t), this.reject = n(i);
	};
	t.exports.f = function(e) {
		return new i(e);
	};
})), rt = /* @__PURE__ */ t((() => {
	var e = U(), t = k(), n = Te(), i = r(), a = Ee(), o = s(), c = fe(), l = Ae(), u = je(), d = Ne(), f = E(), p = g(), m = _(), h = W(), v = Re(), y = Ke().set, b = Ze(), x = Qe(), S = $e(), C = Je(), w = ue(), T = et(), D = tt(), O = nt(), A = "Promise", j = D.CONSTRUCTOR, M = D.REJECTION_EVENT, N = D.SUBCLASSING, P = w.getterFor(A), F = w.set, I = T && T.prototype, L = T, R = I, z = i.TypeError, ee = i.document, te = i.process, ne = O.f, B = ne, re = !!(ee && ee.createEvent && i.dispatchEvent), ie = "unhandledrejection", ae = "rejectionhandled", oe = 0, se = 1, ce = 2, le = 1, de = 2, pe, me, he, V, ge = function(e) {
		var t;
		return m(e) && p(t = e.then) ? t : !1;
	}, _e = function(e, t) {
		var n = t.value, r = t.state === se, i = r ? e.ok : e.fail, a = e.resolve, s = e.reject, c = e.domain, l, u, d;
		try {
			i ? (r || (t.rejection === de && xe(t), t.rejection = le), i === !0 ? l = n : (c && c.enter(), l = i(n), c && (c.exit(), d = !0)), l === e.promise ? s(new z("Promise-chain cycle")) : (u = ge(l)) ? o(u, l, a, s) : a(l)) : s(n);
		} catch (e) {
			c && !d && c.exit(), s(e);
		}
	}, H = function(e, t) {
		e.notified || (e.notified = !0, b(function() {
			for (var n = e.reactions, r; r = n.get();) _e(r, e);
			e.notified = !1, t && !e.rejection && ye(e);
		}));
	}, ve = function(e, t, n) {
		var r, a;
		re ? (r = ee.createEvent("Event"), r.promise = t, r.reason = n, r.initEvent(e, !1, !0), i.dispatchEvent(r)) : r = {
			promise: t,
			reason: n
		}, !M && (a = i["on" + e]) ? a(r) : e === ie && x("Unhandled promise rejection", n);
	}, ye = function(e) {
		o(y, i, function() {
			var t = e.facade, r = e.value, i = be(e), a;
			if (i && (a = S(function() {
				n ? te.emit("unhandledRejection", r, t) : ve(ie, t, r);
			}), e.rejection = n || be(e) ? de : le, a.error)) throw a.value;
		});
	}, be = function(e) {
		return e.rejection !== le && !e.parent;
	}, xe = function(e) {
		o(y, i, function() {
			var t = e.facade;
			n ? te.emit("rejectionHandled", t) : ve(ae, t, e.value);
		});
	}, Se = function(e, t, n) {
		return function(r) {
			e(t, r, n);
		};
	}, Ce = function(e, t, n) {
		e.done || (e.done = !0, n && (e = n), e.value = t, e.state = ce, H(e, !0));
	}, we = function(e, t, n) {
		if (!e.done) {
			e.done = !0, n && (e = n);
			try {
				if (e.facade === t) throw new z("Promise can't be resolved itself");
				var r = ge(t);
				r ? b(function() {
					var n = { done: !1 };
					try {
						o(r, t, Se(we, n, e), Se(Ce, n, e));
					} catch (t) {
						Ce(n, t, e);
					}
				}) : (e.value = t, e.state = se, H(e, !1));
			} catch (t) {
				Ce({ done: !1 }, t, e);
			}
		}
	};
	if (j && (L = function(e) {
		h(this, R), f(e), o(pe, this);
		var t = P(this);
		try {
			e(Se(we, t), Se(Ce, t));
		} catch (e) {
			Ce(t, e);
		}
	}, R = L.prototype, pe = function(e) {
		F(this, {
			type: A,
			done: !1,
			notified: !1,
			parent: !1,
			reactions: new C(),
			rejection: !1,
			state: oe,
			value: null
		});
	}, pe.prototype = c(R, "then", function(e, t) {
		var r = P(this), i = ne(v(this, L));
		return r.parent = !0, i.ok = !p(e) || e, i.fail = p(t) && t, i.domain = n ? te.domain : void 0, r.state === oe ? r.reactions.add(i) : b(function() {
			_e(i, r);
		}), i.promise;
	}), me = function() {
		var e = new pe(), t = P(e);
		this.promise = e, this.resolve = Se(we, t), this.reject = Se(Ce, t);
	}, O.f = ne = function(e) {
		return e === L || e === he ? new me(e) : B(e);
	}, !t && p(T) && I !== Object.prototype)) {
		V = I.then, N || c(I, "then", function(e, t) {
			var n = this;
			return new L(function(e, t) {
				o(V, n, e, t);
			}).then(e, t);
		}, { unsafe: !0 });
		try {
			delete I.constructor;
		} catch {}
		l && l(I, R);
	}
	e({
		global: !0,
		constructor: !0,
		wrap: !0,
		forced: j
	}, { Promise: L }), he = a.Promise, u(L, A, !1, !0), d(A);
})), it = /* @__PURE__ */ t(((e, t) => {
	t.exports = Object.create ? Object.create(null) : {};
})), at = /* @__PURE__ */ t(((e, t) => {
	var n = I(), r = it(), i = n("iterator"), a = Array.prototype;
	t.exports = function(e) {
		return e !== void 0 && (r.Array === e || a[i] === e);
	};
})), ot = /* @__PURE__ */ t(((e, t) => {
	var n = d(), r = p(), i = D(), a = I()("iterator"), o = Array.prototype;
	t.exports = function(e) {
		if (!r(e)) return i(e, a) || i(e, "@@iterator") || (n(e) === "Arguments" ? o[a] : void 0);
	};
})), st = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = g(), i = B(), a = T(), o = ot(), c = TypeError;
	t.exports = function(e, t) {
		var s = arguments.length < 2 ? o(e) : t;
		if (r(s)) return i(n(s, e));
		throw new c(a(e) + " is not iterable");
	};
})), ct = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = B(), i = D();
	t.exports = function(e, t, a) {
		var o, s;
		r(e);
		try {
			if (o = i(e, "return"), !o) {
				if (t === "throw") throw a;
				return a;
			}
			o = n(o, e);
		} catch (e) {
			s = !0, o = e;
		}
		if (t === "throw") throw a;
		if (s) throw o;
		return r(o), a;
	};
})), lt = /* @__PURE__ */ t(((e, t) => {
	var n = Ve(), r = s(), i = B(), a = T(), o = at(), c = ge(), l = y(), u = st(), d = ot(), f = ct(), p = TypeError, m = function(e, t) {
		this.stopped = e, this.result = t;
	}, h = m.prototype;
	t.exports = function(e, t, s) {
		var g = s && s.that, _ = !!(s && s.AS_ENTRIES), v = !!(s && s.IS_RECORD), y = !!(s && s.IS_ITERATOR), b = !!(s && s.INTERRUPTED), x = n(t, g), S, C, w, T, E, D, O, k = function(e) {
			var t = S;
			return S = void 0, t && f(t, "normal"), new m(!0, e);
		}, A = function(e) {
			return _ ? (i(e), b ? x(e[0], e[1], k) : x(e[0], e[1])) : b ? x(e, k) : x(e);
		};
		if (v) S = e.iterator;
		else if (y) S = e;
		else {
			if (C = d(e), !C) throw new p(a(e) + " is not iterable");
			if (o(C)) {
				for (w = 0, T = c(e); T > w; w++) if (E = A(e[w]), E && l(h, E)) return E;
				return new m(!1);
			}
			S = u(e, C);
		}
		for (D = v ? e.next : S.next; !(O = r(D, S)).done;) {
			var j = O.value;
			try {
				E = A(j);
			} catch (e) {
				if (S) f(S, "throw", e);
				else throw e;
			}
			if (typeof E == "object" && E && l(h, E)) return E;
		}
		return new m(!1);
	};
})), ut = /* @__PURE__ */ t(((e, t) => {
	var n = I()("iterator"), r = !1;
	try {
		var i = 0, a = {
			next: function() {
				return { done: !!i++ };
			},
			return: function() {
				r = !0;
			}
		};
		a[n] = function() {
			return this;
		}, Array.from(a, function() {
			throw 2;
		});
	} catch {}
	t.exports = function(e, t) {
		try {
			if (!t && !r) return !1;
		} catch {
			return !1;
		}
		var i = !1;
		try {
			var a = {};
			a[n] = function() {
				return { next: function() {
					return { done: i = !0 };
				} };
			}, e(a);
		} catch {}
		return i;
	};
})), dt = /* @__PURE__ */ t(((e, t) => {
	var n = et(), r = ut();
	t.exports = tt().CONSTRUCTOR || !r(function(e) {
		n.all(e).then(void 0, function() {});
	});
})), ft = /* @__PURE__ */ t((() => {
	var e = U(), t = s(), n = E(), r = nt(), i = $e(), a = lt();
	e({
		target: "Promise",
		stat: !0,
		forced: dt()
	}, { all: function(e) {
		var o = this, s = r.f(o), c = s.resolve, l = s.reject, u = i(function() {
			var r = n(o.resolve), i = [], s = 0, u = 1;
			a(e, function(e) {
				var n = s++, a = !1;
				u++, t(r, o, e).then(function(e) {
					a || (a = !0, i[n] = e, --u || c(i));
				}, l);
			}), --u || c(i);
		});
		return u.error && l(u.value), s.promise;
	} });
})), pt = /* @__PURE__ */ t((() => {
	var e = U(), t = k(), n = tt().CONSTRUCTOR, r = et(), i = v(), a = g(), o = fe(), s = r && r.prototype;
	if (e({
		target: "Promise",
		proto: !0,
		forced: n,
		real: !0
	}, { catch: function(e) {
		return this.then(void 0, e);
	} }), !t && a(r)) {
		var c = i("Promise").prototype.catch;
		s.catch !== c && o(s, "catch", c, { unsafe: !0 });
	}
})), mt = /* @__PURE__ */ t((() => {
	var e = U(), t = s(), n = E(), r = nt(), i = $e(), a = lt();
	e({
		target: "Promise",
		stat: !0,
		forced: dt()
	}, { race: function(e) {
		var o = this, s = r.f(o), c = s.reject, l = i(function() {
			var r = n(o.resolve);
			a(e, function(e) {
				t(r, o, e).then(s.resolve, c);
			});
		});
		return l.error && c(l.value), s.promise;
	} });
})), ht = /* @__PURE__ */ t((() => {
	var e = U(), t = nt(), n = tt().CONSTRUCTOR;
	e({
		target: "Promise",
		stat: !0,
		forced: n
	}, { reject: function(e) {
		var n = t.f(this), r = n.reject;
		return r(e), n.promise;
	} });
})), gt = /* @__PURE__ */ t(((e, t) => {
	var n = B(), r = _(), i = nt();
	t.exports = function(e, t) {
		if (n(e), r(t) && t.constructor === e) return t;
		var a = i.f(e), o = a.resolve;
		return o(t), a.promise;
	};
})), _t = /* @__PURE__ */ t((() => {
	var e = U(), t = v(), n = k(), r = et(), i = tt().CONSTRUCTOR, a = gt(), o = t("Promise"), s = n && !i;
	e({
		target: "Promise",
		stat: !0,
		forced: n || i
	}, { resolve: function(e) {
		return a(s && this === o ? r : this, e);
	} });
}));
(/* @__PURE__ */ t((() => {
	rt(), ft(), pt(), mt(), ht(), _t();
})))();
function vt(e, t, n, r, i, a, o) {
	try {
		var s = e[a](o), c = s.value;
	} catch (e) {
		n(e);
		return;
	}
	s.done ? t(c) : Promise.resolve(c).then(r, i);
}
function yt(e) {
	return function() {
		var t = this, n = arguments;
		return new Promise(function(r, i) {
			var a = e.apply(t, n);
			function o(e) {
				vt(a, r, i, o, s, "next", e);
			}
			function s(e) {
				vt(a, r, i, o, s, "throw", e);
			}
			o(void 0);
		});
	};
}
//#endregion
//#region node_modules/core-js/internals/to-string.js
var bt = /* @__PURE__ */ t(((e, t) => {
	var n = Fe(), r = String;
	t.exports = function(e) {
		if (n(e) === "Symbol") throw TypeError("Cannot convert a Symbol value to a string");
		return r(e);
	};
})), xt = /* @__PURE__ */ t(((e, t) => {
	var n = B();
	t.exports = function() {
		var e = n(this), t = "";
		return e.hasIndices && (t += "d"), e.global && (t += "g"), e.ignoreCase && (t += "i"), e.multiline && (t += "m"), e.dotAll && (t += "s"), e.unicode && (t += "u"), e.unicodeSets && (t += "v"), e.sticky && (t += "y"), t;
	};
})), St = /* @__PURE__ */ t(((e, t) => {
	var n = i(), a = r().RegExp, o = n(function() {
		var e = a("a", "y");
		return e.lastIndex = 2, e.exec("abcd") !== null;
	}), s = o || n(function() {
		return !a("a", "y").sticky;
	});
	t.exports = {
		BROKEN_CARET: o || n(function() {
			var e = a("^r", "gy");
			return e.lastIndex = 2, e.exec("str") !== null;
		}),
		MISSED_STICKY: s,
		UNSUPPORTED_Y: o
	};
})), Ct = /* @__PURE__ */ t(((e, t) => {
	var n = H(), r = ve();
	t.exports = Object.keys || function(e) {
		return n(e, r);
	};
})), wt = /* @__PURE__ */ t(((e) => {
	var t = a(), n = ne(), r = re(), i = B(), o = h(), s = Ct();
	e.f = t && !n ? Object.defineProperties : function(e, t) {
		i(e);
		for (var n = o(t), a = s(t), c = a.length, l = 0, u; c > l;) r.f(e, u = a[l++], n[u]);
		return e;
	};
})), Tt = /* @__PURE__ */ t(((e, t) => {
	var n = B(), r = wt(), i = ve(), a = le(), o = He(), s = z(), c = ce(), l = ">", u = "<", d = "prototype", f = "script", p = c("IE_PROTO"), m = function() {}, h = function(e) {
		return u + f + l + e + u + "/" + f + l;
	}, g = function(e) {
		e.write(h("")), e.close();
		var t = e.parentWindow.Object;
		return e = null, t;
	}, _ = function() {
		var e = s("iframe"), t = "java" + f + ":", n;
		return e.style.display = "none", o.appendChild(e), e.src = String(t), n = e.contentWindow.document, n.open(), n.write(h("document.F=Object")), n.close(), n.F;
	}, v, y = function() {
		try {
			v = new ActiveXObject("htmlfile");
		} catch {}
		y = typeof document < "u" ? document.domain && v ? g(v) : _() : g(v);
		for (var e = i.length; e--;) delete y[d][i[e]];
		return y();
	};
	a[p] = !0, t.exports = Object.create || function(e, t) {
		var i;
		return e === null ? i = y() : (m[d] = n(e), i = new m(), m[d] = null, i[p] = e), t === void 0 ? i : r.f(i, t);
	};
})), Et = /* @__PURE__ */ t(((e, t) => {
	var n = i(), a = r().RegExp;
	t.exports = n(function() {
		var e = a(".", "s");
		return !(e.dotAll && e.test("\n") && e.flags === "s");
	});
})), Dt = /* @__PURE__ */ t(((e, t) => {
	var n = i(), a = r().RegExp;
	t.exports = n(function() {
		var e = a("(?<a>b)", "g");
		return e.exec("b").groups.a !== "b" || "b".replace(e, "$<a>c") !== "bc";
	});
})), Ot = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = u(), i = bt(), a = xt(), o = St(), c = M(), l = Tt(), d = ue().get, f = Et(), p = Dt(), m = c("native-string-replace", String.prototype.replace), h = RegExp.prototype.exec, g = h, _ = r("".charAt), v = r("".indexOf), y = r("".replace), b = r("".slice), x = (function() {
		var e = /a/, t = /b*/g;
		return n(h, e, "a"), n(h, t, "a"), e.lastIndex !== 0 || t.lastIndex !== 0;
	})(), S = o.BROKEN_CARET, C = /()??/.exec("")[1] !== void 0, w = x || C || S || f || p, T = function(e, t) {
		for (var n = e.groups = l(null), r = 0; r < t.length; r++) {
			var i = t[r];
			n[i[0]] = e[i[1]];
		}
	};
	w && (g = function(e) {
		var t = this, r = d(t), o = i(e), s = r.raw, c, l, u;
		if (s) return s.lastIndex = t.lastIndex, c = n(g, s, o), t.lastIndex = s.lastIndex, c && r.groups && T(c, r.groups), c;
		var f = r.groups, p = S && t.sticky, w = n(a, t), E = t.source, D = 0, O = o;
		if (p) {
			w = y(w, "y", ""), v(w, "g") === -1 && (w += "g"), O = b(o, t.lastIndex);
			var k = t.lastIndex > 0 && _(o, t.lastIndex - 1);
			t.lastIndex > 0 && (!t.multiline || t.multiline && k !== "\n" && k !== "\r" && k !== "\u2028" && k !== "\u2029") && (E = "(?: (?:" + E + "))", O = " " + O, D++), l = RegExp("^(?:" + E + ")", w);
		}
		C && (l = RegExp("^" + E + "$(?!\\s)", w)), x && (u = t.lastIndex);
		var A = n(h, p ? l : t, O);
		return p ? A ? (A.input = o, A[0] = b(A[0], D), A.index = t.lastIndex, t.lastIndex += A[0].length) : t.lastIndex = 0 : x && A && (t.lastIndex = t.global ? A.index + A[0].length : u), C && A && A.length > 1 && n(m, A[0], l, function() {
			for (var e = 1; e < arguments.length - 2; e++) arguments[e] === void 0 && (A[e] = void 0);
		}), A && f && T(A, f), A;
	}), t.exports = g;
})), kt = /* @__PURE__ */ t((() => {
	var e = U(), t = Ot();
	e({
		target: "RegExp",
		proto: !0,
		forced: /./.exec !== t
	}, { exec: t });
})), At = /* @__PURE__ */ t(((e, t) => {
	kt();
	var n = s(), r = fe(), a = Ot(), o = i(), c = I(), l = ie(), u = c("species"), d = RegExp.prototype;
	t.exports = function(e, t, i, s) {
		var f = c(e), p = !o(function() {
			var t = {};
			return t[f] = function() {
				return 7;
			}, ""[e](t) !== 7;
		}), m = p && !o(function() {
			var t = !1, n = /a/;
			if (e === "split") {
				var r = {};
				r[u] = function() {
					return n;
				}, n = {
					constructor: r,
					flags: ""
				}, n[f] = /./[f];
			}
			return n.exec = function() {
				return t = !0, null;
			}, n[f](""), !t;
		});
		if (!p || !m || i) {
			var h = /./[f], g = t(f, ""[e], function(e, t, r, i, o) {
				var s = t.exec;
				return s === a || s === d.exec ? p && !o ? {
					done: !0,
					value: n(h, t, r, i)
				} : {
					done: !0,
					value: n(e, r, t, i)
				} : { done: !1 };
			});
			r(String.prototype, e, g[0]), r(d, f, g[1]);
		}
		s && l(d[f], "sham", !0);
	};
})), jt = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = me(), i = bt(), a = m(), o = n("".charAt), s = n("".charCodeAt), c = n("".slice), l = function(e) {
		return function(t, n) {
			var l = i(a(t)), u = r(n), d = l.length, f, p;
			return u < 0 || u >= d ? e ? "" : void 0 : (f = s(l, u), f < 55296 || f > 56319 || u + 1 === d || (p = s(l, u + 1)) < 56320 || p > 57343 ? e ? o(l, u) : f : e ? c(l, u, u + 2) : (f - 55296 << 10) + (p - 56320) + 65536);
		};
	};
	t.exports = {
		codeAt: l(!1),
		charAt: l(!0)
	};
})), Mt = /* @__PURE__ */ t(((e, t) => {
	var n = jt().charAt;
	t.exports = function(e, t, r) {
		return t + (r && n(e, t).length || 1);
	};
})), Nt = /* @__PURE__ */ t(((e, t) => {
	var n = r(), a = i(), o = n.RegExp;
	t.exports = { correct: !a(function() {
		var e = !0;
		try {
			o(".", "d");
		} catch {
			e = !1;
		}
		var t = {}, n = "", r = e ? "dgimsy" : "gimsy", i = function(e, r) {
			Object.defineProperty(t, e, { get: function() {
				return n += r, !0;
			} });
		}, a = {
			dotAll: "s",
			global: "g",
			ignoreCase: "i",
			multiline: "m",
			sticky: "y"
		};
		for (var s in e && (a.hasIndices = "d"), a) i(s, a[s]);
		return Object.getOwnPropertyDescriptor(o.prototype, "flags").get.call(t) !== r || n !== r;
	}) };
})), Pt = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = P(), i = y(), a = Nt(), o = xt(), c = RegExp.prototype;
	t.exports = a.correct ? function(e) {
		return e.flags;
	} : function(e) {
		return !a.correct && i(c, e) && !r(e, "flags") ? n(o, e) : e.flags;
	};
})), Ft = /* @__PURE__ */ t(((e, t) => {
	var n = s(), r = B(), i = g(), a = d(), o = Ot(), c = TypeError;
	t.exports = function(e, t) {
		var s = e.exec;
		if (i(s)) {
			var l = n(s, e, t);
			return l !== null && r(l), l;
		}
		if (a(e) === "RegExp") return n(o, e, t);
		throw new c("RegExp#exec called on incompatible receiver");
	};
})), It = /* @__PURE__ */ t((() => {
	var e = s(), t = u(), n = At(), r = B(), i = _(), a = V(), o = bt(), c = m(), l = D(), d = Mt(), f = Pt(), p = Ft(), h = t("".indexOf);
	n("match", function(t, n, s) {
		return [function(n) {
			var r = c(this), a = i(n) ? l(n, t) : void 0;
			if (a) return e(a, n, r);
			var s = o(r);
			return new RegExp(n)[t](s);
		}, function(e) {
			var t = r(this), i = o(e), c = s(n, t, i);
			if (c.done) return c.value;
			var l = o(f(t));
			if (!~h(l, "g")) return p(t, i);
			var u = !!~h(l, "u") || !!~h(l, "v");
			t.lastIndex = 0;
			for (var m = [], g = 0, _; (_ = p(t, i)) !== null;) {
				var v = o(_[0]);
				m[g] = v, v === "" && (t.lastIndex = d(i, a(t.lastIndex), u)), g++;
			}
			return g === 0 ? null : m;
		}];
	});
})), Lt = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = N(), i = Math.floor, a = n("".charAt), o = n("".replace), s = n("".slice), c = /\$([$&'`]|\d{1,2}|<[^>]*>)/g, l = /\$([$&'`]|\d{1,2})/g;
	t.exports = function(e, t, n, u, d, f) {
		var p = n + e.length, m = u.length, h = l;
		return d !== void 0 && (d = r(d), h = c), o(f, h, function(r, o) {
			var c;
			switch (a(o, 0)) {
				case "$": return "$";
				case "&": return e;
				case "`": return s(t, 0, n);
				case "'": return s(t, p);
				case "<":
					c = d[s(o, 1, -1)];
					break;
				default:
					var l = +o;
					if (l === 0) return r;
					if (l > m) {
						var f = i(l / 10);
						return f === 0 ? r : f <= m ? u[f - 1] === void 0 ? a(o, 1) : u[f - 1] + a(o, 1) : r;
					}
					c = u[l - 1];
			}
			return c === void 0 ? "" : c;
		});
	};
})), Rt = /* @__PURE__ */ t((() => {
	var e = ze(), t = s(), n = u(), r = At(), a = i(), o = B(), c = g(), l = _(), d = me(), f = V(), p = bt(), h = m(), v = Mt(), y = D(), b = Lt(), x = Pt(), S = Ft(), C = I()("replace"), w = Math.max, T = Math.min, E = n([].concat), O = n([].push), k = n("".indexOf), A = n("".slice), j = function(e) {
		return e === void 0 ? e : String(e);
	}, M = (function() {
		return "a".replace(/./, "$0") === "$0";
	})(), N = (function() {
		return /./[C] ? /./[C]("a", "$0") === "" : !1;
	})();
	r("replace", function(n, r, i) {
		var a = N ? "$" : "$0";
		return [function(e, n) {
			var i = h(this), a = l(e) ? y(e, C) : void 0;
			return a ? t(a, e, i, n) : t(r, p(i), e, n);
		}, function(t, n) {
			var s = o(this), l = p(t), u = c(n);
			u || (n = p(n));
			var m = p(x(s));
			if (typeof n == "string" && !~k(n, a) && !~k(n, "$<") && !~k(m, "y")) {
				var h = i(r, s, l, n);
				if (h.done) return h.value;
			}
			var g = !!~k(m, "g"), _;
			g && (_ = !!~k(m, "u") || !!~k(m, "v"), s.lastIndex = 0);
			for (var y = [], C; C = S(s, l), !(C === null || (O(y, C), !g));) p(C[0]) === "" && (s.lastIndex = v(l, f(s.lastIndex), _));
			for (var D = "", M = 0, N = 0; N < y.length; N++) {
				C = y[N];
				for (var P = p(C[0]), F = w(T(d(C.index), l.length), 0), I = [], L, R = 1; R < C.length; R++) O(I, j(C[R]));
				var z = C.groups;
				if (u) {
					var ee = E([P], I, F, l);
					z !== void 0 && O(ee, z), L = p(e(n, void 0, ee));
				} else L = b(P, l, F, I, z, n);
				F >= M && (D += A(l, M, F) + L, M = F + P.length);
			}
			return D + A(l, M);
		}];
	}, !!a(function() {
		var e = /./;
		return e.exec = function() {
			var e = [];
			return e.groups = { a: "7" }, e;
		}, "".replace(e, "$<a>") !== "7";
	}) || !M || N);
})), zt = /* @__PURE__ */ t(((e, t) => {
	var n = _(), r = d(), i = I()("match");
	t.exports = function(e) {
		var t;
		return n(e) && ((t = e[i]) === void 0 ? r(e) === "RegExp" : !!t);
	};
})), Bt = /* @__PURE__ */ t(((e, t) => {
	var n = zt(), r = TypeError;
	t.exports = function(e) {
		if (n(e)) throw new r("The method doesn't accept regular expressions");
		return e;
	};
})), Vt = /* @__PURE__ */ t(((e, t) => {
	var n = I()("match");
	t.exports = function(e) {
		var t = /./;
		try {
			"/./"[e](t);
		} catch {
			try {
				return t[n] = !1, "/./"[e](t);
			} catch {}
		}
		return !1;
	};
})), Ht = /* @__PURE__ */ t((() => {
	var e = U(), t = Be(), n = te().f, r = V(), i = bt(), a = Bt(), o = m(), s = Vt(), c = k(), l = t("".slice), u = Math.min, d = s("startsWith");
	e({
		target: "String",
		proto: !0,
		forced: !(!c && !d && function() {
			var e = n(String.prototype, "startsWith");
			return e && !e.writable;
		}()) && !d
	}, { startsWith: function(e) {
		var t = i(o(this));
		a(e);
		var n = i(e), s = r(u(arguments.length > 1 ? arguments[1] : void 0, t.length));
		return l(t, s, s + n.length) === n;
	} });
})), Ut = /* @__PURE__ */ t(((e, t) => {
	var n = I(), r = Tt(), i = re().f, a = n("unscopables"), o = Array.prototype;
	o[a] === void 0 && i(o, a, {
		configurable: !0,
		value: r(null)
	}), t.exports = function(e) {
		o[a][e] = !0;
	};
})), Wt = /* @__PURE__ */ t(((e, t) => {
	t.exports = !i()(function() {
		function e() {}
		return e.prototype.constructor = null, Object.getPrototypeOf(new e()) !== e.prototype;
	});
})), Gt = /* @__PURE__ */ t(((e, t) => {
	var n = P(), r = g(), i = N(), a = ce(), o = Wt(), s = a("IE_PROTO"), c = Object, l = c.prototype;
	t.exports = o ? c.getPrototypeOf : function(e) {
		var t = i(e);
		if (n(t, s)) return t[s];
		var a = t.constructor;
		return r(a) && t instanceof a ? a.prototype : t instanceof c ? l : null;
	};
})), Kt = /* @__PURE__ */ t(((e, t) => {
	var n = i(), r = g(), a = _(), o = Tt(), s = Gt(), c = fe(), l = I(), u = k(), d = l("iterator"), f = !1, p, m, h;
	[].keys && (h = [].keys(), "next" in h ? (m = s(s(h)), m !== Object.prototype && (p = m)) : f = !0), !a(p) || n(function() {
		var e = {};
		return p[d].call(e) !== e;
	}) ? p = {} : u && (p = o(p)), r(p[d]) || c(p, d, function() {
		return this;
	}), t.exports = {
		IteratorPrototype: p,
		BUGGY_SAFARI_ITERATORS: f
	};
})), qt = /* @__PURE__ */ t(((e, t) => {
	var n = Kt().IteratorPrototype, r = Tt(), i = l(), a = je(), o = it(), s = function() {
		return this;
	};
	t.exports = function(e, t, c, l) {
		var u = t + " Iterator";
		return e.prototype = r(n, { next: i(+!l, c) }), a(e, u, !1, !0), o[u] = s, e;
	};
})), Jt = /* @__PURE__ */ t(((e, t) => {
	var n = U(), r = s(), i = k(), a = ae(), o = g(), c = qt(), l = Gt(), u = Ae(), d = je(), f = ie(), p = fe(), m = I(), h = it(), _ = Kt(), v = a.PROPER, y = a.CONFIGURABLE, b = _.IteratorPrototype, x = _.BUGGY_SAFARI_ITERATORS, S = m("iterator"), C = "keys", w = "values", T = "entries", E = function() {
		return this;
	};
	t.exports = function(e, t, a, s, m, g, _) {
		c(a, t, s);
		var D = function(e) {
			if (e === m && M) return M;
			if (!x && e && e in A) return A[e];
			switch (e) {
				case C: return function() {
					return new a(this, e);
				};
				case w: return function() {
					return new a(this, e);
				};
				case T: return function() {
					return new a(this, e);
				};
			}
			return function() {
				return new a(this);
			};
		}, O = t + " Iterator", k = !1, A = e.prototype, j = A[S] || A["@@iterator"] || m && A[m], M = !x && j || D(m), N = t === "Array" && A.entries || j, P, F, I;
		if (N && (P = l(N.call(new e())), P !== Object.prototype && P.next && (!i && l(P) !== b && (u ? u(P, b) : o(P[S]) || p(P, S, E)), d(P, O, !0, !0), i && (h[O] = E))), v && m === w && j && j.name !== w && (!i && y ? f(A, "name", w) : (k = !0, M = function() {
			return r(j, this);
		})), m) if (F = {
			values: D(w),
			keys: g ? M : D(C),
			entries: D(T)
		}, _) for (I in F) (x || k || !(I in A)) && p(A, I, F[I]);
		else n({
			target: t,
			proto: !0,
			forced: x || k
		}, F);
		return (!i || _) && A[S] !== M && p(A, S, M, { name: m }), h[t] = M, F;
	};
})), Yt = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e, t) {
		return {
			value: e,
			done: t
		};
	};
})), Xt = /* @__PURE__ */ t(((e, t) => {
	var n = h(), r = Ut(), i = it(), o = ue(), s = re().f, c = Jt(), l = Yt(), u = k(), d = a(), f = "Array Iterator", p = o.set, m = o.getterFor(f);
	t.exports = c(Array, "Array", function(e, t) {
		p(this, {
			type: f,
			target: n(e),
			index: 0,
			kind: t
		});
	}, function() {
		var e = m(this), t = e.target, n = e.index++;
		if (!t || n >= t.length) return e.target = null, l(void 0, !0);
		switch (e.kind) {
			case "keys": return l(n, !1);
			case "values": return l(t[n], !1);
		}
		return l([n, t[n]], !1);
	}, "values");
	var g = i.Arguments = i.Array;
	if (r("keys"), r("values"), r("entries"), !u && d && g.name !== "values") try {
		s(g, "name", { value: "values" });
	} catch {}
})), Zt = /* @__PURE__ */ t(((e, t) => {
	t.exports = {
		CSSRuleList: 0,
		CSSStyleDeclaration: 0,
		CSSValueList: 0,
		ClientRectList: 0,
		DOMRectList: 0,
		DOMStringList: 0,
		DOMTokenList: 1,
		DataTransferItemList: 0,
		FileList: 0,
		HTMLAllCollection: 0,
		HTMLCollection: 0,
		HTMLFormElement: 0,
		HTMLSelectElement: 0,
		MediaList: 0,
		MimeTypeArray: 0,
		NamedNodeMap: 0,
		NodeList: 1,
		PaintRequestList: 0,
		Plugin: 0,
		PluginArray: 0,
		SVGLengthList: 0,
		SVGNumberList: 0,
		SVGPathSegList: 0,
		SVGPointList: 0,
		SVGStringList: 0,
		SVGTransformList: 0,
		SourceBufferList: 0,
		StyleSheetList: 0,
		TextTrackCueList: 0,
		TextTrackList: 0,
		TouchList: 0
	};
})), Qt = /* @__PURE__ */ t(((e, t) => {
	var n = z()("span").classList, r = n && n.constructor && n.constructor.prototype;
	t.exports = r === Object.prototype ? void 0 : r;
})), $t = /* @__PURE__ */ t((() => {
	var e = r(), t = Zt(), n = Qt(), i = Xt(), a = ie(), o = je(), s = I()("iterator"), c = i.values, l = function(e, n) {
		if (e) {
			if (e[s] !== c) try {
				a(e, s, c);
			} catch {
				e[s] = c;
			}
			if (o(e, n, !0), t[n]) {
				for (var r in i) if (e[r] !== i[r]) try {
					a(e, r, i[r]);
				} catch {
					e[r] = i[r];
				}
			}
		}
	};
	for (var u in t) l(e[u] && e[u].prototype, u);
	l(n, "DOMTokenList");
}));
It(), Rt(), Ht(), Xt(), $t();
function en(e, t) {
	if (n(e) != "object" || !e) return e;
	var r = e[Symbol.toPrimitive];
	if (r !== void 0) {
		var i = r.call(e, t || "default");
		if (n(i) != "object") return i;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/toPropertyKey.js
function tn(e) {
	var t = en(e, "string");
	return n(t) == "symbol" ? t : t + "";
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/defineProperty.js
function nn(e, t, n) {
	return (t = tn(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
//#endregion
//#region node_modules/core-js/internals/array-reduce.js
var rn = /* @__PURE__ */ t(((e, t) => {
	var n = E(), r = N(), i = f(), a = ge(), o = TypeError, s = "Reduce of empty array with no initial value", c = function(e) {
		return function(t, c, l, u) {
			var d = r(t), f = i(d), p = a(d);
			if (n(c), p === 0 && l < 2) throw new o(s);
			var m = e ? p - 1 : 0, h = e ? -1 : 1;
			if (l < 2) for (;;) {
				if (m in f) {
					u = f[m], m += h;
					break;
				}
				if (m += h, e ? m < 0 : p <= m) throw new o(s);
			}
			for (; e ? m >= 0 : p > m; m += h) m in f && (u = c(u, f[m], m, d));
			return u;
		};
	};
	t.exports = {
		left: c(!1),
		right: c(!0)
	};
})), an = /* @__PURE__ */ t(((e, t) => {
	var n = i();
	t.exports = function(e, t) {
		var r = [][e];
		return !!r && n(function() {
			r.call(null, t || function() {
				return 1;
			}, 1);
		});
	};
})), on = /* @__PURE__ */ t((() => {
	var e = U(), t = rn().left, n = an(), r = x();
	e({
		target: "Array",
		proto: !0,
		forced: !Te() && r > 79 && r < 83 || !n("reduce")
	}, { reduce: function(e) {
		var n = arguments.length;
		return t(this, e, n, n > 1 ? arguments[1] : void 0);
	} });
})), sn = /* @__PURE__ */ t((() => {
	var e = U(), t = Be(), n = te().f, r = V(), i = bt(), a = Bt(), o = m(), s = Vt(), c = k(), l = t("".slice), u = Math.min, d = s("endsWith");
	e({
		target: "String",
		proto: !0,
		forced: !(!c && !d && function() {
			var e = n(String.prototype, "endsWith");
			return e && !e.writable;
		}()) && !d
	}, { endsWith: function(e) {
		var t = i(o(this));
		a(e);
		var n = i(e), s = arguments.length > 1 ? arguments[1] : void 0, c = t.length, d = s === void 0 ? c : u(r(s), c);
		return l(t, d - n.length, d) === n;
	} });
})), cn = /* @__PURE__ */ t((() => {
	var e = s(), t = u(), n = At(), r = B(), a = _(), o = m(), c = Re(), l = Mt(), d = V(), f = bt(), p = D(), h = Pt(), g = Ft(), v = St(), y = i(), b = v.UNSUPPORTED_Y, x = 4294967295, S = Math.min, C = t([].push), w = t("".slice), T = t("".indexOf), E = !y(function() {
		var e = /(?:)/, t = e.exec;
		e.exec = function() {
			return t.apply(this, arguments);
		};
		var n = "ab".split(e);
		return n.length !== 2 || n[0] !== "a" || n[1] !== "b";
	}), O = "abbc".split(/(b)*/)[1] === "c" || "test".split(/(?:)/, -1).length !== 4 || "ab".split(/(?:ab)*/).length !== 2 || ".".split(/(.?)(.?)/).length !== 4 || ".".split(/()()/).length > 1 || "".split(/.?/).length;
	n("split", function(t, n, i) {
		var s = "0".split(void 0, 0).length ? function(t, r) {
			return t === void 0 && r === 0 ? [] : e(n, this, t, r);
		} : n;
		return [function(n, r) {
			var i = o(this), c = a(n) ? p(n, t) : void 0;
			return c ? e(c, n, i, r) : e(s, f(i), n, r);
		}, function(e, t) {
			var a = r(this), o = f(e);
			if (!O) {
				var u = i(s, a, o, t, s !== n);
				if (u.done) return u.value;
			}
			var p = c(a, RegExp), m = f(h(a)), _ = !!~T(m, "u") || !!~T(m, "v");
			b ? ~T(m, "g") || (m += "g") : ~T(m, "y") || (m += "y");
			var v = new p(b ? "^(?:" + a.source + ")" : a, m), y = t === void 0 ? x : t >>> 0;
			if (y === 0) return [];
			if (o.length === 0) return g(v, o) === null ? [o] : [];
			for (var E = 0, D = 0, k = []; D < o.length;) {
				v.lastIndex = b ? 0 : D;
				var A = g(v, b ? w(o, D) : o), j;
				if (A === null || (j = S(d(v.lastIndex + (b ? D : 0)), o.length)) === E) D = l(o, D, _);
				else {
					if (C(k, w(o, E, D)), k.length === y) return k;
					for (var M = 1; M <= A.length - 1; M++) if (C(k, A[M]), k.length === y) return k;
					D = E = j;
				}
			}
			return C(k, w(o, E)), k;
		}];
	}, O || !E, b);
})), ln = /* @__PURE__ */ t(((e, t) => {
	(function() {
		var e, n, r, i, a, o;
		typeof performance < "u" && performance !== null && performance.now ? t.exports = function() {
			return performance.now();
		} : typeof process < "u" && process !== null && process.hrtime ? (t.exports = function() {
			return (e() - a) / 1e6;
		}, n = process.hrtime, e = function() {
			var e = n();
			return e[0] * 1e9 + e[1];
		}, i = e(), o = process.uptime() * 1e9, a = i - o) : Date.now ? (t.exports = function() {
			return Date.now() - r;
		}, r = Date.now()) : (t.exports = function() {
			return (/* @__PURE__ */ new Date()).getTime() - r;
		}, r = (/* @__PURE__ */ new Date()).getTime());
	}).call(e);
})), un = /* @__PURE__ */ t(((e, t) => {
	for (var n = ln(), r = typeof window > "u" ? global : window, i = ["moz", "webkit"], a = "AnimationFrame", o = r["request" + a], s = r["cancel" + a] || r["cancelRequest" + a], c = 0; !o && c < i.length; c++) o = r[i[c] + "Request" + a], s = r[i[c] + "Cancel" + a] || r[i[c] + "CancelRequest" + a];
	if (!o || !s) {
		var l = 0, u = 0, d = [], f = 1e3 / 60;
		o = function(e) {
			if (d.length === 0) {
				var t = n(), r = Math.max(0, f - (t - l));
				l = r + t, setTimeout(function() {
					var e = d.slice(0);
					d.length = 0;
					for (var t = 0; t < e.length; t++) if (!e[t].cancelled) try {
						e[t].callback(l);
					} catch (e) {
						setTimeout(function() {
							throw e;
						}, 0);
					}
				}, Math.round(r));
			}
			return d.push({
				handle: ++u,
				callback: e,
				cancelled: !1
			}), u;
		}, s = function(e) {
			for (var t = 0; t < d.length; t++) d[t].handle === e && (d[t].cancelled = !0);
		};
	}
	t.exports = function(e) {
		return o.call(r, e);
	}, t.exports.cancel = function() {
		s.apply(r, arguments);
	}, t.exports.polyfill = function(e) {
		e ||= r, e.requestAnimationFrame = o, e.cancelAnimationFrame = s;
	};
})), dn = /* @__PURE__ */ t(((e, t) => {
	t.exports = "	\n\v\f\r \xA0              　\u2028\u2029﻿";
})), fn = /* @__PURE__ */ t(((e, t) => {
	var n = u(), r = m(), i = bt(), a = dn(), o = n("".replace), s = RegExp("^[" + a + "]+"), c = RegExp("(^|[^" + a + "])[" + a + "]+$"), l = function(e) {
		return function(t) {
			var n = i(r(t));
			return e & 1 && (n = o(n, s, "")), e & 2 && (n = o(n, c, "$1")), n;
		};
	};
	t.exports = {
		start: l(1),
		end: l(2),
		trim: l(3)
	};
})), pn = /* @__PURE__ */ t(((e, t) => {
	var n = ae().PROPER, r = i(), a = dn(), o = "​᠎";
	t.exports = function(e) {
		return r(function() {
			return !!a[e]() || o[e]() !== o || n && a[e].name !== e;
		});
	};
})), mn = /* @__PURE__ */ t((() => {
	var e = U(), t = fn().trim;
	e({
		target: "String",
		proto: !0,
		forced: pn()("trim")
	}, { trim: function() {
		return t(this);
	} });
})), hn = /* @__PURE__ */ t(((e, t) => {
	t.exports = function(e) {
		this.ok = !1, this.alpha = 1, e.charAt(0) == "#" && (e = e.substr(1, 6)), e = e.replace(/ /g, ""), e = e.toLowerCase();
		var t = {
			aliceblue: "f0f8ff",
			antiquewhite: "faebd7",
			aqua: "00ffff",
			aquamarine: "7fffd4",
			azure: "f0ffff",
			beige: "f5f5dc",
			bisque: "ffe4c4",
			black: "000000",
			blanchedalmond: "ffebcd",
			blue: "0000ff",
			blueviolet: "8a2be2",
			brown: "a52a2a",
			burlywood: "deb887",
			cadetblue: "5f9ea0",
			chartreuse: "7fff00",
			chocolate: "d2691e",
			coral: "ff7f50",
			cornflowerblue: "6495ed",
			cornsilk: "fff8dc",
			crimson: "dc143c",
			cyan: "00ffff",
			darkblue: "00008b",
			darkcyan: "008b8b",
			darkgoldenrod: "b8860b",
			darkgray: "a9a9a9",
			darkgreen: "006400",
			darkkhaki: "bdb76b",
			darkmagenta: "8b008b",
			darkolivegreen: "556b2f",
			darkorange: "ff8c00",
			darkorchid: "9932cc",
			darkred: "8b0000",
			darksalmon: "e9967a",
			darkseagreen: "8fbc8f",
			darkslateblue: "483d8b",
			darkslategray: "2f4f4f",
			darkturquoise: "00ced1",
			darkviolet: "9400d3",
			deeppink: "ff1493",
			deepskyblue: "00bfff",
			dimgray: "696969",
			dodgerblue: "1e90ff",
			feldspar: "d19275",
			firebrick: "b22222",
			floralwhite: "fffaf0",
			forestgreen: "228b22",
			fuchsia: "ff00ff",
			gainsboro: "dcdcdc",
			ghostwhite: "f8f8ff",
			gold: "ffd700",
			goldenrod: "daa520",
			gray: "808080",
			green: "008000",
			greenyellow: "adff2f",
			honeydew: "f0fff0",
			hotpink: "ff69b4",
			indianred: "cd5c5c",
			indigo: "4b0082",
			ivory: "fffff0",
			khaki: "f0e68c",
			lavender: "e6e6fa",
			lavenderblush: "fff0f5",
			lawngreen: "7cfc00",
			lemonchiffon: "fffacd",
			lightblue: "add8e6",
			lightcoral: "f08080",
			lightcyan: "e0ffff",
			lightgoldenrodyellow: "fafad2",
			lightgrey: "d3d3d3",
			lightgreen: "90ee90",
			lightpink: "ffb6c1",
			lightsalmon: "ffa07a",
			lightseagreen: "20b2aa",
			lightskyblue: "87cefa",
			lightslateblue: "8470ff",
			lightslategray: "778899",
			lightsteelblue: "b0c4de",
			lightyellow: "ffffe0",
			lime: "00ff00",
			limegreen: "32cd32",
			linen: "faf0e6",
			magenta: "ff00ff",
			maroon: "800000",
			mediumaquamarine: "66cdaa",
			mediumblue: "0000cd",
			mediumorchid: "ba55d3",
			mediumpurple: "9370d8",
			mediumseagreen: "3cb371",
			mediumslateblue: "7b68ee",
			mediumspringgreen: "00fa9a",
			mediumturquoise: "48d1cc",
			mediumvioletred: "c71585",
			midnightblue: "191970",
			mintcream: "f5fffa",
			mistyrose: "ffe4e1",
			moccasin: "ffe4b5",
			navajowhite: "ffdead",
			navy: "000080",
			oldlace: "fdf5e6",
			olive: "808000",
			olivedrab: "6b8e23",
			orange: "ffa500",
			orangered: "ff4500",
			orchid: "da70d6",
			palegoldenrod: "eee8aa",
			palegreen: "98fb98",
			paleturquoise: "afeeee",
			palevioletred: "d87093",
			papayawhip: "ffefd5",
			peachpuff: "ffdab9",
			peru: "cd853f",
			pink: "ffc0cb",
			plum: "dda0dd",
			powderblue: "b0e0e6",
			purple: "800080",
			rebeccapurple: "663399",
			red: "ff0000",
			rosybrown: "bc8f8f",
			royalblue: "4169e1",
			saddlebrown: "8b4513",
			salmon: "fa8072",
			sandybrown: "f4a460",
			seagreen: "2e8b57",
			seashell: "fff5ee",
			sienna: "a0522d",
			silver: "c0c0c0",
			skyblue: "87ceeb",
			slateblue: "6a5acd",
			slategray: "708090",
			snow: "fffafa",
			springgreen: "00ff7f",
			steelblue: "4682b4",
			tan: "d2b48c",
			teal: "008080",
			thistle: "d8bfd8",
			tomato: "ff6347",
			turquoise: "40e0d0",
			violet: "ee82ee",
			violetred: "d02090",
			wheat: "f5deb3",
			white: "ffffff",
			whitesmoke: "f5f5f5",
			yellow: "ffff00",
			yellowgreen: "9acd32"
		};
		e = t[e] || e;
		for (var n = [
			{
				re: /^rgba\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3}),\s*((?:\d?\.)?\d)\)$/,
				example: ["rgba(123, 234, 45, 0.8)", "rgba(255,234,245,1.0)"],
				process: function(e) {
					return [
						parseInt(e[1]),
						parseInt(e[2]),
						parseInt(e[3]),
						parseFloat(e[4])
					];
				}
			},
			{
				re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,
				example: ["rgb(123, 234, 45)", "rgb(255,234,245)"],
				process: function(e) {
					return [
						parseInt(e[1]),
						parseInt(e[2]),
						parseInt(e[3])
					];
				}
			},
			{
				re: /^([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
				example: ["#00ff00", "336699"],
				process: function(e) {
					return [
						parseInt(e[1], 16),
						parseInt(e[2], 16),
						parseInt(e[3], 16)
					];
				}
			},
			{
				re: /^([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
				example: ["#fb0", "f0f"],
				process: function(e) {
					return [
						parseInt(e[1] + e[1], 16),
						parseInt(e[2] + e[2], 16),
						parseInt(e[3] + e[3], 16)
					];
				}
			}
		], r = 0; r < n.length; r++) {
			var i = n[r].re, a = n[r].process, o = i.exec(e);
			if (o) {
				var s = a(o);
				this.r = s[0], this.g = s[1], this.b = s[2], s.length > 3 && (this.alpha = s[3]), this.ok = !0;
			}
		}
		this.r = this.r < 0 || isNaN(this.r) ? 0 : this.r > 255 ? 255 : this.r, this.g = this.g < 0 || isNaN(this.g) ? 0 : this.g > 255 ? 255 : this.g, this.b = this.b < 0 || isNaN(this.b) ? 0 : this.b > 255 ? 255 : this.b, this.alpha = this.alpha < 0 ? 0 : this.alpha > 1 || isNaN(this.alpha) ? 1 : this.alpha, this.toRGB = function() {
			return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
		}, this.toRGBA = function() {
			return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.alpha + ")";
		}, this.toHex = function() {
			var e = this.r.toString(16), t = this.g.toString(16), n = this.b.toString(16);
			return e.length == 1 && (e = "0" + e), t.length == 1 && (t = "0" + t), n.length == 1 && (n = "0" + n), "#" + e + t + n;
		}, this.getHelpXML = function() {
			for (var e = [], r = 0; r < n.length; r++) for (var i = n[r].example, a = 0; a < i.length; a++) e[e.length] = i[a];
			for (var o in t) e[e.length] = o;
			var s = document.createElement("ul");
			s.setAttribute("id", "rgbcolor-examples");
			for (var r = 0; r < e.length; r++) try {
				var c = document.createElement("li"), l = new RGBColor(e[r]), u = document.createElement("div");
				u.style.cssText = "margin: 3px; border: 1px solid black; background:" + l.toHex() + "; color:" + l.toHex(), u.appendChild(document.createTextNode("test"));
				var d = document.createTextNode(" " + e[r] + " -> " + l.toRGB() + " -> " + l.toHex());
				c.appendChild(u), c.appendChild(d), s.appendChild(c);
			} catch {}
			return s;
		};
	};
})), gn = /* @__PURE__ */ t((() => {
	var e = U(), t = Be(), n = _e().indexOf, r = an(), i = t([].indexOf), a = !!i && 1 / i([1], 1, -0) < 0;
	e({
		target: "Array",
		proto: !0,
		forced: a || !r("indexOf")
	}, { indexOf: function(e) {
		var t = arguments.length > 1 ? arguments[1] : void 0;
		return a ? i(this, e, t) || 0 : n(this, e, t);
	} });
})), _n = /* @__PURE__ */ t((() => {
	var e = U(), t = u(), n = Bt(), r = m(), i = bt(), a = Vt(), o = t("".indexOf);
	e({
		target: "String",
		proto: !0,
		forced: !a("includes")
	}, { includes: function(e) {
		return !!~o(i(r(this)), i(n(e)), arguments.length > 1 ? arguments[1] : void 0);
	} });
})), vn = /* @__PURE__ */ t(((e, t) => {
	var n = d();
	t.exports = Array.isArray || function(e) {
		return n(e) === "Array";
	};
})), yn = /* @__PURE__ */ t((() => {
	var e = U(), t = u(), n = vn(), r = t([].reverse), i = [1, 2];
	e({
		target: "Array",
		proto: !0,
		forced: String(i) === String(i.reverse())
	}, { reverse: function() {
		return n(this) && (this.length = this.length), r(this);
	} });
}));
on(), sn(), cn();
var bn = /* @__PURE__ */ e(un(), 1);
mn();
var xn = /* @__PURE__ */ e(hn(), 1);
gn(), _n(), yn();
var Sn = function(e, t) {
	return (Sn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e, t) {
		e.__proto__ = t;
	} || function(e, t) {
		for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
	})(e, t);
};
function Cn(e, t) {
	if (typeof t != "function" && t !== null) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");
	function n() {
		this.constructor = e;
	}
	Sn(e, t), e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
function wn(e) {
	var t = "";
	Array.isArray(e) || (e = [e]);
	for (var n = 0; n < e.length; n++) {
		var r = e[n];
		if (r.type === K.CLOSE_PATH) t += "z";
		else if (r.type === K.HORIZ_LINE_TO) t += (r.relative ? "h" : "H") + r.x;
		else if (r.type === K.VERT_LINE_TO) t += (r.relative ? "v" : "V") + r.y;
		else if (r.type === K.MOVE_TO) t += (r.relative ? "m" : "M") + r.x + " " + r.y;
		else if (r.type === K.LINE_TO) t += (r.relative ? "l" : "L") + r.x + " " + r.y;
		else if (r.type === K.CURVE_TO) t += (r.relative ? "c" : "C") + r.x1 + " " + r.y1 + " " + r.x2 + " " + r.y2 + " " + r.x + " " + r.y;
		else if (r.type === K.SMOOTH_CURVE_TO) t += (r.relative ? "s" : "S") + r.x2 + " " + r.y2 + " " + r.x + " " + r.y;
		else if (r.type === K.QUAD_TO) t += (r.relative ? "q" : "Q") + r.x1 + " " + r.y1 + " " + r.x + " " + r.y;
		else if (r.type === K.SMOOTH_QUAD_TO) t += (r.relative ? "t" : "T") + r.x + " " + r.y;
		else {
			if (r.type !== K.ARC) throw Error("Unexpected command type \"" + r.type + "\" at index " + n + ".");
			t += (r.relative ? "a" : "A") + r.rX + " " + r.rY + " " + r.xRot + " " + +r.lArcFlag + " " + +r.sweepFlag + " " + r.x + " " + r.y;
		}
	}
	return t;
}
function Tn(e, t) {
	var n = e[0], r = e[1];
	return [n * Math.cos(t) - r * Math.sin(t), n * Math.sin(t) + r * Math.cos(t)];
}
function En() {
	for (var e = [...arguments], t = 0; t < e.length; t++) if (typeof e[t] != "number") throw Error("assertNumbers arguments[" + t + "] is not a number. " + typeof e[t] + " == typeof " + e[t]);
	return !0;
}
var Dn = Math.PI;
function On(e, t, n) {
	e.lArcFlag = e.lArcFlag === 0 ? 0 : 1, e.sweepFlag = e.sweepFlag === 0 ? 0 : 1;
	var r = e.rX, i = e.rY, a = e.x, o = e.y;
	r = Math.abs(e.rX), i = Math.abs(e.rY);
	var s = Tn([(t - a) / 2, (n - o) / 2], -e.xRot / 180 * Dn), c = s[0], l = s[1], u = c ** 2 / r ** 2 + l ** 2 / i ** 2;
	1 < u && (r *= Math.sqrt(u), i *= Math.sqrt(u)), e.rX = r, e.rY = i;
	var d = r ** 2 * l ** 2 + i ** 2 * c ** 2, f = (e.lArcFlag === e.sweepFlag ? -1 : 1) * Math.sqrt(Math.max(0, (r ** 2 * i ** 2 - d) / d)), p = r * l / i * f, m = -i * c / r * f, h = Tn([p, m], e.xRot / 180 * Dn);
	e.cX = h[0] + (t + a) / 2, e.cY = h[1] + (n + o) / 2, e.phi1 = Math.atan2((l - m) / i, (c - p) / r), e.phi2 = Math.atan2((-l - m) / i, (-c - p) / r), e.sweepFlag === 0 && e.phi2 > e.phi1 && (e.phi2 -= 2 * Dn), e.sweepFlag === 1 && e.phi2 < e.phi1 && (e.phi2 += 2 * Dn), e.phi1 *= 180 / Dn, e.phi2 *= 180 / Dn;
}
function kn(e, t, n) {
	En(e, t, n);
	var r = e * e + t * t - n * n;
	if (0 > r) return [];
	if (r === 0) return [[e * n / (e * e + t * t), t * n / (e * e + t * t)]];
	var i = Math.sqrt(r);
	return [[(e * n + t * i) / (e * e + t * t), (t * n - e * i) / (e * e + t * t)], [(e * n - t * i) / (e * e + t * t), (t * n + e * i) / (e * e + t * t)]];
}
var G, An = Math.PI / 180;
function jn(e, t, n) {
	return (1 - n) * e + n * t;
}
function Mn(e, t, n, r) {
	return e + Math.cos(r / 180 * Dn) * t + Math.sin(r / 180 * Dn) * n;
}
function Nn(e, t, n, r) {
	var i = 1e-6, a = t - e, o = n - t, s = 3 * a + 3 * (r - n) - 6 * o, c = 6 * (o - a), l = 3 * a;
	return Math.abs(s) < i ? [-l / c] : function(e, t, n) {
		n === void 0 && (n = 1e-6);
		var r = e * e / 4 - t;
		if (r < -n) return [];
		if (r <= n) return [-e / 2];
		var i = Math.sqrt(r);
		return [-e / 2 - i, -e / 2 + i];
	}(c / s, l / s, i);
}
function Pn(e, t, n, r, i) {
	var a = 1 - i;
	return e * (a * a * a) + t * (3 * a * a * i) + n * (3 * a * i * i) + r * (i * i * i);
}
(function(e) {
	function t() {
		return i((function(e, t, n) {
			return e.relative &&= (e.x1 !== void 0 && (e.x1 += t), e.y1 !== void 0 && (e.y1 += n), e.x2 !== void 0 && (e.x2 += t), e.y2 !== void 0 && (e.y2 += n), e.x !== void 0 && (e.x += t), e.y !== void 0 && (e.y += n), !1), e;
		}));
	}
	function n() {
		var e = NaN, t = NaN, n = NaN, r = NaN;
		return i((function(i, a, o) {
			return i.type & K.SMOOTH_CURVE_TO && (i.type = K.CURVE_TO, e = isNaN(e) ? a : e, t = isNaN(t) ? o : t, i.x1 = i.relative ? a - e : 2 * a - e, i.y1 = i.relative ? o - t : 2 * o - t), i.type & K.CURVE_TO ? (e = i.relative ? a + i.x2 : i.x2, t = i.relative ? o + i.y2 : i.y2) : (e = NaN, t = NaN), i.type & K.SMOOTH_QUAD_TO && (i.type = K.QUAD_TO, n = isNaN(n) ? a : n, r = isNaN(r) ? o : r, i.x1 = i.relative ? a - n : 2 * a - n, i.y1 = i.relative ? o - r : 2 * o - r), i.type & K.QUAD_TO ? (n = i.relative ? a + i.x1 : i.x1, r = i.relative ? o + i.y1 : i.y1) : (n = NaN, r = NaN), i;
		}));
	}
	function r() {
		var e = NaN, t = NaN;
		return i((function(n, r, i) {
			if (n.type & K.SMOOTH_QUAD_TO && (n.type = K.QUAD_TO, e = isNaN(e) ? r : e, t = isNaN(t) ? i : t, n.x1 = n.relative ? r - e : 2 * r - e, n.y1 = n.relative ? i - t : 2 * i - t), n.type & K.QUAD_TO) {
				e = n.relative ? r + n.x1 : n.x1, t = n.relative ? i + n.y1 : n.y1;
				var a = n.x1, o = n.y1;
				n.type = K.CURVE_TO, n.x1 = ((n.relative ? 0 : r) + 2 * a) / 3, n.y1 = ((n.relative ? 0 : i) + 2 * o) / 3, n.x2 = (n.x + 2 * a) / 3, n.y2 = (n.y + 2 * o) / 3;
			} else e = NaN, t = NaN;
			return n;
		}));
	}
	function i(e) {
		var t = 0, n = 0, r = NaN, i = NaN;
		return function(a) {
			if (isNaN(r) && !(a.type & K.MOVE_TO)) throw Error("path must start with moveto");
			var o = e(a, t, n, r, i);
			return a.type & K.CLOSE_PATH && (t = r, n = i), a.x !== void 0 && (t = a.relative ? t + a.x : a.x), a.y !== void 0 && (n = a.relative ? n + a.y : a.y), a.type & K.MOVE_TO && (r = t, i = n), o;
		};
	}
	function a(e, t, n, r, a, o) {
		return En(e, t, n, r, a, o), i((function(i, s, c, l) {
			var u = i.x1, d = i.x2, f = i.relative && !isNaN(l), p = i.x === void 0 ? f ? 0 : s : i.x, m = i.y === void 0 ? f ? 0 : c : i.y;
			function h(e) {
				return e * e;
			}
			i.type & K.HORIZ_LINE_TO && t !== 0 && (i.type = K.LINE_TO, i.y = i.relative ? 0 : c), i.type & K.VERT_LINE_TO && n !== 0 && (i.type = K.LINE_TO, i.x = i.relative ? 0 : s), i.x !== void 0 && (i.x = i.x * e + m * n + (f ? 0 : a)), i.y !== void 0 && (i.y = p * t + i.y * r + (f ? 0 : o)), i.x1 !== void 0 && (i.x1 = i.x1 * e + i.y1 * n + (f ? 0 : a)), i.y1 !== void 0 && (i.y1 = u * t + i.y1 * r + (f ? 0 : o)), i.x2 !== void 0 && (i.x2 = i.x2 * e + i.y2 * n + (f ? 0 : a)), i.y2 !== void 0 && (i.y2 = d * t + i.y2 * r + (f ? 0 : o));
			var g = e * r - t * n;
			if (i.xRot !== void 0 && (e !== 1 || t !== 0 || n !== 0 || r !== 1)) if (g === 0) delete i.rX, delete i.rY, delete i.xRot, delete i.lArcFlag, delete i.sweepFlag, i.type = K.LINE_TO;
			else {
				var _ = i.xRot * Math.PI / 180, v = Math.sin(_), y = Math.cos(_), b = 1 / h(i.rX), x = 1 / h(i.rY), S = h(y) * b + h(v) * x, C = 2 * v * y * (b - x), w = h(v) * b + h(y) * x, T = S * r * r - C * t * r + w * t * t, E = C * (e * r + t * n) - 2 * (S * n * r + w * e * t), D = S * n * n - C * e * n + w * e * e, O = (Math.atan2(E, T - D) + Math.PI) % Math.PI / 2, k = Math.sin(O), A = Math.cos(O);
				i.rX = Math.abs(g) / Math.sqrt(T * h(A) + E * k * A + D * h(k)), i.rY = Math.abs(g) / Math.sqrt(T * h(k) - E * k * A + D * h(A)), i.xRot = 180 * O / Math.PI;
			}
			return i.sweepFlag !== void 0 && 0 > g && (i.sweepFlag = +!i.sweepFlag), i;
		}));
	}
	function o() {
		return function(e) {
			var t = {};
			for (var n in e) t[n] = e[n];
			return t;
		};
	}
	e.ROUND = function(e) {
		function t(t) {
			return Math.round(t * e) / e;
		}
		return e === void 0 && (e = 0x9184e72a000), En(e), function(e) {
			return e.x1 !== void 0 && (e.x1 = t(e.x1)), e.y1 !== void 0 && (e.y1 = t(e.y1)), e.x2 !== void 0 && (e.x2 = t(e.x2)), e.y2 !== void 0 && (e.y2 = t(e.y2)), e.x !== void 0 && (e.x = t(e.x)), e.y !== void 0 && (e.y = t(e.y)), e.rX !== void 0 && (e.rX = t(e.rX)), e.rY !== void 0 && (e.rY = t(e.rY)), e;
		};
	}, e.TO_ABS = t, e.TO_REL = function() {
		return i((function(e, t, n) {
			return e.relative ||= (e.x1 !== void 0 && (e.x1 -= t), e.y1 !== void 0 && (e.y1 -= n), e.x2 !== void 0 && (e.x2 -= t), e.y2 !== void 0 && (e.y2 -= n), e.x !== void 0 && (e.x -= t), e.y !== void 0 && (e.y -= n), !0), e;
		}));
	}, e.NORMALIZE_HVZ = function(e, t, n) {
		return e === void 0 && (e = !0), t === void 0 && (t = !0), n === void 0 && (n = !0), i((function(r, i, a, o, s) {
			if (isNaN(o) && !(r.type & K.MOVE_TO)) throw Error("path must start with moveto");
			return t && r.type & K.HORIZ_LINE_TO && (r.type = K.LINE_TO, r.y = r.relative ? 0 : a), n && r.type & K.VERT_LINE_TO && (r.type = K.LINE_TO, r.x = r.relative ? 0 : i), e && r.type & K.CLOSE_PATH && (r.type = K.LINE_TO, r.x = r.relative ? o - i : o, r.y = r.relative ? s - a : s), r.type & K.ARC && (r.rX === 0 || r.rY === 0) && (r.type = K.LINE_TO, delete r.rX, delete r.rY, delete r.xRot, delete r.lArcFlag, delete r.sweepFlag), r;
		}));
	}, e.NORMALIZE_ST = n, e.QT_TO_C = r, e.INFO = i, e.SANITIZE = function(e) {
		e === void 0 && (e = 0), En(e);
		var t = NaN, n = NaN, r = NaN, a = NaN;
		return i((function(i, o, s, c, l) {
			var u = Math.abs, d = !1, f = 0, p = 0;
			if (i.type & K.SMOOTH_CURVE_TO && (f = isNaN(t) ? 0 : o - t, p = isNaN(n) ? 0 : s - n), i.type & (K.CURVE_TO | K.SMOOTH_CURVE_TO) ? (t = i.relative ? o + i.x2 : i.x2, n = i.relative ? s + i.y2 : i.y2) : (t = NaN, n = NaN), i.type & K.SMOOTH_QUAD_TO ? (r = isNaN(r) ? o : 2 * o - r, a = isNaN(a) ? s : 2 * s - a) : i.type & K.QUAD_TO ? (r = i.relative ? o + i.x1 : i.x1, a = i.relative ? s + i.y1 : i.y2) : (r = NaN, a = NaN), i.type & K.LINE_COMMANDS || i.type & K.ARC && (i.rX === 0 || i.rY === 0 || !i.lArcFlag) || i.type & K.CURVE_TO || i.type & K.SMOOTH_CURVE_TO || i.type & K.QUAD_TO || i.type & K.SMOOTH_QUAD_TO) {
				var m = i.x === void 0 ? 0 : i.relative ? i.x : i.x - o, h = i.y === void 0 ? 0 : i.relative ? i.y : i.y - s;
				f = isNaN(r) ? i.x1 === void 0 ? f : i.relative ? i.x : i.x1 - o : r - o, p = isNaN(a) ? i.y1 === void 0 ? p : i.relative ? i.y : i.y1 - s : a - s;
				var g = i.x2 === void 0 ? 0 : i.relative ? i.x : i.x2 - o, _ = i.y2 === void 0 ? 0 : i.relative ? i.y : i.y2 - s;
				u(m) <= e && u(h) <= e && u(f) <= e && u(p) <= e && u(g) <= e && u(_) <= e && (d = !0);
			}
			return i.type & K.CLOSE_PATH && u(o - c) <= e && u(s - l) <= e && (d = !0), d ? [] : i;
		}));
	}, e.MATRIX = a, e.ROTATE = function(e, t, n) {
		t === void 0 && (t = 0), n === void 0 && (n = 0), En(e, t, n);
		var r = Math.sin(e), i = Math.cos(e);
		return a(i, r, -r, i, t - t * i + n * r, n - t * r - n * i);
	}, e.TRANSLATE = function(e, t) {
		return t === void 0 && (t = 0), En(e, t), a(1, 0, 0, 1, e, t);
	}, e.SCALE = function(e, t) {
		return t === void 0 && (t = e), En(e, t), a(e, 0, 0, t, 0, 0);
	}, e.SKEW_X = function(e) {
		return En(e), a(1, 0, Math.atan(e), 1, 0, 0);
	}, e.SKEW_Y = function(e) {
		return En(e), a(1, Math.atan(e), 0, 1, 0, 0);
	}, e.X_AXIS_SYMMETRY = function(e) {
		return e === void 0 && (e = 0), En(e), a(-1, 0, 0, 1, e, 0);
	}, e.Y_AXIS_SYMMETRY = function(e) {
		return e === void 0 && (e = 0), En(e), a(1, 0, 0, -1, 0, e);
	}, e.A_TO_C = function() {
		return i((function(e, t, n) {
			return K.ARC === e.type ? function(e, t, n) {
				var r, i, a, o;
				e.cX || On(e, t, n);
				for (var s = Math.min(e.phi1, e.phi2), c = Math.max(e.phi1, e.phi2) - s, l = Math.ceil(c / 90), u = Array(l), d = t, f = n, p = 0; p < l; p++) {
					var m = jn(e.phi1, e.phi2, p / l), h = jn(e.phi1, e.phi2, (p + 1) / l), g = h - m, _ = 4 / 3 * Math.tan(g * An / 4), v = [Math.cos(m * An) - _ * Math.sin(m * An), Math.sin(m * An) + _ * Math.cos(m * An)], y = v[0], b = v[1], x = [Math.cos(h * An), Math.sin(h * An)], S = x[0], C = x[1], w = [S + _ * Math.sin(h * An), C - _ * Math.cos(h * An)], T = w[0], E = w[1];
					u[p] = {
						relative: e.relative,
						type: K.CURVE_TO
					};
					var D = function(t, n) {
						var r = Tn([t * e.rX, n * e.rY], e.xRot), i = r[0], a = r[1];
						return [e.cX + i, e.cY + a];
					};
					r = D(y, b), u[p].x1 = r[0], u[p].y1 = r[1], i = D(T, E), u[p].x2 = i[0], u[p].y2 = i[1], a = D(S, C), u[p].x = a[0], u[p].y = a[1], e.relative && (u[p].x1 -= d, u[p].y1 -= f, u[p].x2 -= d, u[p].y2 -= f, u[p].x -= d, u[p].y -= f), d = (o = [u[p].x, u[p].y])[0], f = o[1];
				}
				return u;
			}(e, e.relative ? 0 : t, e.relative ? 0 : n) : e;
		}));
	}, e.ANNOTATE_ARCS = function() {
		return i((function(e, t, n) {
			return e.relative && (t = 0, n = 0), K.ARC === e.type && On(e, t, n), e;
		}));
	}, e.CLONE = o, e.CALCULATE_BOUNDS = function() {
		var e = function(e) {
			var t = {};
			for (var n in e) t[n] = e[n];
			return t;
		}, a = t(), o = r(), s = n(), c = i((function(t, n, r) {
			var i = s(o(a(e(t))));
			function l(e) {
				e > c.maxX && (c.maxX = e), e < c.minX && (c.minX = e);
			}
			function u(e) {
				e > c.maxY && (c.maxY = e), e < c.minY && (c.minY = e);
			}
			if (i.type & K.DRAWING_COMMANDS && (l(n), u(r)), i.type & K.HORIZ_LINE_TO && l(i.x), i.type & K.VERT_LINE_TO && u(i.y), i.type & K.LINE_TO && (l(i.x), u(i.y)), i.type & K.CURVE_TO) {
				l(i.x), u(i.y);
				for (var d = 0, f = Nn(n, i.x1, i.x2, i.x); d < f.length; d++) 0 < (O = f[d]) && 1 > O && l(Pn(n, i.x1, i.x2, i.x, O));
				for (var p = 0, m = Nn(r, i.y1, i.y2, i.y); p < m.length; p++) 0 < (O = m[p]) && 1 > O && u(Pn(r, i.y1, i.y2, i.y, O));
			}
			if (i.type & K.ARC) {
				l(i.x), u(i.y), On(i, n, r);
				for (var h = i.xRot / 180 * Math.PI, g = Math.cos(h) * i.rX, _ = Math.sin(h) * i.rX, v = -Math.sin(h) * i.rY, y = Math.cos(h) * i.rY, b = i.phi1 < i.phi2 ? [i.phi1, i.phi2] : -180 > i.phi2 ? [i.phi2 + 360, i.phi1 + 360] : [i.phi2, i.phi1], x = b[0], S = b[1], C = function(e) {
					var t = e[0], n = e[1], r = 180 * Math.atan2(n, t) / Math.PI;
					return r < x ? r + 360 : r;
				}, w = 0, T = kn(v, -g, 0).map(C); w < T.length; w++) (O = T[w]) > x && O < S && l(Mn(i.cX, g, v, O));
				for (var E = 0, D = kn(y, -_, 0).map(C); E < D.length; E++) {
					var O;
					(O = D[E]) > x && O < S && u(Mn(i.cY, _, y, O));
				}
			}
			return t;
		}));
		return c.minX = Infinity, c.maxX = -Infinity, c.minY = Infinity, c.maxY = -Infinity, c;
	};
})(G ||= {});
var Fn, In = function() {
	function e() {}
	return e.prototype.round = function(e) {
		return this.transform(G.ROUND(e));
	}, e.prototype.toAbs = function() {
		return this.transform(G.TO_ABS());
	}, e.prototype.toRel = function() {
		return this.transform(G.TO_REL());
	}, e.prototype.normalizeHVZ = function(e, t, n) {
		return this.transform(G.NORMALIZE_HVZ(e, t, n));
	}, e.prototype.normalizeST = function() {
		return this.transform(G.NORMALIZE_ST());
	}, e.prototype.qtToC = function() {
		return this.transform(G.QT_TO_C());
	}, e.prototype.aToC = function() {
		return this.transform(G.A_TO_C());
	}, e.prototype.sanitize = function(e) {
		return this.transform(G.SANITIZE(e));
	}, e.prototype.translate = function(e, t) {
		return this.transform(G.TRANSLATE(e, t));
	}, e.prototype.scale = function(e, t) {
		return this.transform(G.SCALE(e, t));
	}, e.prototype.rotate = function(e, t, n) {
		return this.transform(G.ROTATE(e, t, n));
	}, e.prototype.matrix = function(e, t, n, r, i, a) {
		return this.transform(G.MATRIX(e, t, n, r, i, a));
	}, e.prototype.skewX = function(e) {
		return this.transform(G.SKEW_X(e));
	}, e.prototype.skewY = function(e) {
		return this.transform(G.SKEW_Y(e));
	}, e.prototype.xSymmetry = function(e) {
		return this.transform(G.X_AXIS_SYMMETRY(e));
	}, e.prototype.ySymmetry = function(e) {
		return this.transform(G.Y_AXIS_SYMMETRY(e));
	}, e.prototype.annotateArcs = function() {
		return this.transform(G.ANNOTATE_ARCS());
	}, e;
}(), Ln = function(e) {
	return e === " " || e === "	" || e === "\r" || e === "\n";
}, Rn = function(e) {
	return 48 <= e.charCodeAt(0) && e.charCodeAt(0) <= 57;
}, zn = function(e) {
	function t() {
		var t = e.call(this) || this;
		return t.curNumber = "", t.curCommandType = -1, t.curCommandRelative = !1, t.canParseCommandOrComma = !0, t.curNumberHasExp = !1, t.curNumberHasExpDigits = !1, t.curNumberHasDecimal = !1, t.curArgs = [], t;
	}
	return Cn(t, e), t.prototype.finish = function(e) {
		if (e === void 0 && (e = []), this.parse(" ", e), this.curArgs.length !== 0 || !this.canParseCommandOrComma) throw SyntaxError("Unterminated command at the path end.");
		return e;
	}, t.prototype.parse = function(e, t) {
		var n = this;
		t === void 0 && (t = []);
		for (var r = function(e) {
			t.push(e), n.curArgs.length = 0, n.canParseCommandOrComma = !0;
		}, i = 0; i < e.length; i++) {
			var a = e[i], o = !(this.curCommandType !== K.ARC || this.curArgs.length !== 3 && this.curArgs.length !== 4 || this.curNumber.length !== 1 || this.curNumber !== "0" && this.curNumber !== "1"), s = Rn(a) && (this.curNumber === "0" && a === "0" || o);
			if (!Rn(a) || s) if (a !== "e" && a !== "E") if (a !== "-" && a !== "+" || !this.curNumberHasExp || this.curNumberHasExpDigits) if (a !== "." || this.curNumberHasExp || this.curNumberHasDecimal || o) {
				if (this.curNumber && this.curCommandType !== -1) {
					var c = Number(this.curNumber);
					if (isNaN(c)) throw SyntaxError("Invalid number ending at " + i);
					if (this.curCommandType === K.ARC) {
						if (this.curArgs.length === 0 || this.curArgs.length === 1) {
							if (0 > c) throw SyntaxError("Expected positive number, got \"" + c + "\" at index \"" + i + "\"");
						} else if ((this.curArgs.length === 3 || this.curArgs.length === 4) && this.curNumber !== "0" && this.curNumber !== "1") throw SyntaxError("Expected a flag, got \"" + this.curNumber + "\" at index \"" + i + "\"");
					}
					this.curArgs.push(c), this.curArgs.length === Bn[this.curCommandType] && (K.HORIZ_LINE_TO === this.curCommandType ? r({
						type: K.HORIZ_LINE_TO,
						relative: this.curCommandRelative,
						x: c
					}) : K.VERT_LINE_TO === this.curCommandType ? r({
						type: K.VERT_LINE_TO,
						relative: this.curCommandRelative,
						y: c
					}) : this.curCommandType === K.MOVE_TO || this.curCommandType === K.LINE_TO || this.curCommandType === K.SMOOTH_QUAD_TO ? (r({
						type: this.curCommandType,
						relative: this.curCommandRelative,
						x: this.curArgs[0],
						y: this.curArgs[1]
					}), K.MOVE_TO === this.curCommandType && (this.curCommandType = K.LINE_TO)) : this.curCommandType === K.CURVE_TO ? r({
						type: K.CURVE_TO,
						relative: this.curCommandRelative,
						x1: this.curArgs[0],
						y1: this.curArgs[1],
						x2: this.curArgs[2],
						y2: this.curArgs[3],
						x: this.curArgs[4],
						y: this.curArgs[5]
					}) : this.curCommandType === K.SMOOTH_CURVE_TO ? r({
						type: K.SMOOTH_CURVE_TO,
						relative: this.curCommandRelative,
						x2: this.curArgs[0],
						y2: this.curArgs[1],
						x: this.curArgs[2],
						y: this.curArgs[3]
					}) : this.curCommandType === K.QUAD_TO ? r({
						type: K.QUAD_TO,
						relative: this.curCommandRelative,
						x1: this.curArgs[0],
						y1: this.curArgs[1],
						x: this.curArgs[2],
						y: this.curArgs[3]
					}) : this.curCommandType === K.ARC && r({
						type: K.ARC,
						relative: this.curCommandRelative,
						rX: this.curArgs[0],
						rY: this.curArgs[1],
						xRot: this.curArgs[2],
						lArcFlag: this.curArgs[3],
						sweepFlag: this.curArgs[4],
						x: this.curArgs[5],
						y: this.curArgs[6]
					})), this.curNumber = "", this.curNumberHasExpDigits = !1, this.curNumberHasExp = !1, this.curNumberHasDecimal = !1, this.canParseCommandOrComma = !0;
				}
				if (!Ln(a)) if (a === "," && this.canParseCommandOrComma) this.canParseCommandOrComma = !1;
				else if (a !== "+" && a !== "-" && a !== ".") if (s) this.curNumber = a, this.curNumberHasDecimal = !1;
				else {
					if (this.curArgs.length !== 0) throw SyntaxError("Unterminated command at index " + i + ".");
					if (!this.canParseCommandOrComma) throw SyntaxError("Unexpected character \"" + a + "\" at index " + i + ". Command cannot follow comma");
					if (this.canParseCommandOrComma = !1, a !== "z" && a !== "Z") if (a === "h" || a === "H") this.curCommandType = K.HORIZ_LINE_TO, this.curCommandRelative = a === "h";
					else if (a === "v" || a === "V") this.curCommandType = K.VERT_LINE_TO, this.curCommandRelative = a === "v";
					else if (a === "m" || a === "M") this.curCommandType = K.MOVE_TO, this.curCommandRelative = a === "m";
					else if (a === "l" || a === "L") this.curCommandType = K.LINE_TO, this.curCommandRelative = a === "l";
					else if (a === "c" || a === "C") this.curCommandType = K.CURVE_TO, this.curCommandRelative = a === "c";
					else if (a === "s" || a === "S") this.curCommandType = K.SMOOTH_CURVE_TO, this.curCommandRelative = a === "s";
					else if (a === "q" || a === "Q") this.curCommandType = K.QUAD_TO, this.curCommandRelative = a === "q";
					else if (a === "t" || a === "T") this.curCommandType = K.SMOOTH_QUAD_TO, this.curCommandRelative = a === "t";
					else {
						if (a !== "a" && a !== "A") throw SyntaxError("Unexpected character \"" + a + "\" at index " + i + ".");
						this.curCommandType = K.ARC, this.curCommandRelative = a === "a";
					}
					else t.push({ type: K.CLOSE_PATH }), this.canParseCommandOrComma = !0, this.curCommandType = -1;
				}
				else this.curNumber = a, this.curNumberHasDecimal = a === ".";
			} else this.curNumber += a, this.curNumberHasDecimal = !0;
			else this.curNumber += a;
			else this.curNumber += a, this.curNumberHasExp = !0;
			else this.curNumber += a, this.curNumberHasExpDigits = this.curNumberHasExp;
		}
		return t;
	}, t.prototype.transform = function(e) {
		return Object.create(this, { parse: { value: function(t, n) {
			n === void 0 && (n = []);
			for (var r = 0, i = Object.getPrototypeOf(this).parse.call(this, t); r < i.length; r++) {
				var a = i[r], o = e(a);
				Array.isArray(o) ? n.push.apply(n, o) : n.push(o);
			}
			return n;
		} } });
	}, t;
}(In), K = function(e) {
	function t(n) {
		var r = e.call(this) || this;
		return r.commands = typeof n == "string" ? t.parse(n) : n, r;
	}
	return Cn(t, e), t.prototype.encode = function() {
		return t.encode(this.commands);
	}, t.prototype.getBounds = function() {
		var e = G.CALCULATE_BOUNDS();
		return this.transform(e), e;
	}, t.prototype.transform = function(e) {
		for (var t = [], n = 0, r = this.commands; n < r.length; n++) {
			var i = e(r[n]);
			Array.isArray(i) ? t.push.apply(t, i) : t.push(i);
		}
		return this.commands = t, this;
	}, t.encode = function(e) {
		return wn(e);
	}, t.parse = function(e) {
		var t = new zn(), n = [];
		return t.parse(e, n), t.finish(n), n;
	}, t.CLOSE_PATH = 1, t.MOVE_TO = 2, t.HORIZ_LINE_TO = 4, t.VERT_LINE_TO = 8, t.LINE_TO = 16, t.CURVE_TO = 32, t.SMOOTH_CURVE_TO = 64, t.QUAD_TO = 128, t.SMOOTH_QUAD_TO = 256, t.ARC = 512, t.LINE_COMMANDS = t.LINE_TO | t.HORIZ_LINE_TO | t.VERT_LINE_TO, t.DRAWING_COMMANDS = t.HORIZ_LINE_TO | t.VERT_LINE_TO | t.LINE_TO | t.CURVE_TO | t.SMOOTH_CURVE_TO | t.QUAD_TO | t.SMOOTH_QUAD_TO | t.ARC, t;
}(In), Bn = ((Fn = {})[K.MOVE_TO] = 2, Fn[K.LINE_TO] = 2, Fn[K.HORIZ_LINE_TO] = 1, Fn[K.VERT_LINE_TO] = 1, Fn[K.CLOSE_PATH] = 0, Fn[K.QUAD_TO] = 4, Fn[K.SMOOTH_QUAD_TO] = 2, Fn[K.CURVE_TO] = 6, Fn[K.SMOOTH_CURVE_TO] = 4, Fn[K.ARC] = 7, Fn);
(/* @__PURE__ */ t((() => {
	var e = ae().PROPER, t = fe(), n = B(), r = bt(), a = i(), o = Pt(), s = "toString", c = RegExp.prototype, l = c[s], u = a(function() {
		return l.call({
			source: "a",
			flags: "b"
		}) !== "/a/b";
	}), d = e && l.name !== s;
	(u || d) && t(c, s, function() {
		var e = n(this), t = r(e.source), i = r(o(e));
		return "/" + t + "/" + i;
	}, { unsafe: !0 });
})))();
function Vn(e) {
	"@babel/helpers - typeof";
	return Vn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, Vn(e);
}
function Hn(e, t) {
	if (!(e instanceof t)) throw TypeError("Cannot call a class as a function");
}
var Un = [
	512,
	512,
	456,
	512,
	328,
	456,
	335,
	512,
	405,
	328,
	271,
	456,
	388,
	335,
	292,
	512,
	454,
	405,
	364,
	328,
	298,
	271,
	496,
	456,
	420,
	388,
	360,
	335,
	312,
	292,
	273,
	512,
	482,
	454,
	428,
	405,
	383,
	364,
	345,
	328,
	312,
	298,
	284,
	271,
	259,
	496,
	475,
	456,
	437,
	420,
	404,
	388,
	374,
	360,
	347,
	335,
	323,
	312,
	302,
	292,
	282,
	273,
	265,
	512,
	497,
	482,
	468,
	454,
	441,
	428,
	417,
	405,
	394,
	383,
	373,
	364,
	354,
	345,
	337,
	328,
	320,
	312,
	305,
	298,
	291,
	284,
	278,
	271,
	265,
	259,
	507,
	496,
	485,
	475,
	465,
	456,
	446,
	437,
	428,
	420,
	412,
	404,
	396,
	388,
	381,
	374,
	367,
	360,
	354,
	347,
	341,
	335,
	329,
	323,
	318,
	312,
	307,
	302,
	297,
	292,
	287,
	282,
	278,
	273,
	269,
	265,
	261,
	512,
	505,
	497,
	489,
	482,
	475,
	468,
	461,
	454,
	447,
	441,
	435,
	428,
	422,
	417,
	411,
	405,
	399,
	394,
	389,
	383,
	378,
	373,
	368,
	364,
	359,
	354,
	350,
	345,
	341,
	337,
	332,
	328,
	324,
	320,
	316,
	312,
	309,
	305,
	301,
	298,
	294,
	291,
	287,
	284,
	281,
	278,
	274,
	271,
	268,
	265,
	262,
	259,
	257,
	507,
	501,
	496,
	491,
	485,
	480,
	475,
	470,
	465,
	460,
	456,
	451,
	446,
	442,
	437,
	433,
	428,
	424,
	420,
	416,
	412,
	408,
	404,
	400,
	396,
	392,
	388,
	385,
	381,
	377,
	374,
	370,
	367,
	363,
	360,
	357,
	354,
	350,
	347,
	344,
	341,
	338,
	335,
	332,
	329,
	326,
	323,
	320,
	318,
	315,
	312,
	310,
	307,
	304,
	302,
	299,
	297,
	294,
	292,
	289,
	287,
	285,
	282,
	280,
	278,
	275,
	273,
	271,
	269,
	267,
	265,
	263,
	261,
	259
], Wn = [
	9,
	11,
	12,
	13,
	13,
	14,
	14,
	15,
	15,
	15,
	15,
	16,
	16,
	16,
	16,
	17,
	17,
	17,
	17,
	17,
	17,
	17,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24
];
function Gn(e, t, n, r, i) {
	if (typeof e == "string" && (e = document.getElementById(e)), !e || Vn(e) !== "object" || !("getContext" in e)) throw TypeError("Expecting canvas with `getContext` method in processCanvasRGB(A) calls!");
	var a = e.getContext("2d");
	try {
		return a.getImageData(t, n, r, i);
	} catch (e) {
		throw Error("unable to access image data: " + e);
	}
}
function Kn(e, t, n, r, i, a) {
	if (!(isNaN(a) || a < 1)) {
		a |= 0;
		var o = Gn(e, t, n, r, i);
		o = qn(o, t, n, r, i, a), e.getContext("2d").putImageData(o, t, n);
	}
}
function qn(e, t, n, r, i, a) {
	for (var o = e.data, s = 2 * a + 1, c = r - 1, l = i - 1, u = a + 1, d = u * (u + 1) / 2, f = new Jn(), p = f, m, h = 1; h < s; h++) p = p.next = new Jn(), h === u && (m = p);
	p.next = f;
	for (var g = null, _ = null, v = 0, y = 0, b = Un[a], x = Wn[a], S = 0; S < i; S++) {
		p = f;
		for (var C = o[y], w = o[y + 1], T = o[y + 2], E = o[y + 3], D = 0; D < u; D++) p.r = C, p.g = w, p.b = T, p.a = E, p = p.next;
		for (var O = 0, k = 0, A = 0, j = 0, M = u * C, N = u * w, P = u * T, F = u * E, I = d * C, L = d * w, R = d * T, z = d * E, ee = 1; ee < u; ee++) {
			var te = y + ((c < ee ? c : ee) << 2), ne = o[te], B = o[te + 1], re = o[te + 2], ie = o[te + 3], ae = u - ee;
			I += (p.r = ne) * ae, L += (p.g = B) * ae, R += (p.b = re) * ae, z += (p.a = ie) * ae, O += ne, k += B, A += re, j += ie, p = p.next;
		}
		g = f, _ = m;
		for (var oe = 0; oe < r; oe++) {
			var se = z * b >>> x;
			if (o[y + 3] = se, se !== 0) {
				var ce = 255 / se;
				o[y] = (I * b >>> x) * ce, o[y + 1] = (L * b >>> x) * ce, o[y + 2] = (R * b >>> x) * ce;
			} else o[y] = o[y + 1] = o[y + 2] = 0;
			I -= M, L -= N, R -= P, z -= F, M -= g.r, N -= g.g, P -= g.b, F -= g.a;
			var le = oe + a + 1;
			le = v + (le < c ? le : c) << 2, O += g.r = o[le], k += g.g = o[le + 1], A += g.b = o[le + 2], j += g.a = o[le + 3], I += O, L += k, R += A, z += j, g = g.next;
			var ue = _, de = ue.r, fe = ue.g, pe = ue.b, me = ue.a;
			M += de, N += fe, P += pe, F += me, O -= de, k -= fe, A -= pe, j -= me, _ = _.next, y += 4;
		}
		v += r;
	}
	for (var he = 0; he < r; he++) {
		y = he << 2;
		var V = o[y], ge = o[y + 1], _e = o[y + 2], H = o[y + 3], ve = u * V, ye = u * ge, be = u * _e, xe = u * H, Se = d * V, Ce = d * ge, U = d * _e, we = d * H;
		p = f;
		for (var Te = 0; Te < u; Te++) p.r = V, p.g = ge, p.b = _e, p.a = H, p = p.next;
		for (var Ee = r, De = 0, Oe = 0, ke = 0, Ae = 0, je = 1; je <= a; je++) {
			y = Ee + he << 2;
			var Me = u - je;
			Se += (p.r = V = o[y]) * Me, Ce += (p.g = ge = o[y + 1]) * Me, U += (p.b = _e = o[y + 2]) * Me, we += (p.a = H = o[y + 3]) * Me, Ae += V, De += ge, Oe += _e, ke += H, p = p.next, je < l && (Ee += r);
		}
		y = he, g = f, _ = m;
		for (var Ne = 0; Ne < i; Ne++) {
			var W = y << 2;
			o[W + 3] = H = we * b >>> x, H > 0 ? (H = 255 / H, o[W] = (Se * b >>> x) * H, o[W + 1] = (Ce * b >>> x) * H, o[W + 2] = (U * b >>> x) * H) : o[W] = o[W + 1] = o[W + 2] = 0, Se -= ve, Ce -= ye, U -= be, we -= xe, ve -= g.r, ye -= g.g, be -= g.b, xe -= g.a, W = he + ((W = Ne + u) < l ? W : l) * r << 2, Se += Ae += g.r = o[W], Ce += De += g.g = o[W + 1], U += Oe += g.b = o[W + 2], we += ke += g.a = o[W + 3], g = g.next, ve += V = _.r, ye += ge = _.g, be += _e = _.b, xe += H = _.a, Ae -= V, De -= ge, Oe -= _e, ke -= H, _ = _.next, y += r;
		}
	}
	return e;
}
var Jn = function e() {
	Hn(this, e), this.r = 0, this.g = 0, this.b = 0, this.a = 0, this.next = null;
};
//#endregion
//#region node_modules/canvg/lib/index.es.js
function Yn() {
	var { DOMParser: e } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, t = {
		window: null,
		ignoreAnimation: !0,
		ignoreMouse: !0,
		DOMParser: e,
		createCanvas(e, t) {
			return new OffscreenCanvas(e, t);
		},
		createImage(e) {
			return yt(function* () {
				var t = yield (yield fetch(e)).blob();
				return yield createImageBitmap(t);
			})();
		}
	};
	return (typeof DOMParser < "u" || e === void 0) && Reflect.deleteProperty(t, "DOMParser"), t;
}
function Xn(e) {
	var { DOMParser: t, canvas: n, fetch: r } = e;
	return {
		window: null,
		ignoreAnimation: !0,
		ignoreMouse: !0,
		DOMParser: t,
		fetch: r,
		createCanvas: n.createCanvas,
		createImage: n.loadImage
	};
}
var Zn = /*#__PURE__*/ Object.freeze({
	__proto__: null,
	offscreen: Yn,
	node: Xn
});
function Qn(e) {
	return e.replace(/(?!\u3000)\s+/gm, " ");
}
function $n(e) {
	return e.replace(/^[\n \t]+/, "");
}
function er(e) {
	return e.replace(/[\n \t]+$/, "");
}
function q(e) {
	return ((e || "").match(/-?(\d+(?:\.\d*(?:[eE][+-]?\d+)?)?|\.\d+)(?=\D|$)/gm) || []).map(parseFloat);
}
var tr = /^[A-Z-]+$/;
function nr(e) {
	return tr.test(e) ? e.toLowerCase() : e;
}
function rr(e) {
	var t = /url\(('([^']+)'|"([^"]+)"|([^'")]+))\)/.exec(e) || [];
	return t[2] || t[3] || t[4];
}
function ir(e) {
	if (!e.startsWith("rgb")) return e;
	var t = 3;
	return e.replace(/\d+(\.\d+)?/g, (e, n) => t-- && n ? String(Math.round(parseFloat(e))) : e);
}
var ar = /(\[[^\]]+\])/g, or = /(#[^\s+>~.[:]+)/g, sr = /(\.[^\s+>~.[:]+)/g, cr = /(::[^\s+>~.[:]+|:first-line|:first-letter|:before|:after)/gi, lr = /(:[\w-]+\([^)]*\))/gi, ur = /(:[^\s+>~.[:]+)/g, dr = /([^\s+>~.[:]+)/g;
function fr(e, t) {
	var n = t.exec(e);
	return n ? [e.replace(t, " "), n.length] : [e, 0];
}
function pr(e) {
	var t = [
		0,
		0,
		0
	], n = e.replace(/:not\(([^)]*)\)/g, "     $1 ").replace(/{[\s\S]*/gm, " "), r = 0;
	return [n, r] = fr(n, ar), t[1] += r, [n, r] = fr(n, or), t[0] += r, [n, r] = fr(n, sr), t[1] += r, [n, r] = fr(n, cr), t[2] += r, [n, r] = fr(n, lr), t[1] += r, [n, r] = fr(n, ur), t[1] += r, n = n.replace(/[*\s+>~]/g, " ").replace(/[#.]/g, " "), [n, r] = fr(n, dr), t[2] += r, t.join("");
}
var mr = 1e-8;
function hr(e) {
	return Math.sqrt(e[0] ** 2 + e[1] ** 2);
}
function gr(e, t) {
	return (e[0] * t[0] + e[1] * t[1]) / (hr(e) * hr(t));
}
function _r(e, t) {
	return (e[0] * t[1] < e[1] * t[0] ? -1 : 1) * Math.acos(gr(e, t));
}
function vr(e) {
	return e * e * e;
}
function yr(e) {
	return 3 * e * e * (1 - e);
}
function br(e) {
	return 3 * e * (1 - e) * (1 - e);
}
function xr(e) {
	return (1 - e) * (1 - e) * (1 - e);
}
function Sr(e) {
	return e * e;
}
function Cr(e) {
	return 2 * e * (1 - e);
}
function wr(e) {
	return (1 - e) * (1 - e);
}
var J = class e {
	constructor(e, t, n) {
		this.document = e, this.name = t, this.value = n, this.isNormalizedColor = !1;
	}
	static empty(t) {
		return new e(t, "EMPTY", "");
	}
	split() {
		var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : " ", { document: n, name: r } = this;
		return Qn(this.getString()).trim().split(t).map((t) => new e(n, r, t));
	}
	hasValue(e) {
		var { value: t } = this;
		return t !== null && t !== "" && (e || t !== 0) && t !== void 0;
	}
	isString(e) {
		var { value: t } = this, n = typeof t == "string";
		return !n || !e ? n : e.test(t);
	}
	isUrlDefinition() {
		return this.isString(/^url\(/);
	}
	isPixels() {
		if (!this.hasValue()) return !1;
		var e = this.getString();
		switch (!0) {
			case e.endsWith("px"):
			case /^[0-9]+$/.test(e): return !0;
			default: return !1;
		}
	}
	setValue(e) {
		return this.value = e, this;
	}
	getValue(e) {
		return e === void 0 || this.hasValue() ? this.value : e;
	}
	getNumber(e) {
		if (!this.hasValue()) return e === void 0 ? 0 : parseFloat(e);
		var { value: t } = this, n = parseFloat(t);
		return this.isString(/%$/) && (n /= 100), n;
	}
	getString(e) {
		return e === void 0 || this.hasValue() ? this.value === void 0 ? "" : String(this.value) : String(e);
	}
	getColor(e) {
		var t = this.getString(e);
		return this.isNormalizedColor ? t : (this.isNormalizedColor = !0, t = ir(t), this.value = t, t);
	}
	getDpi() {
		return 96;
	}
	getRem() {
		return this.document.rootEmSize;
	}
	getEm() {
		return this.document.emSize;
	}
	getUnits() {
		return this.getString().replace(/[0-9.-]/g, "");
	}
	getPixels(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
		if (!this.hasValue()) return 0;
		var [n, r] = typeof e == "boolean" ? [void 0, e] : [e], { viewPort: i } = this.document.screen;
		switch (!0) {
			case this.isString(/vmin$/): return this.getNumber() / 100 * Math.min(i.computeSize("x"), i.computeSize("y"));
			case this.isString(/vmax$/): return this.getNumber() / 100 * Math.max(i.computeSize("x"), i.computeSize("y"));
			case this.isString(/vw$/): return this.getNumber() / 100 * i.computeSize("x");
			case this.isString(/vh$/): return this.getNumber() / 100 * i.computeSize("y");
			case this.isString(/rem$/): return this.getNumber() * this.getRem();
			case this.isString(/em$/): return this.getNumber() * this.getEm();
			case this.isString(/ex$/): return this.getNumber() * this.getEm() / 2;
			case this.isString(/px$/): return this.getNumber();
			case this.isString(/pt$/): return this.getNumber() * this.getDpi() * (1 / 72);
			case this.isString(/pc$/): return this.getNumber() * 15;
			case this.isString(/cm$/): return this.getNumber() * this.getDpi() / 2.54;
			case this.isString(/mm$/): return this.getNumber() * this.getDpi() / 25.4;
			case this.isString(/in$/): return this.getNumber() * this.getDpi();
			case this.isString(/%$/) && r: return this.getNumber() * this.getEm();
			case this.isString(/%$/): return this.getNumber() * i.computeSize(n);
			default:
				var a = this.getNumber();
				return t && a < 1 ? a * i.computeSize(n) : a;
		}
	}
	getMilliseconds() {
		return this.hasValue() ? this.isString(/ms$/) ? this.getNumber() : this.getNumber() * 1e3 : 0;
	}
	getRadians() {
		if (!this.hasValue()) return 0;
		switch (!0) {
			case this.isString(/deg$/): return this.getNumber() * (Math.PI / 180);
			case this.isString(/grad$/): return this.getNumber() * (Math.PI / 200);
			case this.isString(/rad$/): return this.getNumber();
			default: return this.getNumber() * (Math.PI / 180);
		}
	}
	getDefinition() {
		var e = this.getString(), t = /#([^)'"]+)/.exec(e);
		return t &&= t[1], t ||= e, this.document.definitions[t];
	}
	getFillStyleDefinition(e, t) {
		var n = this.getDefinition();
		if (!n) return null;
		if (typeof n.createGradient == "function") return n.createGradient(this.document.ctx, e, t);
		if (typeof n.createPattern == "function") {
			if (n.getHrefAttribute().hasValue()) {
				var r = n.getAttribute("patternTransform");
				n = n.getHrefAttribute().getDefinition(), r.hasValue() && n.getAttribute("patternTransform", !0).setValue(r.value);
			}
			return n.createPattern(this.document.ctx, e, t);
		}
		return null;
	}
	getTextBaseline() {
		return this.hasValue() ? e.textBaselineMapping[this.getString()] : null;
	}
	addOpacity(t) {
		for (var n = this.getColor(), r = n.length, i = 0, a = 0; a < r && (n[a] === "," && i++, i !== 3); a++);
		if (t.hasValue() && this.isString() && i !== 3) {
			var o = new xn.default(n);
			o.ok && (o.alpha = t.getNumber(), n = o.toRGBA());
		}
		return new e(this.document, this.name, n);
	}
};
J.textBaselineMapping = {
	baseline: "alphabetic",
	"before-edge": "top",
	"text-before-edge": "top",
	middle: "middle",
	central: "middle",
	"after-edge": "bottom",
	"text-after-edge": "bottom",
	ideographic: "ideographic",
	alphabetic: "alphabetic",
	hanging: "hanging",
	mathematical: "alphabetic"
};
var Tr = class {
	constructor() {
		this.viewPorts = [];
	}
	clear() {
		this.viewPorts = [];
	}
	setCurrent(e, t) {
		this.viewPorts.push({
			width: e,
			height: t
		});
	}
	removeCurrent() {
		this.viewPorts.pop();
	}
	getCurrent() {
		var { viewPorts: e } = this;
		return e[e.length - 1];
	}
	get width() {
		return this.getCurrent().width;
	}
	get height() {
		return this.getCurrent().height;
	}
	computeSize(e) {
		return typeof e == "number" ? e : e === "x" ? this.width : e === "y" ? this.height : Math.sqrt(this.width ** 2 + this.height ** 2) / Math.sqrt(2);
	}
}, Y = class e {
	constructor(e, t) {
		this.x = e, this.y = t;
	}
	static parse(t) {
		var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, [r = n, i = n] = q(t);
		return new e(r, i);
	}
	static parseScale(t) {
		var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1, [r = n, i = r] = q(t);
		return new e(r, i);
	}
	static parsePath(t) {
		for (var n = q(t), r = n.length, i = [], a = 0; a < r; a += 2) i.push(new e(n[a], n[a + 1]));
		return i;
	}
	angleTo(e) {
		return Math.atan2(e.y - this.y, e.x - this.x);
	}
	applyTransform(e) {
		var { x: t, y: n } = this, r = t * e[0] + n * e[2] + e[4], i = t * e[1] + n * e[3] + e[5];
		this.x = r, this.y = i;
	}
}, Er = class {
	constructor(e) {
		this.screen = e, this.working = !1, this.events = [], this.eventElements = [], this.onClick = this.onClick.bind(this), this.onMouseMove = this.onMouseMove.bind(this);
	}
	isWorking() {
		return this.working;
	}
	start() {
		if (!this.working) {
			var { screen: e, onClick: t, onMouseMove: n } = this, r = e.ctx.canvas;
			r.onclick = t, r.onmousemove = n, this.working = !0;
		}
	}
	stop() {
		if (this.working) {
			var e = this.screen.ctx.canvas;
			this.working = !1, e.onclick = null, e.onmousemove = null;
		}
	}
	hasEvents() {
		return this.working && this.events.length > 0;
	}
	runEvents() {
		if (this.working) {
			var { screen: e, events: t, eventElements: n } = this, { style: r } = e.ctx.canvas;
			r && (r.cursor = ""), t.forEach((e, t) => {
				for (var { run: r } = e, i = n[t]; i;) r(i), i = i.parent;
			}), this.events = [], this.eventElements = [];
		}
	}
	checkPath(e, t) {
		if (!(!this.working || !t)) {
			var { events: n, eventElements: r } = this;
			n.forEach((n, i) => {
				var { x: a, y: o } = n;
				!r[i] && t.isPointInPath && t.isPointInPath(a, o) && (r[i] = e);
			});
		}
	}
	checkBoundingBox(e, t) {
		if (!(!this.working || !t)) {
			var { events: n, eventElements: r } = this;
			n.forEach((n, i) => {
				var { x: a, y: o } = n;
				!r[i] && t.isPointInBox(a, o) && (r[i] = e);
			});
		}
	}
	mapXY(e, t) {
		for (var { window: n, ctx: r } = this.screen, i = new Y(e, t), a = r.canvas; a;) i.x -= a.offsetLeft, i.y -= a.offsetTop, a = a.offsetParent;
		return n.scrollX && (i.x += n.scrollX), n.scrollY && (i.y += n.scrollY), i;
	}
	onClick(e) {
		var { x: t, y: n } = this.mapXY(e.clientX, e.clientY);
		this.events.push({
			type: "onclick",
			x: t,
			y: n,
			run(e) {
				e.onClick && e.onClick();
			}
		});
	}
	onMouseMove(e) {
		var { x: t, y: n } = this.mapXY(e.clientX, e.clientY);
		this.events.push({
			type: "onmousemove",
			x: t,
			y: n,
			run(e) {
				e.onMouseMove && e.onMouseMove();
			}
		});
	}
}, Dr = typeof window < "u" ? window : null, Or = typeof fetch < "u" ? fetch.bind(void 0) : null, kr = class {
	constructor(e) {
		var { fetch: t = Or, window: n = Dr } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		this.ctx = e, this.FRAMERATE = 30, this.MAX_VIRTUAL_PIXELS = 3e4, this.CLIENT_WIDTH = 800, this.CLIENT_HEIGHT = 600, this.viewPort = new Tr(), this.mouse = new Er(this), this.animations = [], this.waits = [], this.frameDuration = 0, this.isReadyLock = !1, this.isFirstRender = !0, this.intervalId = null, this.window = n, this.fetch = t;
	}
	wait(e) {
		this.waits.push(e);
	}
	ready() {
		return this.readyPromise ? this.readyPromise : Promise.resolve();
	}
	isReady() {
		if (this.isReadyLock) return !0;
		var e = this.waits.every((e) => e());
		return e && (this.waits = [], this.resolveReady && this.resolveReady()), this.isReadyLock = e, e;
	}
	setDefaults(e) {
		e.strokeStyle = "rgba(0,0,0,0)", e.lineCap = "butt", e.lineJoin = "miter", e.miterLimit = 4;
	}
	setViewBox(e) {
		var { document: t, ctx: n, aspectRatio: r, width: i, desiredWidth: a, height: o, desiredHeight: s, minX: c = 0, minY: l = 0, refX: u, refY: d, clip: f = !1, clipX: p = 0, clipY: m = 0 } = e, [h, g] = Qn(r).replace(/^defer\s/, "").split(" "), _ = h || "xMidYMid", v = g || "meet", y = i / a, b = o / s, x = Math.min(y, b), S = Math.max(y, b), C = a, w = s;
		v === "meet" && (C *= x, w *= x), v === "slice" && (C *= S, w *= S);
		var T = new J(t, "refX", u), E = new J(t, "refY", d), D = T.hasValue() && E.hasValue();
		if (D && n.translate(-x * T.getPixels("x"), -x * E.getPixels("y")), f) {
			var O = x * p, k = x * m;
			n.beginPath(), n.moveTo(O, k), n.lineTo(i, k), n.lineTo(i, o), n.lineTo(O, o), n.closePath(), n.clip();
		}
		if (!D) {
			var A = v === "meet" && x === b, j = v === "slice" && S === b, M = v === "meet" && x === y, N = v === "slice" && S === y;
			_.startsWith("xMid") && (A || j) && n.translate(i / 2 - C / 2, 0), _.endsWith("YMid") && (M || N) && n.translate(0, o / 2 - w / 2), _.startsWith("xMax") && (A || j) && n.translate(i - C, 0), _.endsWith("YMax") && (M || N) && n.translate(0, o - w);
		}
		switch (!0) {
			case _ === "none":
				n.scale(y, b);
				break;
			case v === "meet":
				n.scale(x, x);
				break;
			case v === "slice": n.scale(S, S);
		}
		n.translate(-c, -l);
	}
	start(e) {
		var { enableRedraw: t = !1, ignoreMouse: n = !1, ignoreAnimation: r = !1, ignoreDimensions: i = !1, ignoreClear: a = !1, forceRedraw: o, scaleWidth: s, scaleHeight: c, offsetX: l, offsetY: u } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, { FRAMERATE: d, mouse: f } = this, p = 1e3 / d;
		if (this.frameDuration = p, this.readyPromise = new Promise((e) => {
			this.resolveReady = e;
		}), this.isReady() && this.render(e, i, a, s, c, l, u), t) {
			var m = Date.now(), h = m, g = 0, _ = () => {
				m = Date.now(), g = m - h, g >= p && (h = m - g % p, this.shouldUpdate(r, o) && (this.render(e, i, a, s, c, l, u), f.runEvents())), this.intervalId = (0, bn.default)(_);
			};
			n || f.start(), this.intervalId = (0, bn.default)(_);
		}
	}
	stop() {
		this.intervalId &&= (bn.default.cancel(this.intervalId), null), this.mouse.stop();
	}
	shouldUpdate(e, t) {
		if (!e) {
			var { frameDuration: n } = this;
			if (this.animations.reduce((e, t) => t.update(n) || e, !1)) return !0;
		}
		return !!(typeof t == "function" && t() || !this.isReadyLock && this.isReady() || this.mouse.hasEvents());
	}
	render(e, t, n, r, i, a, o) {
		var { CLIENT_WIDTH: s, CLIENT_HEIGHT: c, viewPort: l, ctx: u, isFirstRender: d } = this, f = u.canvas;
		l.clear(), f.width && f.height ? l.setCurrent(f.width, f.height) : l.setCurrent(s, c);
		var p = e.getStyle("width"), m = e.getStyle("height");
		!t && (d || typeof r != "number" && typeof i != "number") && (p.hasValue() && (f.width = p.getPixels("x"), f.style && (f.style.width = `${f.width}px`)), m.hasValue() && (f.height = m.getPixels("y"), f.style && (f.style.height = `${f.height}px`)));
		var h = f.clientWidth || f.width, g = f.clientHeight || f.height;
		if (t && p.hasValue() && m.hasValue() && (h = p.getPixels("x"), g = m.getPixels("y")), l.setCurrent(h, g), typeof a == "number" && e.getAttribute("x", !0).setValue(a), typeof o == "number" && e.getAttribute("y", !0).setValue(o), typeof r == "number" || typeof i == "number") {
			var _ = q(e.getAttribute("viewBox").getString()), v = 0, y = 0;
			if (typeof r == "number") {
				var b = e.getStyle("width");
				b.hasValue() ? v = b.getPixels("x") / r : isNaN(_[2]) || (v = _[2] / r);
			}
			if (typeof i == "number") {
				var x = e.getStyle("height");
				x.hasValue() ? y = x.getPixels("y") / i : isNaN(_[3]) || (y = _[3] / i);
			}
			v ||= y, y ||= v, e.getAttribute("width", !0).setValue(r), e.getAttribute("height", !0).setValue(i);
			var S = e.getStyle("transform", !0, !0);
			S.setValue(`${S.getString()} scale(${1 / v}, ${1 / y})`);
		}
		n || u.clearRect(0, 0, h, g), e.render(u), d && (this.isFirstRender = !1);
	}
};
kr.defaultWindow = Dr, kr.defaultFetch = Or;
var { defaultFetch: Ar } = kr, jr = typeof DOMParser < "u" ? DOMParser : null, Mr = class {
	constructor() {
		var { fetch: e = Ar, DOMParser: t = jr } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		this.fetch = e, this.DOMParser = t;
	}
	parse(e) {
		var t = this;
		return yt(function* () {
			return e.startsWith("<") ? t.parseFromString(e) : t.load(e);
		})();
	}
	parseFromString(e) {
		var t = new this.DOMParser();
		try {
			return this.checkDocument(t.parseFromString(e, "image/svg+xml"));
		} catch {
			return this.checkDocument(t.parseFromString(e, "text/xml"));
		}
	}
	checkDocument(e) {
		var t = e.getElementsByTagName("parsererror")[0];
		if (t) throw Error(t.textContent);
		return e;
	}
	load(e) {
		var t = this;
		return yt(function* () {
			var n = yield (yield t.fetch(e)).text();
			return t.parseFromString(n);
		})();
	}
}, Nr = class {
	constructor(e, t) {
		this.type = "translate", this.point = null, this.point = Y.parse(t);
	}
	apply(e) {
		var { x: t, y: n } = this.point;
		e.translate(t || 0, n || 0);
	}
	unapply(e) {
		var { x: t, y: n } = this.point;
		e.translate(-1 * t || 0, -1 * n || 0);
	}
	applyToPoint(e) {
		var { x: t, y: n } = this.point;
		e.applyTransform([
			1,
			0,
			0,
			1,
			t || 0,
			n || 0
		]);
	}
}, Pr = class {
	constructor(e, t, n) {
		this.type = "rotate", this.angle = null, this.originX = null, this.originY = null, this.cx = 0, this.cy = 0;
		var r = q(t);
		this.angle = new J(e, "angle", r[0]), this.originX = n[0], this.originY = n[1], this.cx = r[1] || 0, this.cy = r[2] || 0;
	}
	apply(e) {
		var { cx: t, cy: n, originX: r, originY: i, angle: a } = this, o = t + r.getPixels("x"), s = n + i.getPixels("y");
		e.translate(o, s), e.rotate(a.getRadians()), e.translate(-o, -s);
	}
	unapply(e) {
		var { cx: t, cy: n, originX: r, originY: i, angle: a } = this, o = t + r.getPixels("x"), s = n + i.getPixels("y");
		e.translate(o, s), e.rotate(-1 * a.getRadians()), e.translate(-o, -s);
	}
	applyToPoint(e) {
		var { cx: t, cy: n, angle: r } = this, i = r.getRadians();
		e.applyTransform([
			1,
			0,
			0,
			1,
			t || 0,
			n || 0
		]), e.applyTransform([
			Math.cos(i),
			Math.sin(i),
			-Math.sin(i),
			Math.cos(i),
			0,
			0
		]), e.applyTransform([
			1,
			0,
			0,
			1,
			-t || 0,
			-n || 0
		]);
	}
}, Fr = class {
	constructor(e, t, n) {
		this.type = "scale", this.scale = null, this.originX = null, this.originY = null;
		var r = Y.parseScale(t);
		(r.x === 0 || r.y === 0) && (r.x = mr, r.y = mr), this.scale = r, this.originX = n[0], this.originY = n[1];
	}
	apply(e) {
		var { scale: { x: t, y: n }, originX: r, originY: i } = this, a = r.getPixels("x"), o = i.getPixels("y");
		e.translate(a, o), e.scale(t, n || t), e.translate(-a, -o);
	}
	unapply(e) {
		var { scale: { x: t, y: n }, originX: r, originY: i } = this, a = r.getPixels("x"), o = i.getPixels("y");
		e.translate(a, o), e.scale(1 / t, 1 / n || t), e.translate(-a, -o);
	}
	applyToPoint(e) {
		var { x: t, y: n } = this.scale;
		e.applyTransform([
			t || 0,
			0,
			0,
			n || 0,
			0,
			0
		]);
	}
}, Ir = class {
	constructor(e, t, n) {
		this.type = "matrix", this.matrix = [], this.originX = null, this.originY = null, this.matrix = q(t), this.originX = n[0], this.originY = n[1];
	}
	apply(e) {
		var { originX: t, originY: n, matrix: r } = this, i = t.getPixels("x"), a = n.getPixels("y");
		e.translate(i, a), e.transform(r[0], r[1], r[2], r[3], r[4], r[5]), e.translate(-i, -a);
	}
	unapply(e) {
		var { originX: t, originY: n, matrix: r } = this, i = r[0], a = r[2], o = r[4], s = r[1], c = r[3], l = r[5], u = 0, d = 0, f = 1, p = 1 / (i * (c * f - l * d) - a * (s * f - l * u) + o * (s * d - c * u)), m = t.getPixels("x"), h = n.getPixels("y");
		e.translate(m, h), e.transform(p * (c * f - l * d), p * (l * u - s * f), p * (o * d - a * f), p * (i * f - o * u), p * (a * l - o * c), p * (o * s - i * l)), e.translate(-m, -h);
	}
	applyToPoint(e) {
		e.applyTransform(this.matrix);
	}
}, Lr = class extends Ir {
	constructor(e, t, n) {
		super(e, t, n), this.type = "skew", this.angle = null, this.angle = new J(e, "angle", t);
	}
}, Rr = class extends Lr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "skewX", this.matrix = [
			1,
			0,
			Math.tan(this.angle.getRadians()),
			1,
			0,
			0
		];
	}
}, zr = class extends Lr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "skewY", this.matrix = [
			1,
			Math.tan(this.angle.getRadians()),
			0,
			1,
			0,
			0
		];
	}
};
function Br(e) {
	return Qn(e).trim().replace(/\)([a-zA-Z])/g, ") $1").replace(/\)(\s?,\s?)/g, ") ").split(/\s(?=[a-z])/);
}
function Vr(e) {
	var [t, n] = e.split("(");
	return [t.trim(), n.trim().replace(")", "")];
}
var Hr = class e {
	constructor(t, n, r) {
		this.document = t, this.transforms = [], Br(n).forEach((t) => {
			if (t !== "none") {
				var [n, i] = Vr(t), a = e.transformTypes[n];
				a !== void 0 && this.transforms.push(new a(this.document, i, r));
			}
		});
	}
	static fromElement(t, n) {
		var r = n.getStyle("transform", !1, !0), [i, a = i] = n.getStyle("transform-origin", !1, !0).split(), o = [i, a];
		return r.hasValue() ? new e(t, r.getString(), o) : null;
	}
	apply(e) {
		for (var { transforms: t } = this, n = t.length, r = 0; r < n; r++) t[r].apply(e);
	}
	unapply(e) {
		for (var { transforms: t } = this, n = t.length - 1; n >= 0; n--) t[n].unapply(e);
	}
	applyToPoint(e) {
		for (var { transforms: t } = this, n = t.length, r = 0; r < n; r++) t[r].applyToPoint(e);
	}
};
Hr.transformTypes = {
	translate: Nr,
	rotate: Pr,
	scale: Fr,
	matrix: Ir,
	skewX: Rr,
	skewY: zr
};
var X = class e {
	constructor(e, t) {
		var n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2];
		if (this.document = e, this.node = t, this.captureTextNodes = n, this.attributes = Object.create(null), this.styles = Object.create(null), this.stylesSpecificity = Object.create(null), this.animationFrozen = !1, this.animationFrozenValue = "", this.parent = null, this.children = [], !(!t || t.nodeType !== 1)) {
			Array.from(t.attributes).forEach((t) => {
				var n = nr(t.nodeName);
				this.attributes[n] = new J(e, n, t.value);
			}), this.addStylesFromStyleDefinition(), this.getAttribute("style").hasValue() && this.getAttribute("style").getString().split(";").map((e) => e.trim()).forEach((t) => {
				if (t) {
					var [n, r] = t.split(":").map((e) => e.trim());
					this.styles[n] = new J(e, n, r);
				}
			});
			var { definitions: r } = e, i = this.getAttribute("id");
			i.hasValue() && (r[i.getString()] || (r[i.getString()] = this)), Array.from(t.childNodes).forEach((t) => {
				if (t.nodeType === 1) this.addChild(t);
				else if (n && (t.nodeType === 3 || t.nodeType === 4)) {
					var r = e.createTextNode(t);
					r.getText().length > 0 && this.addChild(r);
				}
			});
		}
	}
	getAttribute(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], n = this.attributes[e];
		if (!n && t) {
			var r = new J(this.document, e, "");
			return this.attributes[e] = r, r;
		}
		return n || J.empty(this.document);
	}
	getHrefAttribute() {
		for (var e in this.attributes) if (e === "href" || e.endsWith(":href")) return this.attributes[e];
		return J.empty(this.document);
	}
	getStyle(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2], r = this.styles[e];
		if (r) return r;
		var i = this.getAttribute(e);
		if (i != null && i.hasValue()) return this.styles[e] = i, i;
		if (!n) {
			var { parent: a } = this;
			if (a) {
				var o = a.getStyle(e);
				if (o != null && o.hasValue()) return o;
			}
		}
		if (t) {
			var s = new J(this.document, e, "");
			return this.styles[e] = s, s;
		}
		return r || J.empty(this.document);
	}
	render(e) {
		if (this.getStyle("display").getString() !== "none" && this.getStyle("visibility").getString() !== "hidden") {
			if (e.save(), this.getStyle("mask").hasValue()) {
				var t = this.getStyle("mask").getDefinition();
				t && (this.applyEffects(e), t.apply(e, this));
			} else if (this.getStyle("filter").getValue("none") !== "none") {
				var n = this.getStyle("filter").getDefinition();
				n && (this.applyEffects(e), n.apply(e, this));
			} else this.setContext(e), this.renderChildren(e), this.clearContext(e);
			e.restore();
		}
	}
	setContext(e) {}
	applyEffects(e) {
		var t = Hr.fromElement(this.document, this);
		t && t.apply(e);
		var n = this.getStyle("clip-path", !1, !0);
		if (n.hasValue()) {
			var r = n.getDefinition();
			r && r.apply(e);
		}
	}
	clearContext(e) {}
	renderChildren(e) {
		this.children.forEach((t) => {
			t.render(e);
		});
	}
	addChild(t) {
		var n = t instanceof e ? t : this.document.createElement(t);
		n.parent = this, e.ignoreChildTypes.includes(n.type) || this.children.push(n);
	}
	matchesSelector(e) {
		var { node: t } = this;
		if (typeof t.matches == "function") return t.matches(e);
		var n = t.getAttribute?.call(t, "class");
		return !n || n === "" ? !1 : n.split(" ").some((t) => `.${t}` === e);
	}
	addStylesFromStyleDefinition() {
		var { styles: e, stylesSpecificity: t } = this.document;
		for (var n in e) if (!n.startsWith("@") && this.matchesSelector(n)) {
			var r = e[n], i = t[n];
			if (r) for (var a in r) {
				var o = this.stylesSpecificity[a];
				o === void 0 && (o = "000"), i >= o && (this.styles[a] = r[a], this.stylesSpecificity[a] = i);
			}
		}
	}
	removeStyles(e, t) {
		return t.reduce((t, n) => {
			var r = e.getStyle(n);
			if (!r.hasValue()) return t;
			var i = r.getString();
			return r.setValue(""), [...t, [n, i]];
		}, []);
	}
	restoreStyles(e, t) {
		t.forEach((t) => {
			var [n, r] = t;
			e.getStyle(n, !0).setValue(r);
		});
	}
	isFirstChild() {
		return this.parent?.children.indexOf(this) === 0;
	}
};
X.ignoreChildTypes = ["title"];
var Ur = class extends X {
	constructor(e, t, n) {
		super(e, t, n);
	}
};
function Wr(e) {
	var t = e.trim();
	return /^('|")/.test(t) ? t : `"${t}"`;
}
function Gr(e) {
	return typeof process > "u" ? e : e.trim().split(",").map(Wr).join(",");
}
function Kr(e) {
	if (!e) return "";
	var t = e.trim().toLowerCase();
	switch (t) {
		case "normal":
		case "italic":
		case "oblique":
		case "inherit":
		case "initial":
		case "unset": return t;
		default: return /^oblique\s+(-|)\d+deg$/.test(t) ? t : "";
	}
}
function qr(e) {
	if (!e) return "";
	var t = e.trim().toLowerCase();
	switch (t) {
		case "normal":
		case "bold":
		case "lighter":
		case "bolder":
		case "inherit":
		case "initial":
		case "unset": return t;
		default: return /^[\d.]+$/.test(t) ? t : "";
	}
}
var Jr = class e {
	constructor(t, n, r, i, a, o) {
		var s = o ? typeof o == "string" ? e.parse(o) : o : {};
		this.fontFamily = a || s.fontFamily, this.fontSize = i || s.fontSize, this.fontStyle = t || s.fontStyle, this.fontWeight = r || s.fontWeight, this.fontVariant = n || s.fontVariant;
	}
	static parse() {
		var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", n = arguments.length > 1 ? arguments[1] : void 0, r = "", i = "", a = "", o = "", s = "", c = Qn(t).trim().split(" "), l = {
			fontSize: !1,
			fontStyle: !1,
			fontWeight: !1,
			fontVariant: !1
		};
		return c.forEach((t) => {
			switch (!0) {
				case !l.fontStyle && e.styles.includes(t):
					t !== "inherit" && (r = t), l.fontStyle = !0;
					break;
				case !l.fontVariant && e.variants.includes(t):
					t !== "inherit" && (i = t), l.fontStyle = !0, l.fontVariant = !0;
					break;
				case !l.fontWeight && e.weights.includes(t):
					t !== "inherit" && (a = t), l.fontStyle = !0, l.fontVariant = !0, l.fontWeight = !0;
					break;
				case !l.fontSize:
					t !== "inherit" && ([o] = t.split("/")), l.fontStyle = !0, l.fontVariant = !0, l.fontWeight = !0, l.fontSize = !0;
					break;
				default: t !== "inherit" && (s += t);
			}
		}), new e(r, i, a, o, s, n);
	}
	toString() {
		return [
			Kr(this.fontStyle),
			this.fontVariant,
			qr(this.fontWeight),
			this.fontSize,
			Gr(this.fontFamily)
		].join(" ").trim();
	}
};
Jr.styles = "normal|italic|oblique|inherit", Jr.variants = "normal|small-caps|inherit", Jr.weights = "normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900|inherit";
var Yr = class {
	constructor() {
		var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : NaN, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : NaN, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : NaN, r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : NaN;
		this.x1 = e, this.y1 = t, this.x2 = n, this.y2 = r, this.addPoint(e, t), this.addPoint(n, r);
	}
	get x() {
		return this.x1;
	}
	get y() {
		return this.y1;
	}
	get width() {
		return this.x2 - this.x1;
	}
	get height() {
		return this.y2 - this.y1;
	}
	addPoint(e, t) {
		e !== void 0 && ((isNaN(this.x1) || isNaN(this.x2)) && (this.x1 = e, this.x2 = e), e < this.x1 && (this.x1 = e), e > this.x2 && (this.x2 = e)), t !== void 0 && ((isNaN(this.y1) || isNaN(this.y2)) && (this.y1 = t, this.y2 = t), t < this.y1 && (this.y1 = t), t > this.y2 && (this.y2 = t));
	}
	addX(e) {
		this.addPoint(e, null);
	}
	addY(e) {
		this.addPoint(null, e);
	}
	addBoundingBox(e) {
		if (e) {
			var { x1: t, y1: n, x2: r, y2: i } = e;
			this.addPoint(t, n), this.addPoint(r, i);
		}
	}
	sumCubic(e, t, n, r, i) {
		return (1 - e) ** 3 * t + 3 * (1 - e) ** 2 * e * n + 3 * (1 - e) * e ** 2 * r + e ** 3 * i;
	}
	bezierCurveAdd(e, t, n, r, i) {
		var a = 6 * t - 12 * n + 6 * r, o = -3 * t + 9 * n - 9 * r + 3 * i, s = 3 * n - 3 * t;
		if (o === 0) {
			if (a === 0) return;
			var c = -s / a;
			0 < c && c < 1 && (e ? this.addX(this.sumCubic(c, t, n, r, i)) : this.addY(this.sumCubic(c, t, n, r, i)));
			return;
		}
		var l = a ** 2 - 4 * s * o;
		if (!(l < 0)) {
			var u = (-a + Math.sqrt(l)) / (2 * o);
			0 < u && u < 1 && (e ? this.addX(this.sumCubic(u, t, n, r, i)) : this.addY(this.sumCubic(u, t, n, r, i)));
			var d = (-a - Math.sqrt(l)) / (2 * o);
			0 < d && d < 1 && (e ? this.addX(this.sumCubic(d, t, n, r, i)) : this.addY(this.sumCubic(d, t, n, r, i)));
		}
	}
	addBezierCurve(e, t, n, r, i, a, o, s) {
		this.addPoint(e, t), this.addPoint(o, s), this.bezierCurveAdd(!0, e, n, i, o), this.bezierCurveAdd(!1, t, r, a, s);
	}
	addQuadraticCurve(e, t, n, r, i, a) {
		var o = e + 2 / 3 * (n - e), s = t + 2 / 3 * (r - t), c = o + 1 / 3 * (i - e), l = s + 1 / 3 * (a - t);
		this.addBezierCurve(e, t, o, c, s, l, i, a);
	}
	isPointInBox(e, t) {
		var { x1: n, y1: r, x2: i, y2: a } = this;
		return n <= e && e <= i && r <= t && t <= a;
	}
}, Z = class extends K {
	constructor(e) {
		super(e.replace(/([+\-.])\s+/gm, "$1").replace(/[^MmZzLlHhVvCcSsQqTtAae\d\s.,+-].*/g, "")), this.control = null, this.start = null, this.current = null, this.command = null, this.commands = this.commands, this.i = -1, this.previousCommand = null, this.points = [], this.angles = [];
	}
	reset() {
		this.i = -1, this.command = null, this.previousCommand = null, this.start = new Y(0, 0), this.control = new Y(0, 0), this.current = new Y(0, 0), this.points = [], this.angles = [];
	}
	isEnd() {
		var { i: e, commands: t } = this;
		return e >= t.length - 1;
	}
	next() {
		var e = this.commands[++this.i];
		return this.previousCommand = this.command, this.command = e, e;
	}
	getPoint() {
		var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "x", t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "y", n = new Y(this.command[e], this.command[t]);
		return this.makeAbsolute(n);
	}
	getAsControlPoint(e, t) {
		var n = this.getPoint(e, t);
		return this.control = n, n;
	}
	getAsCurrentPoint(e, t) {
		var n = this.getPoint(e, t);
		return this.current = n, n;
	}
	getReflectedControlPoint() {
		var e = this.previousCommand.type;
		if (e !== K.CURVE_TO && e !== K.SMOOTH_CURVE_TO && e !== K.QUAD_TO && e !== K.SMOOTH_QUAD_TO) return this.current;
		var { current: { x: t, y: n }, control: { x: r, y: i } } = this;
		return new Y(2 * t - r, 2 * n - i);
	}
	makeAbsolute(e) {
		if (this.command.relative) {
			var { x: t, y: n } = this.current;
			e.x += t, e.y += n;
		}
		return e;
	}
	addMarker(e, t, n) {
		var { points: r, angles: i } = this;
		n && i.length > 0 && !i[i.length - 1] && (i[i.length - 1] = r[r.length - 1].angleTo(n)), this.addMarkerAngle(e, t ? t.angleTo(e) : null);
	}
	addMarkerAngle(e, t) {
		this.points.push(e), this.angles.push(t);
	}
	getMarkerPoints() {
		return this.points;
	}
	getMarkerAngles() {
		for (var { angles: e } = this, t = e.length, n = 0; n < t; n++) if (!e[n]) {
			for (var r = n + 1; r < t; r++) if (e[r]) {
				e[n] = e[r];
				break;
			}
		}
		return e;
	}
}, Xr = class extends X {
	constructor() {
		super(...arguments), this.modifiedEmSizeStack = !1;
	}
	calculateOpacity() {
		for (var e = 1, t = this; t;) {
			var n = t.getStyle("opacity", !1, !0);
			n.hasValue(!0) && (e *= n.getNumber()), t = t.parent;
		}
		return e;
	}
	setContext(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
		if (!t) {
			var n = this.getStyle("fill"), r = this.getStyle("fill-opacity"), i = this.getStyle("stroke"), a = this.getStyle("stroke-opacity");
			if (n.isUrlDefinition()) {
				var o = n.getFillStyleDefinition(this, r);
				o && (e.fillStyle = o);
			} else if (n.hasValue()) {
				n.getString() === "currentColor" && n.setValue(this.getStyle("color").getColor());
				var s = n.getColor();
				s !== "inherit" && (e.fillStyle = s === "none" ? "rgba(0,0,0,0)" : s);
			}
			if (r.hasValue() && (e.fillStyle = new J(this.document, "fill", e.fillStyle).addOpacity(r).getColor()), i.isUrlDefinition()) {
				var c = i.getFillStyleDefinition(this, a);
				c && (e.strokeStyle = c);
			} else if (i.hasValue()) {
				i.getString() === "currentColor" && i.setValue(this.getStyle("color").getColor());
				var l = i.getString();
				l !== "inherit" && (e.strokeStyle = l === "none" ? "rgba(0,0,0,0)" : l);
			}
			a.hasValue() && (e.strokeStyle = new J(this.document, "stroke", e.strokeStyle).addOpacity(a).getString());
			var u = this.getStyle("stroke-width");
			u.hasValue() && (e.lineWidth = u.getPixels() || mr);
			var d = this.getStyle("stroke-linecap"), f = this.getStyle("stroke-linejoin"), p = this.getStyle("stroke-miterlimit"), m = this.getStyle("stroke-dasharray"), h = this.getStyle("stroke-dashoffset");
			if (d.hasValue() && (e.lineCap = d.getString()), f.hasValue() && (e.lineJoin = f.getString()), p.hasValue() && (e.miterLimit = p.getNumber()), m.hasValue() && m.getString() !== "none") {
				var g = q(m.getString());
				e.setLineDash === void 0 ? e.webkitLineDash === void 0 ? e.mozDash !== void 0 && (g.length !== 1 || g[0] !== 0) && (e.mozDash = g) : e.webkitLineDash = g : e.setLineDash(g);
				var _ = h.getPixels();
				e.lineDashOffset === void 0 ? e.webkitLineDashOffset === void 0 ? e.mozDashOffset !== void 0 && (e.mozDashOffset = _) : e.webkitLineDashOffset = _ : e.lineDashOffset = _;
			}
		}
		if (this.modifiedEmSizeStack = !1, e.font !== void 0) {
			var v = this.getStyle("font"), y = this.getStyle("font-style"), b = this.getStyle("font-variant"), x = this.getStyle("font-weight"), S = this.getStyle("font-size"), C = this.getStyle("font-family"), w = new Jr(y.getString(), b.getString(), x.getString(), S.hasValue() ? `${S.getPixels(!0)}px` : "", C.getString(), Jr.parse(v.getString(), e.font));
			y.setValue(w.fontStyle), b.setValue(w.fontVariant), x.setValue(w.fontWeight), S.setValue(w.fontSize), C.setValue(w.fontFamily), e.font = w.toString(), S.isPixels() && (this.document.emSize = S.getPixels(), this.modifiedEmSizeStack = !0);
		}
		t || (this.applyEffects(e), e.globalAlpha = this.calculateOpacity());
	}
	clearContext(e) {
		super.clearContext(e), this.modifiedEmSizeStack && this.document.popEmSize();
	}
}, Q = class e extends Xr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "path", this.pathParser = null, this.pathParser = new Z(this.getAttribute("d").getString());
	}
	path(e) {
		var { pathParser: t } = this, n = new Yr();
		for (t.reset(), e && e.beginPath(); !t.isEnd();) switch (t.next().type) {
			case Z.MOVE_TO:
				this.pathM(e, n);
				break;
			case Z.LINE_TO:
				this.pathL(e, n);
				break;
			case Z.HORIZ_LINE_TO:
				this.pathH(e, n);
				break;
			case Z.VERT_LINE_TO:
				this.pathV(e, n);
				break;
			case Z.CURVE_TO:
				this.pathC(e, n);
				break;
			case Z.SMOOTH_CURVE_TO:
				this.pathS(e, n);
				break;
			case Z.QUAD_TO:
				this.pathQ(e, n);
				break;
			case Z.SMOOTH_QUAD_TO:
				this.pathT(e, n);
				break;
			case Z.ARC:
				this.pathA(e, n);
				break;
			case Z.CLOSE_PATH: this.pathZ(e, n);
		}
		return n;
	}
	getBoundingBox(e) {
		return this.path();
	}
	getMarkers() {
		var { pathParser: e } = this, t = e.getMarkerPoints(), n = e.getMarkerAngles();
		return t.map((e, t) => [e, n[t]]);
	}
	renderChildren(e) {
		this.path(e), this.document.screen.mouse.checkPath(this, e);
		var t = this.getStyle("fill-rule");
		e.fillStyle !== "" && (t.getString("inherit") === "inherit" ? e.fill() : e.fill(t.getString())), e.strokeStyle !== "" && (this.getAttribute("vector-effect").getString() === "non-scaling-stroke" ? (e.save(), e.setTransform(1, 0, 0, 1, 0, 0), e.stroke(), e.restore()) : e.stroke());
		var n = this.getMarkers();
		if (n) {
			var r = n.length - 1, i = this.getStyle("marker-start"), a = this.getStyle("marker-mid"), o = this.getStyle("marker-end");
			if (i.isUrlDefinition()) {
				var s = i.getDefinition(), [c, l] = n[0];
				s.render(e, c, l);
			}
			if (a.isUrlDefinition()) for (var u = a.getDefinition(), d = 1; d < r; d++) {
				var [f, p] = n[d];
				u.render(e, f, p);
			}
			if (o.isUrlDefinition()) {
				var m = o.getDefinition(), [h, g] = n[r];
				m.render(e, h, g);
			}
		}
	}
	static pathM(e) {
		var t = e.getAsCurrentPoint();
		return e.start = e.current, { point: t };
	}
	pathM(t, n) {
		var { pathParser: r } = this, { point: i } = e.pathM(r), { x: a, y: o } = i;
		r.addMarker(i), n.addPoint(a, o), t && t.moveTo(a, o);
	}
	static pathL(e) {
		var { current: t } = e;
		return {
			current: t,
			point: e.getAsCurrentPoint()
		};
	}
	pathL(t, n) {
		var { pathParser: r } = this, { current: i, point: a } = e.pathL(r), { x: o, y: s } = a;
		r.addMarker(a, i), n.addPoint(o, s), t && t.lineTo(o, s);
	}
	static pathH(e) {
		var { current: t, command: n } = e, r = new Y((n.relative ? t.x : 0) + n.x, t.y);
		return e.current = r, {
			current: t,
			point: r
		};
	}
	pathH(t, n) {
		var { pathParser: r } = this, { current: i, point: a } = e.pathH(r), { x: o, y: s } = a;
		r.addMarker(a, i), n.addPoint(o, s), t && t.lineTo(o, s);
	}
	static pathV(e) {
		var { current: t, command: n } = e, r = new Y(t.x, (n.relative ? t.y : 0) + n.y);
		return e.current = r, {
			current: t,
			point: r
		};
	}
	pathV(t, n) {
		var { pathParser: r } = this, { current: i, point: a } = e.pathV(r), { x: o, y: s } = a;
		r.addMarker(a, i), n.addPoint(o, s), t && t.lineTo(o, s);
	}
	static pathC(e) {
		var { current: t } = e;
		return {
			current: t,
			point: e.getPoint("x1", "y1"),
			controlPoint: e.getAsControlPoint("x2", "y2"),
			currentPoint: e.getAsCurrentPoint()
		};
	}
	pathC(t, n) {
		var { pathParser: r } = this, { current: i, point: a, controlPoint: o, currentPoint: s } = e.pathC(r);
		r.addMarker(s, o, a), n.addBezierCurve(i.x, i.y, a.x, a.y, o.x, o.y, s.x, s.y), t && t.bezierCurveTo(a.x, a.y, o.x, o.y, s.x, s.y);
	}
	static pathS(e) {
		var { current: t } = e;
		return {
			current: t,
			point: e.getReflectedControlPoint(),
			controlPoint: e.getAsControlPoint("x2", "y2"),
			currentPoint: e.getAsCurrentPoint()
		};
	}
	pathS(t, n) {
		var { pathParser: r } = this, { current: i, point: a, controlPoint: o, currentPoint: s } = e.pathS(r);
		r.addMarker(s, o, a), n.addBezierCurve(i.x, i.y, a.x, a.y, o.x, o.y, s.x, s.y), t && t.bezierCurveTo(a.x, a.y, o.x, o.y, s.x, s.y);
	}
	static pathQ(e) {
		var { current: t } = e;
		return {
			current: t,
			controlPoint: e.getAsControlPoint("x1", "y1"),
			currentPoint: e.getAsCurrentPoint()
		};
	}
	pathQ(t, n) {
		var { pathParser: r } = this, { current: i, controlPoint: a, currentPoint: o } = e.pathQ(r);
		r.addMarker(o, a, a), n.addQuadraticCurve(i.x, i.y, a.x, a.y, o.x, o.y), t && t.quadraticCurveTo(a.x, a.y, o.x, o.y);
	}
	static pathT(e) {
		var { current: t } = e, n = e.getReflectedControlPoint();
		return e.control = n, {
			current: t,
			controlPoint: n,
			currentPoint: e.getAsCurrentPoint()
		};
	}
	pathT(t, n) {
		var { pathParser: r } = this, { current: i, controlPoint: a, currentPoint: o } = e.pathT(r);
		r.addMarker(o, a, a), n.addQuadraticCurve(i.x, i.y, a.x, a.y, o.x, o.y), t && t.quadraticCurveTo(a.x, a.y, o.x, o.y);
	}
	static pathA(e) {
		var { current: t, command: n } = e, { rX: r, rY: i, xRot: a, lArcFlag: o, sweepFlag: s } = n, c = Math.PI / 180 * a, l = e.getAsCurrentPoint(), u = new Y(Math.cos(c) * (t.x - l.x) / 2 + Math.sin(c) * (t.y - l.y) / 2, -Math.sin(c) * (t.x - l.x) / 2 + Math.cos(c) * (t.y - l.y) / 2), d = u.x ** 2 / r ** 2 + u.y ** 2 / i ** 2;
		d > 1 && (r *= Math.sqrt(d), i *= Math.sqrt(d));
		var f = (o === s ? -1 : 1) * Math.sqrt((r ** 2 * i ** 2 - r ** 2 * u.y ** 2 - i ** 2 * u.x ** 2) / (r ** 2 * u.y ** 2 + i ** 2 * u.x ** 2));
		isNaN(f) && (f = 0);
		var p = new Y(f * r * u.y / i, f * -i * u.x / r), m = new Y((t.x + l.x) / 2 + Math.cos(c) * p.x - Math.sin(c) * p.y, (t.y + l.y) / 2 + Math.sin(c) * p.x + Math.cos(c) * p.y), h = _r([1, 0], [(u.x - p.x) / r, (u.y - p.y) / i]), g = [(u.x - p.x) / r, (u.y - p.y) / i], _ = [(-u.x - p.x) / r, (-u.y - p.y) / i], v = _r(g, _);
		return gr(g, _) <= -1 && (v = Math.PI), gr(g, _) >= 1 && (v = 0), {
			currentPoint: l,
			rX: r,
			rY: i,
			sweepFlag: s,
			xAxisRotation: c,
			centp: m,
			a1: h,
			ad: v
		};
	}
	pathA(t, n) {
		var { pathParser: r } = this, { currentPoint: i, rX: a, rY: o, sweepFlag: s, xAxisRotation: c, centp: l, a1: u, ad: d } = e.pathA(r), f = 1 - s ? 1 : -1, p = u + d / 2 * f, m = new Y(l.x + a * Math.cos(p), l.y + o * Math.sin(p));
		if (r.addMarkerAngle(m, p - f * Math.PI / 2), r.addMarkerAngle(i, p - f * Math.PI), n.addPoint(i.x, i.y), t && !isNaN(u) && !isNaN(d)) {
			var h = a > o ? a : o, g = a > o ? 1 : a / o, _ = a > o ? o / a : 1;
			t.translate(l.x, l.y), t.rotate(c), t.scale(g, _), t.arc(0, 0, h, u, u + d, !!(1 - s)), t.scale(1 / g, 1 / _), t.rotate(-c), t.translate(-l.x, -l.y);
		}
	}
	static pathZ(e) {
		e.current = e.start;
	}
	pathZ(t, n) {
		e.pathZ(this.pathParser), t && n.x1 !== n.x2 && n.y1 !== n.y2 && t.closePath();
	}
}, Zr = class extends Q {
	constructor(e, t, n) {
		super(e, t, n), this.type = "glyph", this.horizAdvX = this.getAttribute("horiz-adv-x").getNumber(), this.unicode = this.getAttribute("unicode").getString(), this.arabicForm = this.getAttribute("arabic-form").getString();
	}
}, Qr = class e extends Xr {
	constructor(t, n, r) {
		super(t, n, new.target === e || r), this.type = "text", this.x = 0, this.y = 0, this.measureCache = -1;
	}
	setContext(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
		super.setContext(e, t);
		var n = this.getStyle("dominant-baseline").getTextBaseline() || this.getStyle("alignment-baseline").getTextBaseline();
		n && (e.textBaseline = n);
	}
	initializeCoordinates() {
		this.x = 0, this.y = 0, this.leafTexts = [], this.textChunkStart = 0, this.minX = Infinity, this.maxX = -Infinity;
	}
	getBoundingBox(e) {
		if (this.type !== "text") return this.getTElementBoundingBox(e);
		this.initializeCoordinates(), this.adjustChildCoordinatesRecursive(e);
		var t = null;
		return this.children.forEach((n, r) => {
			var i = this.getChildBoundingBox(e, this, this, r);
			t ? t.addBoundingBox(i) : t = i;
		}), t;
	}
	getFontSize() {
		var { document: e, parent: t } = this, n = Jr.parse(e.ctx.font).fontSize;
		return t.getStyle("font-size").getNumber(n);
	}
	getTElementBoundingBox(e) {
		var t = this.getFontSize();
		return new Yr(this.x, this.y - t, this.x + this.measureText(e), this.y);
	}
	getGlyph(e, t, n) {
		var r = t[n], i = null;
		if (e.isArabic) {
			var a = t.length, o = t[n - 1], s = t[n + 1], c = "isolated";
			if ((n === 0 || o === " ") && n < a - 1 && s !== " " && (c = "terminal"), n > 0 && o !== " " && n < a - 1 && s !== " " && (c = "medial"), n > 0 && o !== " " && (n === a - 1 || s === " ") && (c = "initial"), e.glyphs[r] !== void 0) {
				var l = e.glyphs[r];
				i = l instanceof Zr ? l : l[c];
			}
		} else i = e.glyphs[r];
		return i ||= e.missingGlyph, i;
	}
	getText() {
		return "";
	}
	getTextFromNode(e) {
		var t = e || this.node, n = Array.from(t.parentNode.childNodes), r = n.indexOf(t), i = n.length - 1, a = Qn(t.textContent || "");
		return r === 0 && (a = $n(a)), r === i && (a = er(a)), a;
	}
	renderChildren(e) {
		if (this.type !== "text") {
			this.renderTElementChildren(e);
			return;
		}
		this.initializeCoordinates(), this.adjustChildCoordinatesRecursive(e), this.children.forEach((t, n) => {
			this.renderChild(e, this, this, n);
		});
		var { mouse: t } = this.document.screen;
		t.isWorking() && t.checkBoundingBox(this, this.getBoundingBox(e));
	}
	renderTElementChildren(e) {
		var { document: t, parent: n } = this, r = this.getText(), i = n.getStyle("font-family").getDefinition();
		if (i) {
			for (var { unitsPerEm: a } = i.fontFace, o = Jr.parse(t.ctx.font), s = n.getStyle("font-size").getNumber(o.fontSize), c = n.getStyle("font-style").getString(o.fontStyle), l = s / a, u = i.isRTL ? r.split("").reverse().join("") : r, d = q(n.getAttribute("dx").getString()), f = u.length, p = 0; p < f; p++) {
				var m = this.getGlyph(i, u, p);
				e.translate(this.x, this.y), e.scale(l, -l);
				var h = e.lineWidth;
				e.lineWidth = e.lineWidth * a / s, c === "italic" && e.transform(1, 0, .4, 1, 0, 0), m.render(e), c === "italic" && e.transform(1, 0, -.4, 1, 0, 0), e.lineWidth = h, e.scale(1 / l, -1 / l), e.translate(-this.x, -this.y), this.x += s * (m.horizAdvX || i.horizAdvX) / a, d[p] !== void 0 && !isNaN(d[p]) && (this.x += d[p]);
			}
			return;
		}
		var { x: g, y: _ } = this;
		e.fillStyle && e.fillText(r, g, _), e.strokeStyle && e.strokeText(r, g, _);
	}
	applyAnchoring() {
		if (!(this.textChunkStart >= this.leafTexts.length)) {
			var e = this.leafTexts[this.textChunkStart], t = e.getStyle("text-anchor").getString("start"), n = 0;
			n = t === "start" ? e.x - this.minX : t === "end" ? e.x - this.maxX : e.x - (this.minX + this.maxX) / 2;
			for (var r = this.textChunkStart; r < this.leafTexts.length; r++) this.leafTexts[r].x += n;
			this.minX = Infinity, this.maxX = -Infinity, this.textChunkStart = this.leafTexts.length;
		}
	}
	adjustChildCoordinatesRecursive(e) {
		this.children.forEach((t, n) => {
			this.adjustChildCoordinatesRecursiveCore(e, this, this, n);
		}), this.applyAnchoring();
	}
	adjustChildCoordinatesRecursiveCore(e, t, n, r) {
		var i = n.children[r];
		i.children.length > 0 ? i.children.forEach((n, r) => {
			t.adjustChildCoordinatesRecursiveCore(e, t, i, r);
		}) : this.adjustChildCoordinates(e, t, n, r);
	}
	adjustChildCoordinates(e, t, n, r) {
		var i = n.children[r];
		if (typeof i.measureText != "function") return i;
		e.save(), i.setContext(e, !0);
		var a = i.getAttribute("x"), o = i.getAttribute("y"), s = i.getAttribute("dx"), c = i.getAttribute("dy"), l = i.getStyle("font-family").getDefinition(), u = !!l && l.isRTL;
		r === 0 && (a.hasValue() || a.setValue(i.getInheritedAttribute("x")), o.hasValue() || o.setValue(i.getInheritedAttribute("y")), s.hasValue() || s.setValue(i.getInheritedAttribute("dx")), c.hasValue() || c.setValue(i.getInheritedAttribute("dy")));
		var d = i.measureText(e);
		return u && (t.x -= d), a.hasValue() ? (t.applyAnchoring(), i.x = a.getPixels("x"), s.hasValue() && (i.x += s.getPixels("x"))) : (s.hasValue() && (t.x += s.getPixels("x")), i.x = t.x), t.x = i.x, u || (t.x += d), o.hasValue() ? (i.y = o.getPixels("y"), c.hasValue() && (i.y += c.getPixels("y"))) : (c.hasValue() && (t.y += c.getPixels("y")), i.y = t.y), t.y = i.y, t.leafTexts.push(i), t.minX = Math.min(t.minX, i.x, i.x + d), t.maxX = Math.max(t.maxX, i.x, i.x + d), i.clearContext(e), e.restore(), i;
	}
	getChildBoundingBox(e, t, n, r) {
		var i = n.children[r];
		if (typeof i.getBoundingBox != "function") return null;
		var a = i.getBoundingBox(e);
		return a ? (i.children.forEach((n, r) => {
			var o = t.getChildBoundingBox(e, t, i, r);
			a.addBoundingBox(o);
		}), a) : null;
	}
	renderChild(e, t, n, r) {
		var i = n.children[r];
		i.render(e), i.children.forEach((n, r) => {
			t.renderChild(e, t, i, r);
		});
	}
	measureText(e) {
		var { measureCache: t } = this;
		if (~t) return t;
		var n = this.getText(), r = this.measureTargetText(e, n);
		return this.measureCache = r, r;
	}
	measureTargetText(e, t) {
		if (!t.length) return 0;
		var { parent: n } = this, r = n.getStyle("font-family").getDefinition();
		if (r) {
			for (var i = this.getFontSize(), a = r.isRTL ? t.split("").reverse().join("") : t, o = q(n.getAttribute("dx").getString()), s = a.length, c = 0, l = 0; l < s; l++) {
				var u = this.getGlyph(r, a, l);
				c += (u.horizAdvX || r.horizAdvX) * i / r.fontFace.unitsPerEm, o[l] !== void 0 && !isNaN(o[l]) && (c += o[l]);
			}
			return c;
		}
		if (!e.measureText) return t.length * 10;
		e.save(), this.setContext(e, !0);
		var { width: d } = e.measureText(t);
		return this.clearContext(e), e.restore(), d;
	}
	getInheritedAttribute(t) {
		for (var n = this; n instanceof e && n.isFirstChild();) {
			var r = n.parent.getAttribute(t);
			if (r.hasValue(!0)) return r.getValue("0");
			n = n.parent;
		}
		return null;
	}
}, $r = class e extends Qr {
	constructor(t, n, r) {
		super(t, n, new.target === e || r), this.type = "tspan", this.text = this.children.length > 0 ? "" : this.getTextFromNode();
	}
	getText() {
		return this.text;
	}
}, ei = class extends $r {
	constructor() {
		super(...arguments), this.type = "textNode";
	}
}, ti = class extends Xr {
	constructor() {
		super(...arguments), this.type = "svg", this.root = !1;
	}
	setContext(e) {
		var { document: t } = this, { screen: n, window: r } = t, i = e.canvas;
		if (n.setDefaults(e), i.style && e.font !== void 0 && r && r.getComputedStyle !== void 0) {
			e.font = r.getComputedStyle(i).getPropertyValue("font");
			var a = new J(t, "fontSize", Jr.parse(e.font).fontSize);
			a.hasValue() && (t.rootEmSize = a.getPixels("y"), t.emSize = t.rootEmSize);
		}
		this.getAttribute("x").hasValue() || this.getAttribute("x", !0).setValue(0), this.getAttribute("y").hasValue() || this.getAttribute("y", !0).setValue(0);
		var { width: o, height: s } = n.viewPort;
		this.getStyle("width").hasValue() || this.getStyle("width", !0).setValue("100%"), this.getStyle("height").hasValue() || this.getStyle("height", !0).setValue("100%"), this.getStyle("color").hasValue() || this.getStyle("color", !0).setValue("black");
		var c = this.getAttribute("refX"), l = this.getAttribute("refY"), u = this.getAttribute("viewBox"), d = u.hasValue() ? q(u.getString()) : null, f = !this.root && this.getStyle("overflow").getValue("hidden") !== "visible", p = 0, m = 0, h = 0, g = 0;
		d && (p = d[0], m = d[1]), this.root || (o = this.getStyle("width").getPixels("x"), s = this.getStyle("height").getPixels("y"), this.type === "marker" && (h = p, g = m, p = 0, m = 0)), n.viewPort.setCurrent(o, s), this.node && (!this.parent || this.node.parentNode?.nodeName === "foreignObject") && this.getStyle("transform", !1, !0).hasValue() && !this.getStyle("transform-origin", !1, !0).hasValue() && this.getStyle("transform-origin", !0, !0).setValue("50% 50%"), super.setContext(e), e.translate(this.getAttribute("x").getPixels("x"), this.getAttribute("y").getPixels("y")), d && (o = d[2], s = d[3]), t.setViewBox({
			ctx: e,
			aspectRatio: this.getAttribute("preserveAspectRatio").getString(),
			width: n.viewPort.width,
			desiredWidth: o,
			height: n.viewPort.height,
			desiredHeight: s,
			minX: p,
			minY: m,
			refX: c.getValue(),
			refY: l.getValue(),
			clip: f,
			clipX: h,
			clipY: g
		}), d && (n.viewPort.removeCurrent(), n.viewPort.setCurrent(o, s));
	}
	clearContext(e) {
		super.clearContext(e), this.document.screen.viewPort.removeCurrent();
	}
	resize(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e, n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2], r = this.getAttribute("width", !0), i = this.getAttribute("height", !0), a = this.getAttribute("viewBox"), o = this.getAttribute("style"), s = r.getNumber(0), c = i.getNumber(0);
		if (n) if (typeof n == "string") this.getAttribute("preserveAspectRatio", !0).setValue(n);
		else {
			var l = this.getAttribute("preserveAspectRatio");
			l.hasValue() && l.setValue(l.getString().replace(/^\s*(\S.*\S)\s*$/, "$1"));
		}
		if (r.setValue(e), i.setValue(t), a.hasValue() || a.setValue(`0 0 ${s || e} ${c || t}`), o.hasValue()) {
			var u = this.getStyle("width"), d = this.getStyle("height");
			u.hasValue() && u.setValue(`${e}px`), d.hasValue() && d.setValue(`${t}px`);
		}
	}
}, ni = class extends Q {
	constructor() {
		super(...arguments), this.type = "rect";
	}
	path(e) {
		var t = this.getAttribute("x").getPixels("x"), n = this.getAttribute("y").getPixels("y"), r = this.getStyle("width", !1, !0).getPixels("x"), i = this.getStyle("height", !1, !0).getPixels("y"), a = this.getAttribute("rx"), o = this.getAttribute("ry"), s = a.getPixels("x"), c = o.getPixels("y");
		if (a.hasValue() && !o.hasValue() && (c = s), o.hasValue() && !a.hasValue() && (s = c), s = Math.min(s, r / 2), c = Math.min(c, i / 2), e) {
			var l = 4 * ((Math.sqrt(2) - 1) / 3);
			e.beginPath(), i > 0 && r > 0 && (e.moveTo(t + s, n), e.lineTo(t + r - s, n), e.bezierCurveTo(t + r - s + l * s, n, t + r, n + c - l * c, t + r, n + c), e.lineTo(t + r, n + i - c), e.bezierCurveTo(t + r, n + i - c + l * c, t + r - s + l * s, n + i, t + r - s, n + i), e.lineTo(t + s, n + i), e.bezierCurveTo(t + s - l * s, n + i, t, n + i - c + l * c, t, n + i - c), e.lineTo(t, n + c), e.bezierCurveTo(t, n + c - l * c, t + s - l * s, n, t + s, n), e.closePath());
		}
		return new Yr(t, n, t + r, n + i);
	}
	getMarkers() {
		return null;
	}
}, ri = class extends Q {
	constructor() {
		super(...arguments), this.type = "circle";
	}
	path(e) {
		var t = this.getAttribute("cx").getPixels("x"), n = this.getAttribute("cy").getPixels("y"), r = this.getAttribute("r").getPixels();
		return e && r > 0 && (e.beginPath(), e.arc(t, n, r, 0, Math.PI * 2, !1), e.closePath()), new Yr(t - r, n - r, t + r, n + r);
	}
	getMarkers() {
		return null;
	}
}, ii = class extends Q {
	constructor() {
		super(...arguments), this.type = "ellipse";
	}
	path(e) {
		var t = 4 * ((Math.sqrt(2) - 1) / 3), n = this.getAttribute("rx").getPixels("x"), r = this.getAttribute("ry").getPixels("y"), i = this.getAttribute("cx").getPixels("x"), a = this.getAttribute("cy").getPixels("y");
		return e && n > 0 && r > 0 && (e.beginPath(), e.moveTo(i + n, a), e.bezierCurveTo(i + n, a + t * r, i + t * n, a + r, i, a + r), e.bezierCurveTo(i - t * n, a + r, i - n, a + t * r, i - n, a), e.bezierCurveTo(i - n, a - t * r, i - t * n, a - r, i, a - r), e.bezierCurveTo(i + t * n, a - r, i + n, a - t * r, i + n, a), e.closePath()), new Yr(i - n, a - r, i + n, a + r);
	}
	getMarkers() {
		return null;
	}
}, ai = class extends Q {
	constructor() {
		super(...arguments), this.type = "line";
	}
	getPoints() {
		return [new Y(this.getAttribute("x1").getPixels("x"), this.getAttribute("y1").getPixels("y")), new Y(this.getAttribute("x2").getPixels("x"), this.getAttribute("y2").getPixels("y"))];
	}
	path(e) {
		var [{ x: t, y: n }, { x: r, y: i }] = this.getPoints();
		return e && (e.beginPath(), e.moveTo(t, n), e.lineTo(r, i)), new Yr(t, n, r, i);
	}
	getMarkers() {
		var [e, t] = this.getPoints(), n = e.angleTo(t);
		return [[e, n], [t, n]];
	}
}, oi = class extends Q {
	constructor(e, t, n) {
		super(e, t, n), this.type = "polyline", this.points = [], this.points = Y.parsePath(this.getAttribute("points").getString());
	}
	path(e) {
		var { points: t } = this, [{ x: n, y: r }] = t, i = new Yr(n, r);
		return e && (e.beginPath(), e.moveTo(n, r)), t.forEach((t) => {
			var { x: n, y: r } = t;
			i.addPoint(n, r), e && e.lineTo(n, r);
		}), i;
	}
	getMarkers() {
		var { points: e } = this, t = e.length - 1, n = [];
		return e.forEach((r, i) => {
			i !== t && n.push([r, r.angleTo(e[i + 1])]);
		}), n.length > 0 && n.push([e[e.length - 1], n[n.length - 1][1]]), n;
	}
}, si = class extends oi {
	constructor() {
		super(...arguments), this.type = "polygon";
	}
	path(e) {
		var t = super.path(e), [{ x: n, y: r }] = this.points;
		return e && (e.lineTo(n, r), e.closePath()), t;
	}
}, ci = class extends X {
	constructor() {
		super(...arguments), this.type = "pattern";
	}
	createPattern(e, t, n) {
		var r = this.getStyle("width").getPixels("x", !0), i = this.getStyle("height").getPixels("y", !0), a = new ti(this.document, null);
		a.attributes.viewBox = new J(this.document, "viewBox", this.getAttribute("viewBox").getValue()), a.attributes.width = new J(this.document, "width", `${r}px`), a.attributes.height = new J(this.document, "height", `${i}px`), a.attributes.transform = new J(this.document, "transform", this.getAttribute("patternTransform").getValue()), a.children = this.children;
		var o = this.document.createCanvas(r, i), s = o.getContext("2d"), c = this.getAttribute("x"), l = this.getAttribute("y");
		c.hasValue() && l.hasValue() && s.translate(c.getPixels("x", !0), l.getPixels("y", !0)), n.hasValue() ? this.styles["fill-opacity"] = n : Reflect.deleteProperty(this.styles, "fill-opacity");
		for (var u = -1; u <= 1; u++) for (var d = -1; d <= 1; d++) s.save(), a.attributes.x = new J(this.document, "x", u * o.width), a.attributes.y = new J(this.document, "y", d * o.height), a.render(s), s.restore();
		return e.createPattern(o, "repeat");
	}
}, li = class extends X {
	constructor() {
		super(...arguments), this.type = "marker";
	}
	render(e, t, n) {
		if (t) {
			var { x: r, y: i } = t, a = this.getAttribute("orient").getString("auto"), o = this.getAttribute("markerUnits").getString("strokeWidth");
			e.translate(r, i), a === "auto" && e.rotate(n), o === "strokeWidth" && e.scale(e.lineWidth, e.lineWidth), e.save();
			var s = new ti(this.document, null);
			s.type = this.type, s.attributes.viewBox = new J(this.document, "viewBox", this.getAttribute("viewBox").getValue()), s.attributes.refX = new J(this.document, "refX", this.getAttribute("refX").getValue()), s.attributes.refY = new J(this.document, "refY", this.getAttribute("refY").getValue()), s.attributes.width = new J(this.document, "width", this.getAttribute("markerWidth").getValue()), s.attributes.height = new J(this.document, "height", this.getAttribute("markerHeight").getValue()), s.attributes.overflow = new J(this.document, "overflow", this.getAttribute("overflow").getValue()), s.attributes.fill = new J(this.document, "fill", this.getAttribute("fill").getColor("black")), s.attributes.stroke = new J(this.document, "stroke", this.getAttribute("stroke").getValue("none")), s.children = this.children, s.render(e), e.restore(), o === "strokeWidth" && e.scale(1 / e.lineWidth, 1 / e.lineWidth), a === "auto" && e.rotate(-n), e.translate(-r, -i);
		}
	}
}, ui = class extends X {
	constructor() {
		super(...arguments), this.type = "defs";
	}
	render() {}
}, di = class extends Xr {
	constructor() {
		super(...arguments), this.type = "g";
	}
	getBoundingBox(e) {
		var t = new Yr();
		return this.children.forEach((n) => {
			t.addBoundingBox(n.getBoundingBox(e));
		}), t;
	}
}, fi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.attributesToInherit = ["gradientUnits"], this.stops = [];
		var { stops: r, children: i } = this;
		i.forEach((e) => {
			e.type === "stop" && r.push(e);
		});
	}
	getGradientUnits() {
		return this.getAttribute("gradientUnits").getString("objectBoundingBox");
	}
	createGradient(e, t, n) {
		var r = this;
		this.getHrefAttribute().hasValue() && (r = this.getHrefAttribute().getDefinition(), this.inheritStopContainer(r));
		var { stops: i } = r, a = this.getGradient(e, t);
		if (!a) return this.addParentOpacity(n, i[i.length - 1].color);
		if (i.forEach((e) => {
			a.addColorStop(e.offset, this.addParentOpacity(n, e.color));
		}), this.getAttribute("gradientTransform").hasValue()) {
			var { document: o } = this, { MAX_VIRTUAL_PIXELS: s, viewPort: c } = o.screen, [l] = c.viewPorts, u = new ni(o, null);
			u.attributes.x = new J(o, "x", -s / 3), u.attributes.y = new J(o, "y", -s / 3), u.attributes.width = new J(o, "width", s), u.attributes.height = new J(o, "height", s);
			var d = new di(o, null);
			d.attributes.transform = new J(o, "transform", this.getAttribute("gradientTransform").getValue()), d.children = [u];
			var f = new ti(o, null);
			f.attributes.x = new J(o, "x", 0), f.attributes.y = new J(o, "y", 0), f.attributes.width = new J(o, "width", l.width), f.attributes.height = new J(o, "height", l.height), f.children = [d];
			var p = o.createCanvas(l.width, l.height), m = p.getContext("2d");
			return m.fillStyle = a, f.render(m), m.createPattern(p, "no-repeat");
		}
		return a;
	}
	inheritStopContainer(e) {
		this.attributesToInherit.forEach((t) => {
			!this.getAttribute(t).hasValue() && e.getAttribute(t).hasValue() && this.getAttribute(t, !0).setValue(e.getAttribute(t).getValue());
		});
	}
	addParentOpacity(e, t) {
		return e.hasValue() ? new J(this.document, "color", t).addOpacity(e).getColor() : t;
	}
}, pi = class extends fi {
	constructor(e, t, n) {
		super(e, t, n), this.type = "linearGradient", this.attributesToInherit.push("x1", "y1", "x2", "y2");
	}
	getGradient(e, t) {
		var n = this.getGradientUnits() === "objectBoundingBox", r = n ? t.getBoundingBox(e) : null;
		if (n && !r) return null;
		!this.getAttribute("x1").hasValue() && !this.getAttribute("y1").hasValue() && !this.getAttribute("x2").hasValue() && !this.getAttribute("y2").hasValue() && (this.getAttribute("x1", !0).setValue(0), this.getAttribute("y1", !0).setValue(0), this.getAttribute("x2", !0).setValue(1), this.getAttribute("y2", !0).setValue(0));
		var i = n ? r.x + r.width * this.getAttribute("x1").getNumber() : this.getAttribute("x1").getPixels("x"), a = n ? r.y + r.height * this.getAttribute("y1").getNumber() : this.getAttribute("y1").getPixels("y"), o = n ? r.x + r.width * this.getAttribute("x2").getNumber() : this.getAttribute("x2").getPixels("x"), s = n ? r.y + r.height * this.getAttribute("y2").getNumber() : this.getAttribute("y2").getPixels("y");
		return i === o && a === s ? null : e.createLinearGradient(i, a, o, s);
	}
}, mi = class extends fi {
	constructor(e, t, n) {
		super(e, t, n), this.type = "radialGradient", this.attributesToInherit.push("cx", "cy", "r", "fx", "fy", "fr");
	}
	getGradient(e, t) {
		var n = this.getGradientUnits() === "objectBoundingBox", r = t.getBoundingBox(e);
		if (n && !r) return null;
		this.getAttribute("cx").hasValue() || this.getAttribute("cx", !0).setValue("50%"), this.getAttribute("cy").hasValue() || this.getAttribute("cy", !0).setValue("50%"), this.getAttribute("r").hasValue() || this.getAttribute("r", !0).setValue("50%");
		var i = n ? r.x + r.width * this.getAttribute("cx").getNumber() : this.getAttribute("cx").getPixels("x"), a = n ? r.y + r.height * this.getAttribute("cy").getNumber() : this.getAttribute("cy").getPixels("y"), o = i, s = a;
		this.getAttribute("fx").hasValue() && (o = n ? r.x + r.width * this.getAttribute("fx").getNumber() : this.getAttribute("fx").getPixels("x")), this.getAttribute("fy").hasValue() && (s = n ? r.y + r.height * this.getAttribute("fy").getNumber() : this.getAttribute("fy").getPixels("y"));
		var c = n ? (r.width + r.height) / 2 * this.getAttribute("r").getNumber() : this.getAttribute("r").getPixels(), l = this.getAttribute("fr").getPixels();
		return e.createRadialGradient(o, s, l, i, a, c);
	}
}, hi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "stop";
		var r = Math.max(0, Math.min(1, this.getAttribute("offset").getNumber())), i = this.getStyle("stop-opacity"), a = this.getStyle("stop-color", !0);
		a.getString() === "" && a.setValue("#000"), i.hasValue() && (a = a.addOpacity(i)), this.offset = r, this.color = a.getColor();
	}
}, gi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "animate", this.duration = 0, this.initialValue = null, this.initialUnits = "", this.removed = !1, this.frozen = !1, e.screen.animations.push(this), this.begin = this.getAttribute("begin").getMilliseconds(), this.maxDuration = this.begin + this.getAttribute("dur").getMilliseconds(), this.from = this.getAttribute("from"), this.to = this.getAttribute("to"), this.values = new J(e, "values", null);
		var r = this.getAttribute("values");
		r.hasValue() && this.values.setValue(r.getString().split(";"));
	}
	getProperty() {
		var e = this.getAttribute("attributeType").getString(), t = this.getAttribute("attributeName").getString();
		return e === "CSS" ? this.parent.getStyle(t, !0) : this.parent.getAttribute(t, !0);
	}
	calcValue() {
		var { initialUnits: e } = this, { progress: t, from: n, to: r } = this.getProgress(), i = n.getNumber() + (r.getNumber() - n.getNumber()) * t;
		return e === "%" && (i *= 100), `${i}${e}`;
	}
	update(e) {
		var { parent: t } = this, n = this.getProperty();
		if (this.initialValue || (this.initialValue = n.getString(), this.initialUnits = n.getUnits()), this.duration > this.maxDuration) {
			var r = this.getAttribute("fill").getString("remove");
			if (this.getAttribute("repeatCount").getString() === "indefinite" || this.getAttribute("repeatDur").getString() === "indefinite") this.duration = 0;
			else if (r === "freeze" && !this.frozen) this.frozen = !0, t.animationFrozen = !0, t.animationFrozenValue = n.getString();
			else if (r === "remove" && !this.removed) return this.removed = !0, n.setValue(t.animationFrozen ? t.animationFrozenValue : this.initialValue), !0;
			return !1;
		}
		this.duration += e;
		var i = !1;
		if (this.begin < this.duration) {
			var a = this.calcValue(), o = this.getAttribute("type");
			o.hasValue() && (a = `${o.getString()}(${a})`), n.setValue(a), i = !0;
		}
		return i;
	}
	getProgress() {
		var { document: e, values: t } = this, n = { progress: (this.duration - this.begin) / (this.maxDuration - this.begin) };
		if (t.hasValue()) {
			var r = n.progress * (t.getValue().length - 1), i = Math.floor(r), a = Math.ceil(r);
			n.from = new J(e, "from", parseFloat(t.getValue()[i])), n.to = new J(e, "to", parseFloat(t.getValue()[a])), n.progress = (r - i) / (a - i);
		} else n.from = this.from, n.to = this.to;
		return n;
	}
}, _i = class extends gi {
	constructor() {
		super(...arguments), this.type = "animateColor";
	}
	calcValue() {
		var { progress: e, from: t, to: n } = this.getProgress(), r = new xn.default(t.getColor()), i = new xn.default(n.getColor());
		if (r.ok && i.ok) {
			var a = r.r + (i.r - r.r) * e, o = r.g + (i.g - r.g) * e, s = r.b + (i.b - r.b) * e;
			return `rgb(${Math.floor(a)}, ${Math.floor(o)}, ${Math.floor(s)})`;
		}
		return this.getAttribute("from").getColor();
	}
}, vi = class extends gi {
	constructor() {
		super(...arguments), this.type = "animateTransform";
	}
	calcValue() {
		var { progress: e, from: t, to: n } = this.getProgress(), r = q(t.getString()), i = q(n.getString());
		return r.map((t, n) => t + (i[n] - t) * e).join(" ");
	}
}, yi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "font", this.glyphs = Object.create(null), this.horizAdvX = this.getAttribute("horiz-adv-x").getNumber();
		var { definitions: r } = e, { children: i } = this;
		for (var a of i) switch (a.type) {
			case "font-face":
				this.fontFace = a;
				var o = a.getStyle("font-family");
				o.hasValue() && (r[o.getString()] = this);
				break;
			case "missing-glyph":
				this.missingGlyph = a;
				break;
			case "glyph":
				var s = a;
				s.arabicForm ? (this.isRTL = !0, this.isArabic = !0, this.glyphs[s.unicode] === void 0 && (this.glyphs[s.unicode] = Object.create(null)), this.glyphs[s.unicode][s.arabicForm] = s) : this.glyphs[s.unicode] = s;
		}
	}
	render() {}
}, bi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "font-face", this.ascent = this.getAttribute("ascent").getNumber(), this.descent = this.getAttribute("descent").getNumber(), this.unitsPerEm = this.getAttribute("units-per-em").getNumber();
	}
}, xi = class extends Q {
	constructor() {
		super(...arguments), this.type = "missing-glyph", this.horizAdvX = 0;
	}
}, Si = class extends Qr {
	constructor() {
		super(...arguments), this.type = "tref";
	}
	getText() {
		var e = this.getHrefAttribute().getDefinition();
		if (e) {
			var t = e.children[0];
			if (t) return t.getText();
		}
		return "";
	}
}, Ci = class extends Qr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "a";
		var { childNodes: r } = t, i = r[0], a = r.length > 0 && Array.from(r).every((e) => e.nodeType === 3);
		this.hasText = a, this.text = a ? this.getTextFromNode(i) : "";
	}
	getText() {
		return this.text;
	}
	renderChildren(e) {
		if (this.hasText) {
			super.renderChildren(e);
			var { document: t, x: n, y: r } = this, { mouse: i } = t.screen, a = new J(t, "fontSize", Jr.parse(t.ctx.font).fontSize);
			i.isWorking() && i.checkBoundingBox(this, new Yr(n, r - a.getPixels("y"), n + this.measureText(e), r));
		} else if (this.children.length > 0) {
			var o = new di(this.document, null);
			o.children = this.children, o.parent = this, o.render(e);
		}
	}
	onClick() {
		var { window: e } = this.document;
		e && e.open(this.getHrefAttribute().getString());
	}
	onMouseMove() {
		var e = this.document.ctx;
		e.canvas.style.cursor = "pointer";
	}
};
function wi(e, t) {
	var n = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var r = Object.getOwnPropertySymbols(e);
		t && (r = r.filter(function(t) {
			return Object.getOwnPropertyDescriptor(e, t).enumerable;
		})), n.push.apply(n, r);
	}
	return n;
}
function Ti(e) {
	for (var t = 1; t < arguments.length; t++) {
		var n = arguments[t] == null ? {} : arguments[t];
		t % 2 ? wi(Object(n), !0).forEach(function(t) {
			nn(e, t, n[t]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : wi(Object(n)).forEach(function(t) {
			Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
		});
	}
	return e;
}
var Ei = class extends Qr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "textPath", this.textWidth = 0, this.textHeight = 0, this.pathLength = -1, this.glyphInfo = null, this.letterSpacingCache = [], this.measuresCache = /* @__PURE__ */ new Map([["", 0]]);
		var r = this.getHrefAttribute().getDefinition();
		this.text = this.getTextFromNode(), this.dataArray = this.parsePathData(r);
	}
	getText() {
		return this.text;
	}
	path(e) {
		var { dataArray: t } = this;
		e && e.beginPath(), t.forEach((t) => {
			var { type: n, points: r } = t;
			switch (n) {
				case Z.LINE_TO:
					e && e.lineTo(r[0], r[1]);
					break;
				case Z.MOVE_TO:
					e && e.moveTo(r[0], r[1]);
					break;
				case Z.CURVE_TO:
					e && e.bezierCurveTo(r[0], r[1], r[2], r[3], r[4], r[5]);
					break;
				case Z.QUAD_TO:
					e && e.quadraticCurveTo(r[0], r[1], r[2], r[3]);
					break;
				case Z.ARC:
					var [i, a, o, s, c, l, u, d] = r, f = o > s ? o : s, p = o > s ? 1 : o / s, m = o > s ? s / o : 1;
					e && (e.translate(i, a), e.rotate(u), e.scale(p, m), e.arc(0, 0, f, c, c + l, !!(1 - d)), e.scale(1 / p, 1 / m), e.rotate(-u), e.translate(-i, -a));
					break;
				case Z.CLOSE_PATH: e && e.closePath();
			}
		});
	}
	renderChildren(e) {
		this.setTextData(e), e.save();
		var t = this.parent.getStyle("text-decoration").getString(), n = this.getFontSize(), { glyphInfo: r } = this, i = e.fillStyle;
		t === "underline" && e.beginPath(), r.forEach((r, i) => {
			var { p0: a, p1: o, rotation: s, text: c } = r;
			e.save(), e.translate(a.x, a.y), e.rotate(s), e.fillStyle && e.fillText(c, 0, 0), e.strokeStyle && e.strokeText(c, 0, 0), e.restore(), t === "underline" && (i === 0 && e.moveTo(a.x, a.y + n / 8), e.lineTo(o.x, o.y + n / 5));
		}), t === "underline" && (e.lineWidth = n / 20, e.strokeStyle = i, e.stroke(), e.closePath()), e.restore();
	}
	getLetterSpacingAt() {
		var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
		return this.letterSpacingCache[e] || 0;
	}
	findSegmentToFitChar(e, t, n, r, i, a, o, s, c) {
		var l = a, u = this.measureText(e, s);
		s === " " && t === "justify" && n < r && (u += (r - n) / i), c > -1 && (l += this.getLetterSpacingAt(c));
		var d = this.textHeight / 20, f = this.getEquidistantPointOnPath(l, d, 0), p = this.getEquidistantPointOnPath(l + u, d, 0), m = {
			p0: f,
			p1: p
		}, h = f && p ? Math.atan2(p.y - f.y, p.x - f.x) : 0;
		if (o) {
			var g = Math.cos(Math.PI / 2 + h) * o, _ = Math.cos(-h) * o;
			m.p0 = Ti(Ti({}, f), {}, {
				x: f.x + g,
				y: f.y + _
			}), m.p1 = Ti(Ti({}, p), {}, {
				x: p.x + g,
				y: p.y + _
			});
		}
		return l += u, {
			offset: l,
			segment: m,
			rotation: h
		};
	}
	measureText(e, t) {
		var { measuresCache: n } = this, r = t || this.getText();
		if (n.has(r)) return n.get(r);
		var i = this.measureTargetText(e, r);
		return n.set(r, i), i;
	}
	setTextData(e) {
		if (!this.glyphInfo) {
			var t = this.getText(), n = t.split(""), r = t.split(" ").length - 1, i = this.parent.getAttribute("dx").split().map((e) => e.getPixels("x")), a = this.parent.getAttribute("dy").getPixels("y"), o = this.parent.getStyle("text-anchor").getString("start"), s = this.getStyle("letter-spacing"), c = this.parent.getStyle("letter-spacing"), l = 0;
			!s.hasValue() || s.getValue() === "inherit" ? l = c.getPixels() : s.hasValue() && s.getValue() !== "initial" && s.getValue() !== "unset" && (l = s.getPixels());
			var u = [], d = t.length;
			this.letterSpacingCache = u;
			for (var f = 0; f < d; f++) u.push(i[f] === void 0 ? l : i[f]);
			var p = u.reduce((e, t, n) => n === 0 ? 0 : e + t || 0, 0), m = this.measureText(e), h = Math.max(m + p, 0);
			this.textWidth = m, this.textHeight = this.getFontSize(), this.glyphInfo = [];
			var g = this.getPathLength(), _ = this.getStyle("startOffset").getNumber(0) * g, v = 0;
			(o === "middle" || o === "center") && (v = -h / 2), (o === "end" || o === "right") && (v = -h), v += _, n.forEach((t, i) => {
				var { offset: s, segment: c, rotation: l } = this.findSegmentToFitChar(e, o, h, g, r, v, a, t, i);
				v = s, !(!c.p0 || !c.p1) && this.glyphInfo.push({
					text: n[i],
					p0: c.p0,
					p1: c.p1,
					rotation: l
				});
			});
		}
	}
	parsePathData(e) {
		if (this.pathLength = -1, !e) return [];
		var t = [], { pathParser: n } = e;
		for (n.reset(); !n.isEnd();) {
			var { current: r } = n, i = r ? r.x : 0, a = r ? r.y : 0, o = n.next(), s = o.type, c = [];
			switch (o.type) {
				case Z.MOVE_TO:
					this.pathM(n, c);
					break;
				case Z.LINE_TO:
					s = this.pathL(n, c);
					break;
				case Z.HORIZ_LINE_TO:
					s = this.pathH(n, c);
					break;
				case Z.VERT_LINE_TO:
					s = this.pathV(n, c);
					break;
				case Z.CURVE_TO:
					this.pathC(n, c);
					break;
				case Z.SMOOTH_CURVE_TO:
					s = this.pathS(n, c);
					break;
				case Z.QUAD_TO:
					this.pathQ(n, c);
					break;
				case Z.SMOOTH_QUAD_TO:
					s = this.pathT(n, c);
					break;
				case Z.ARC:
					c = this.pathA(n);
					break;
				case Z.CLOSE_PATH: Q.pathZ(n);
			}
			o.type === Z.CLOSE_PATH ? t.push({
				type: Z.CLOSE_PATH,
				points: [],
				pathLength: 0
			}) : t.push({
				type: s,
				points: c,
				start: {
					x: i,
					y: a
				},
				pathLength: this.calcLength(i, a, s, c)
			});
		}
		return t;
	}
	pathM(e, t) {
		var { x: n, y: r } = Q.pathM(e).point;
		t.push(n, r);
	}
	pathL(e, t) {
		var { x: n, y: r } = Q.pathL(e).point;
		return t.push(n, r), Z.LINE_TO;
	}
	pathH(e, t) {
		var { x: n, y: r } = Q.pathH(e).point;
		return t.push(n, r), Z.LINE_TO;
	}
	pathV(e, t) {
		var { x: n, y: r } = Q.pathV(e).point;
		return t.push(n, r), Z.LINE_TO;
	}
	pathC(e, t) {
		var { point: n, controlPoint: r, currentPoint: i } = Q.pathC(e);
		t.push(n.x, n.y, r.x, r.y, i.x, i.y);
	}
	pathS(e, t) {
		var { point: n, controlPoint: r, currentPoint: i } = Q.pathS(e);
		return t.push(n.x, n.y, r.x, r.y, i.x, i.y), Z.CURVE_TO;
	}
	pathQ(e, t) {
		var { controlPoint: n, currentPoint: r } = Q.pathQ(e);
		t.push(n.x, n.y, r.x, r.y);
	}
	pathT(e, t) {
		var { controlPoint: n, currentPoint: r } = Q.pathT(e);
		return t.push(n.x, n.y, r.x, r.y), Z.QUAD_TO;
	}
	pathA(e) {
		var { rX: t, rY: n, sweepFlag: r, xAxisRotation: i, centp: a, a1: o, ad: s } = Q.pathA(e);
		return r === 0 && s > 0 && (s -= 2 * Math.PI), r === 1 && s < 0 && (s += 2 * Math.PI), [
			a.x,
			a.y,
			t,
			n,
			o,
			s,
			i,
			r
		];
	}
	calcLength(e, t, n, r) {
		var i = 0, a = null, o = null, s = 0;
		switch (n) {
			case Z.LINE_TO: return this.getLineLength(e, t, r[0], r[1]);
			case Z.CURVE_TO:
				for (i = 0, a = this.getPointOnCubicBezier(0, e, t, r[0], r[1], r[2], r[3], r[4], r[5]), s = .01; s <= 1; s += .01) o = this.getPointOnCubicBezier(s, e, t, r[0], r[1], r[2], r[3], r[4], r[5]), i += this.getLineLength(a.x, a.y, o.x, o.y), a = o;
				return i;
			case Z.QUAD_TO:
				for (i = 0, a = this.getPointOnQuadraticBezier(0, e, t, r[0], r[1], r[2], r[3]), s = .01; s <= 1; s += .01) o = this.getPointOnQuadraticBezier(s, e, t, r[0], r[1], r[2], r[3]), i += this.getLineLength(a.x, a.y, o.x, o.y), a = o;
				return i;
			case Z.ARC:
				i = 0;
				var c = r[4], l = r[5], u = r[4] + l, d = Math.PI / 180;
				if (Math.abs(c - u) < d && (d = Math.abs(c - u)), a = this.getPointOnEllipticalArc(r[0], r[1], r[2], r[3], c, 0), l < 0) for (s = c - d; s > u; s -= d) o = this.getPointOnEllipticalArc(r[0], r[1], r[2], r[3], s, 0), i += this.getLineLength(a.x, a.y, o.x, o.y), a = o;
				else for (s = c + d; s < u; s += d) o = this.getPointOnEllipticalArc(r[0], r[1], r[2], r[3], s, 0), i += this.getLineLength(a.x, a.y, o.x, o.y), a = o;
				return o = this.getPointOnEllipticalArc(r[0], r[1], r[2], r[3], u, 0), i += this.getLineLength(a.x, a.y, o.x, o.y), i;
		}
		return 0;
	}
	getPointOnLine(e, t, n, r, i) {
		var a = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : t, o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : n, s = (i - n) / (r - t + mr), c = Math.sqrt(e * e / (1 + s * s));
		r < t && (c *= -1);
		var l = s * c, u = null;
		if (r === t) u = {
			x: a,
			y: o + l
		};
		else if ((o - n) / (a - t + 1e-8) === s) u = {
			x: a + c,
			y: o + l
		};
		else {
			var d = 0, f = 0, p = this.getLineLength(t, n, r, i);
			if (p < 1e-8) return null;
			var m = (a - t) * (r - t) + (o - n) * (i - n);
			m /= p * p, d = t + m * (r - t), f = n + m * (i - n);
			var h = this.getLineLength(a, o, d, f), g = Math.sqrt(e * e - h * h);
			c = Math.sqrt(g * g / (1 + s * s)), r < t && (c *= -1), l = s * c, u = {
				x: d + c,
				y: f + l
			};
		}
		return u;
	}
	getPointOnPath(e) {
		var t = this.getPathLength(), n = 0, r = null;
		if (e < -5e-5 || e - 5e-5 > t) return null;
		var { dataArray: i } = this;
		for (var a of i) {
			if (a && (a.pathLength < 5e-5 || n + a.pathLength + 5e-5 < e)) {
				n += a.pathLength;
				continue;
			}
			var o = e - n, s = 0;
			switch (a.type) {
				case Z.LINE_TO:
					r = this.getPointOnLine(o, a.start.x, a.start.y, a.points[0], a.points[1], a.start.x, a.start.y);
					break;
				case Z.ARC:
					var c = a.points[4], l = a.points[5], u = a.points[4] + l;
					if (s = c + o / a.pathLength * l, l < 0 && s < u || l >= 0 && s > u) break;
					r = this.getPointOnEllipticalArc(a.points[0], a.points[1], a.points[2], a.points[3], s, a.points[6]);
					break;
				case Z.CURVE_TO:
					s = o / a.pathLength, s > 1 && (s = 1), r = this.getPointOnCubicBezier(s, a.start.x, a.start.y, a.points[0], a.points[1], a.points[2], a.points[3], a.points[4], a.points[5]);
					break;
				case Z.QUAD_TO: s = o / a.pathLength, s > 1 && (s = 1), r = this.getPointOnQuadraticBezier(s, a.start.x, a.start.y, a.points[0], a.points[1], a.points[2], a.points[3]);
			}
			if (r) return r;
			break;
		}
		return null;
	}
	getLineLength(e, t, n, r) {
		return Math.sqrt((n - e) * (n - e) + (r - t) * (r - t));
	}
	getPathLength() {
		return this.pathLength === -1 && (this.pathLength = this.dataArray.reduce((e, t) => t.pathLength > 0 ? e + t.pathLength : e, 0)), this.pathLength;
	}
	getPointOnCubicBezier(e, t, n, r, i, a, o, s, c) {
		return {
			x: s * vr(e) + a * yr(e) + r * br(e) + t * xr(e),
			y: c * vr(e) + o * yr(e) + i * br(e) + n * xr(e)
		};
	}
	getPointOnQuadraticBezier(e, t, n, r, i, a, o) {
		return {
			x: a * Sr(e) + r * Cr(e) + t * wr(e),
			y: o * Sr(e) + i * Cr(e) + n * wr(e)
		};
	}
	getPointOnEllipticalArc(e, t, n, r, i, a) {
		var o = Math.cos(a), s = Math.sin(a), c = {
			x: n * Math.cos(i),
			y: r * Math.sin(i)
		};
		return {
			x: e + (c.x * o - c.y * s),
			y: t + (c.x * s + c.y * o)
		};
	}
	buildEquidistantCache(e, t) {
		var n = this.getPathLength(), r = t || .25, i = e || n / 100;
		if (!this.equidistantCache || this.equidistantCache.step !== i || this.equidistantCache.precision !== r) {
			this.equidistantCache = {
				step: i,
				precision: r,
				points: []
			};
			for (var a = 0, o = 0; o <= n; o += r) {
				var s = this.getPointOnPath(o), c = this.getPointOnPath(o + r);
				!s || !c || (a += this.getLineLength(s.x, s.y, c.x, c.y), a >= i && (this.equidistantCache.points.push({
					x: s.x,
					y: s.y,
					distance: o
				}), a -= i));
			}
		}
	}
	getEquidistantPointOnPath(e, t, n) {
		if (this.buildEquidistantCache(t, n), e < 0 || e - this.getPathLength() > 5e-5) return null;
		var r = Math.round(e / this.getPathLength() * (this.equidistantCache.points.length - 1));
		return this.equidistantCache.points[r] || null;
	}
}, Di = /^\s*data:(([^/,;]+\/[^/,;]+)(?:;([^,;=]+=[^,;=]+))?)?(?:;(base64))?,(.*)$/i, Oi = class extends Xr {
	constructor(e, t, n) {
		super(e, t, n), this.type = "image", this.loaded = !1;
		var r = this.getHrefAttribute().getString();
		if (r) {
			var i = r.endsWith(".svg") || /^\s*data:image\/svg\+xml/i.test(r);
			e.images.push(this), i ? this.loadSvg(r) : this.loadImage(r), this.isSvg = i;
		}
	}
	loadImage(e) {
		var t = this;
		return yt(function* () {
			try {
				t.image = yield t.document.createImage(e);
			} catch (t) {
				console.error(`Error while loading image "${e}":`, t);
			}
			t.loaded = !0;
		})();
	}
	loadSvg(e) {
		var t = this;
		return yt(function* () {
			var n = Di.exec(e);
			if (n) {
				var r = n[5];
				t.image = n[4] === "base64" ? atob(r) : decodeURIComponent(r);
			} else try {
				t.image = yield (yield t.document.fetch(e)).text();
			} catch (t) {
				console.error(`Error while loading image "${e}":`, t);
			}
			t.loaded = !0;
		})();
	}
	renderChildren(e) {
		var { document: t, image: n, loaded: r } = this, i = this.getAttribute("x").getPixels("x"), a = this.getAttribute("y").getPixels("y"), o = this.getStyle("width").getPixels("x"), s = this.getStyle("height").getPixels("y");
		if (!(!r || !n || !o || !s)) {
			if (e.save(), e.translate(i, a), this.isSvg) {
				var c = t.canvg.forkString(e, this.image, {
					ignoreMouse: !0,
					ignoreAnimation: !0,
					ignoreDimensions: !0,
					ignoreClear: !0,
					offsetX: 0,
					offsetY: 0,
					scaleWidth: o,
					scaleHeight: s
				});
				c.document.documentElement.parent = this, c.render();
			} else {
				var l = this.image;
				t.setViewBox({
					ctx: e,
					aspectRatio: this.getAttribute("preserveAspectRatio").getString(),
					width: o,
					desiredWidth: l.width,
					height: s,
					desiredHeight: l.height
				}), this.loaded && (l.complete === void 0 || l.complete) && e.drawImage(l, 0, 0);
			}
			e.restore();
		}
	}
	getBoundingBox() {
		var e = this.getAttribute("x").getPixels("x"), t = this.getAttribute("y").getPixels("y"), n = this.getStyle("width").getPixels("x"), r = this.getStyle("height").getPixels("y");
		return new Yr(e, t, e + n, t + r);
	}
}, ki = class extends Xr {
	constructor() {
		super(...arguments), this.type = "symbol";
	}
	render(e) {}
}, Ai = class {
	constructor(e) {
		this.document = e, this.loaded = !1, e.fonts.push(this);
	}
	load(e, t) {
		var n = this;
		return yt(function* () {
			try {
				var { document: r } = n, i = (yield r.canvg.parser.load(t)).getElementsByTagName("font");
				Array.from(i).forEach((t) => {
					var n = r.createElement(t);
					r.definitions[e] = n;
				});
			} catch (e) {
				console.error(`Error while loading font "${t}":`, e);
			}
			n.loaded = !0;
		})();
	}
}, ji = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "style", Qn(Array.from(t.childNodes).map((e) => e.textContent).join("").replace(/(\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+\/)|(^[\s]*\/\/.*)/gm, "").replace(/@import.*;/g, "")).split("}").forEach((t) => {
			var n = t.trim();
			if (n) {
				var r = n.split("{"), i = r[0].split(","), a = r[1].split(";");
				i.forEach((t) => {
					var n = t.trim();
					if (n) {
						var r = e.styles[n] || {};
						if (a.forEach((t) => {
							var n = t.indexOf(":"), i = t.substr(0, n).trim(), a = t.substr(n + 1, t.length - n).trim();
							i && a && (r[i] = new J(e, i, a));
						}), e.styles[n] = r, e.stylesSpecificity[n] = pr(n), n === "@font-face") {
							var i = r["font-family"].getString().replace(/"|'/g, "");
							r.src.getString().split(",").forEach((t) => {
								if (t.indexOf("format(\"svg\")") > 0) {
									var n = rr(t);
									n && new Ai(e).load(i, n);
								}
							});
						}
					}
				});
			}
		});
	}
};
ji.parseExternalUrl = rr;
var Mi = class extends Xr {
	constructor() {
		super(...arguments), this.type = "use";
	}
	setContext(e) {
		super.setContext(e);
		var t = this.getAttribute("x"), n = this.getAttribute("y");
		t.hasValue() && e.translate(t.getPixels("x"), 0), n.hasValue() && e.translate(0, n.getPixels("y"));
	}
	path(e) {
		var { element: t } = this;
		t && t.path(e);
	}
	renderChildren(e) {
		var { document: t, element: n } = this;
		if (n) {
			var r = n;
			if (n.type === "symbol" && (r = new ti(t, null), r.attributes.viewBox = new J(t, "viewBox", n.getAttribute("viewBox").getString()), r.attributes.preserveAspectRatio = new J(t, "preserveAspectRatio", n.getAttribute("preserveAspectRatio").getString()), r.attributes.overflow = new J(t, "overflow", n.getAttribute("overflow").getString()), r.children = n.children, n.styles.opacity = new J(t, "opacity", this.calculateOpacity())), r.type === "svg") {
				var i = this.getStyle("width", !1, !0), a = this.getStyle("height", !1, !0);
				i.hasValue() && (r.attributes.width = new J(t, "width", i.getString())), a.hasValue() && (r.attributes.height = new J(t, "height", a.getString()));
			}
			var o = r.parent;
			r.parent = this, r.render(e), r.parent = o;
		}
	}
	getBoundingBox(e) {
		var { element: t } = this;
		return t ? t.getBoundingBox(e) : null;
	}
	elementTransform() {
		var { document: e, element: t } = this;
		return Hr.fromElement(e, t);
	}
	get element() {
		return this.cachedElement ||= this.getHrefAttribute().getDefinition(), this.cachedElement;
	}
};
function Ni(e, t, n, r, i, a) {
	return e[n * r * 4 + t * 4 + a];
}
function Pi(e, t, n, r, i, a, o) {
	e[n * r * 4 + t * 4 + a] = o;
}
function $(e, t, n) {
	return e[t] * n;
}
function Fi(e, t, n, r) {
	return t + Math.cos(e) * n + Math.sin(e) * r;
}
var Ii = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "feColorMatrix";
		var r = q(this.getAttribute("values").getString());
		switch (this.getAttribute("type").getString("matrix")) {
			case "saturate":
				var i = r[0];
				r = [
					.213 + .787 * i,
					.715 - .715 * i,
					.072 - .072 * i,
					0,
					0,
					.213 - .213 * i,
					.715 + .285 * i,
					.072 - .072 * i,
					0,
					0,
					.213 - .213 * i,
					.715 - .715 * i,
					.072 + .928 * i,
					0,
					0,
					0,
					0,
					0,
					1,
					0,
					0,
					0,
					0,
					0,
					1
				];
				break;
			case "hueRotate":
				var a = r[0] * Math.PI / 180;
				r = [
					Fi(a, .213, .787, -.213),
					Fi(a, .715, -.715, -.715),
					Fi(a, .072, -.072, .928),
					0,
					0,
					Fi(a, .213, -.213, .143),
					Fi(a, .715, .285, .14),
					Fi(a, .072, -.072, -.283),
					0,
					0,
					Fi(a, .213, -.213, -.787),
					Fi(a, .715, -.715, .715),
					Fi(a, .072, .928, .072),
					0,
					0,
					0,
					0,
					0,
					1,
					0,
					0,
					0,
					0,
					0,
					1
				];
				break;
			case "luminanceToAlpha": r = [
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				.2125,
				.7154,
				.0721,
				0,
				0,
				0,
				0,
				0,
				0,
				1
			];
		}
		this.matrix = r, this.includeOpacity = this.getAttribute("includeOpacity").hasValue();
	}
	apply(e, t, n, r, i) {
		for (var { includeOpacity: a, matrix: o } = this, s = e.getImageData(0, 0, r, i), c = 0; c < i; c++) for (var l = 0; l < r; l++) {
			var u = Ni(s.data, l, c, r, i, 0), d = Ni(s.data, l, c, r, i, 1), f = Ni(s.data, l, c, r, i, 2), p = Ni(s.data, l, c, r, i, 3), m = $(o, 0, u) + $(o, 1, d) + $(o, 2, f) + $(o, 3, p) + $(o, 4, 1), h = $(o, 5, u) + $(o, 6, d) + $(o, 7, f) + $(o, 8, p) + $(o, 9, 1), g = $(o, 10, u) + $(o, 11, d) + $(o, 12, f) + $(o, 13, p) + $(o, 14, 1), _ = $(o, 15, u) + $(o, 16, d) + $(o, 17, f) + $(o, 18, p) + $(o, 19, 1);
			a && (m = 0, h = 0, g = 0, _ *= p / 255), Pi(s.data, l, c, r, i, 0, m), Pi(s.data, l, c, r, i, 1, h), Pi(s.data, l, c, r, i, 2, g), Pi(s.data, l, c, r, i, 3, _);
		}
		e.clearRect(0, 0, r, i), e.putImageData(s, 0, 0);
	}
}, Li = class e extends X {
	constructor() {
		super(...arguments), this.type = "mask";
	}
	apply(t, n) {
		var { document: r } = this, i = this.getAttribute("x").getPixels("x"), a = this.getAttribute("y").getPixels("y"), o = this.getStyle("width").getPixels("x"), s = this.getStyle("height").getPixels("y");
		if (!o && !s) {
			var c = new Yr();
			this.children.forEach((e) => {
				c.addBoundingBox(e.getBoundingBox(t));
			}), i = Math.floor(c.x1), a = Math.floor(c.y1), o = Math.floor(c.width), s = Math.floor(c.height);
		}
		var l = this.removeStyles(n, e.ignoreStyles), u = r.createCanvas(i + o, a + s), d = u.getContext("2d");
		r.screen.setDefaults(d), this.renderChildren(d), new Ii(r, {
			nodeType: 1,
			childNodes: [],
			attributes: [{
				nodeName: "type",
				value: "luminanceToAlpha"
			}, {
				nodeName: "includeOpacity",
				value: "true"
			}]
		}).apply(d, 0, 0, i + o, a + s);
		var f = r.createCanvas(i + o, a + s), p = f.getContext("2d");
		r.screen.setDefaults(p), n.render(p), p.globalCompositeOperation = "destination-in", p.fillStyle = d.createPattern(u, "no-repeat"), p.fillRect(0, 0, i + o, a + s), t.fillStyle = p.createPattern(f, "no-repeat"), t.fillRect(0, 0, i + o, a + s), this.restoreStyles(n, l);
	}
	render(e) {}
};
Li.ignoreStyles = [
	"mask",
	"transform",
	"clip-path"
];
var Ri = () => {}, zi = class extends X {
	constructor() {
		super(...arguments), this.type = "clipPath";
	}
	apply(e) {
		var { document: t } = this, n = Reflect.getPrototypeOf(e), { beginPath: r, closePath: i } = e;
		n && (n.beginPath = Ri, n.closePath = Ri), Reflect.apply(r, e, []), this.children.forEach((r) => {
			if (r.path !== void 0) {
				var a = r.elementTransform === void 0 ? null : r.elementTransform();
				a ||= Hr.fromElement(t, r), a && a.apply(e), r.path(e), n && (n.closePath = i), a && a.unapply(e);
			}
		}), Reflect.apply(i, e, []), e.clip(), n && (n.beginPath = r, n.closePath = i);
	}
	render(e) {}
}, Bi = class e extends X {
	constructor() {
		super(...arguments), this.type = "filter";
	}
	apply(t, n) {
		var { document: r, children: i } = this, a = n.getBoundingBox(t);
		if (a) {
			var o = 0, s = 0;
			i.forEach((e) => {
				var t = e.extraFilterDistance || 0;
				o = Math.max(o, t), s = Math.max(s, t);
			});
			var c = Math.floor(a.width), l = Math.floor(a.height), u = c + 2 * o, d = l + 2 * s;
			if (!(u < 1 || d < 1)) {
				var f = Math.floor(a.x), p = Math.floor(a.y), m = this.removeStyles(n, e.ignoreStyles), h = r.createCanvas(u, d), g = h.getContext("2d");
				r.screen.setDefaults(g), g.translate(-f + o, -p + s), n.render(g), i.forEach((e) => {
					typeof e.apply == "function" && e.apply(g, 0, 0, u, d);
				}), t.drawImage(h, 0, 0, u, d, f - o, p - s, u, d), this.restoreStyles(n, m);
			}
		}
	}
	render(e) {}
};
Bi.ignoreStyles = [
	"filter",
	"transform",
	"clip-path"
];
var Vi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "feDropShadow", this.addStylesFromStyleDefinition();
	}
	apply(e, t, n, r, i) {}
}, Hi = class extends X {
	constructor() {
		super(...arguments), this.type = "feMorphology";
	}
	apply(e, t, n, r, i) {}
}, Ui = class extends X {
	constructor() {
		super(...arguments), this.type = "feComposite";
	}
	apply(e, t, n, r, i) {}
}, Wi = class extends X {
	constructor(e, t, n) {
		super(e, t, n), this.type = "feGaussianBlur", this.blurRadius = Math.floor(this.getAttribute("stdDeviation").getNumber()), this.extraFilterDistance = this.blurRadius;
	}
	apply(e, t, n, r, i) {
		var { document: a, blurRadius: o } = this, s = a.window ? a.window.document.body : null, c = e.canvas;
		c.id = a.getUniqueId(), s && (c.style.display = "none", s.appendChild(c)), Kn(c, t, n, r, i, o), s && s.removeChild(c);
	}
}, Gi = class extends X {
	constructor() {
		super(...arguments), this.type = "title";
	}
}, Ki = class extends X {
	constructor() {
		super(...arguments), this.type = "desc";
	}
}, qi = {
	svg: ti,
	rect: ni,
	circle: ri,
	ellipse: ii,
	line: ai,
	polyline: oi,
	polygon: si,
	path: Q,
	pattern: ci,
	marker: li,
	defs: ui,
	linearGradient: pi,
	radialGradient: mi,
	stop: hi,
	animate: gi,
	animateColor: _i,
	animateTransform: vi,
	font: yi,
	"font-face": bi,
	"missing-glyph": xi,
	glyph: Zr,
	text: Qr,
	tspan: $r,
	tref: Si,
	a: Ci,
	textPath: Ei,
	image: Oi,
	g: di,
	symbol: ki,
	style: ji,
	use: Mi,
	mask: Li,
	clipPath: zi,
	filter: Bi,
	feDropShadow: Vi,
	feMorphology: Hi,
	feComposite: Ui,
	feColorMatrix: Ii,
	feGaussianBlur: Wi,
	title: Gi,
	desc: Ki
};
function Ji(e, t) {
	var n = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var r = Object.getOwnPropertySymbols(e);
		t && (r = r.filter(function(t) {
			return Object.getOwnPropertyDescriptor(e, t).enumerable;
		})), n.push.apply(n, r);
	}
	return n;
}
function Yi(e) {
	for (var t = 1; t < arguments.length; t++) {
		var n = arguments[t] == null ? {} : arguments[t];
		t % 2 ? Ji(Object(n), !0).forEach(function(t) {
			nn(e, t, n[t]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ji(Object(n)).forEach(function(t) {
			Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
		});
	}
	return e;
}
function Xi(e, t) {
	var n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}
function Zi(e) {
	return Qi.apply(this, arguments);
}
function Qi() {
	return Qi = yt(function* (e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], n = document.createElement("img");
		return t && (n.crossOrigin = "Anonymous"), new Promise((t, r) => {
			n.onload = () => {
				t(n);
			}, n.onerror = (e, t, n, i, a) => {
				r(a);
			}, n.src = e;
		});
	}), Qi.apply(this, arguments);
}
var $i = class e {
	constructor(t) {
		var { rootEmSize: n = 12, emSize: r = 12, createCanvas: i = e.createCanvas, createImage: a = e.createImage, anonymousCrossOrigin: o } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		this.canvg = t, this.definitions = Object.create(null), this.styles = Object.create(null), this.stylesSpecificity = Object.create(null), this.images = [], this.fonts = [], this.emSizeStack = [], this.uniqueId = 0, this.screen = t.screen, this.rootEmSize = n, this.emSize = r, this.createCanvas = i, this.createImage = this.bindCreateImage(a, o), this.screen.wait(this.isImagesLoaded.bind(this)), this.screen.wait(this.isFontsLoaded.bind(this));
	}
	bindCreateImage(e, t) {
		return typeof t == "boolean" ? (n, r) => e(n, typeof r == "boolean" ? r : t) : e;
	}
	get window() {
		return this.screen.window;
	}
	get fetch() {
		return this.screen.fetch;
	}
	get ctx() {
		return this.screen.ctx;
	}
	get emSize() {
		var { emSizeStack: e } = this;
		return e[e.length - 1];
	}
	set emSize(e) {
		var { emSizeStack: t } = this;
		t.push(e);
	}
	popEmSize() {
		var { emSizeStack: e } = this;
		e.pop();
	}
	getUniqueId() {
		return `canvg${++this.uniqueId}`;
	}
	isImagesLoaded() {
		return this.images.every((e) => e.loaded);
	}
	isFontsLoaded() {
		return this.fonts.every((e) => e.loaded);
	}
	createDocumentElement(e) {
		var t = this.createElement(e.documentElement);
		return t.root = !0, t.addStylesFromStyleDefinition(), this.documentElement = t, t;
	}
	createElement(t) {
		var n = t.nodeName.replace(/^[^:]+:/, ""), r = e.elementTypes[n];
		return r === void 0 ? new Ur(this, t) : new r(this, t);
	}
	createTextNode(e) {
		return new ei(this, e);
	}
	setViewBox(e) {
		this.screen.setViewBox(Yi({ document: this }, e));
	}
};
$i.createCanvas = Xi, $i.createImage = Zi, $i.elementTypes = qi;
function ea(e, t) {
	var n = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var r = Object.getOwnPropertySymbols(e);
		t && (r = r.filter(function(t) {
			return Object.getOwnPropertyDescriptor(e, t).enumerable;
		})), n.push.apply(n, r);
	}
	return n;
}
function ta(e) {
	for (var t = 1; t < arguments.length; t++) {
		var n = arguments[t] == null ? {} : arguments[t];
		t % 2 ? ea(Object(n), !0).forEach(function(t) {
			nn(e, t, n[t]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : ea(Object(n)).forEach(function(t) {
			Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
		});
	}
	return e;
}
var na = class e {
	constructor(e, t) {
		var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
		this.parser = new Mr(n), this.screen = new kr(e, n), this.options = n;
		var r = new $i(this, n), i = r.createDocumentElement(t);
		this.document = r, this.documentElement = i;
	}
	static from(t, n) {
		var r = arguments;
		return yt(function* () {
			var i = r.length > 2 && r[2] !== void 0 ? r[2] : {}, a = yield new Mr(i).parse(n);
			return new e(t, a, i);
		})();
	}
	static fromString(t, n) {
		var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, i = new Mr(r).parseFromString(n);
		return new e(t, i, r);
	}
	fork(t, n) {
		var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
		return e.from(t, n, ta(ta({}, this.options), r));
	}
	forkString(t, n) {
		var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
		return e.fromString(t, n, ta(ta({}, this.options), r));
	}
	ready() {
		return this.screen.ready();
	}
	isReady() {
		return this.screen.isReady();
	}
	render() {
		var e = arguments, t = this;
		return yt(function* () {
			var n = e.length > 0 && e[0] !== void 0 ? e[0] : {};
			t.start(ta({
				enableRedraw: !0,
				ignoreAnimation: !0,
				ignoreMouse: !0
			}, n)), yield t.ready(), t.stop();
		})();
	}
	start() {
		var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, { documentElement: t, screen: n, options: r } = this;
		n.start(t, ta(ta({ enableRedraw: !0 }, r), e));
	}
	stop() {
		this.screen.stop();
	}
	resize(e) {
		var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e, n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2];
		this.documentElement.resize(e, t, n);
	}
};
//#endregion
export { Ci as AElement, _i as AnimateColorElement, gi as AnimateElement, vi as AnimateTransformElement, Yr as BoundingBox, vr as CB1, yr as CB2, br as CB3, xr as CB4, na as Canvg, na as default, ri as CircleElement, zi as ClipPathElement, ui as DefsElement, Ki as DescElement, $i as Document, X as Element, ii as EllipseElement, Ii as FeColorMatrixElement, Ui as FeCompositeElement, Vi as FeDropShadowElement, Wi as FeGaussianBlurElement, Hi as FeMorphologyElement, Bi as FilterElement, Jr as Font, yi as FontElement, bi as FontFaceElement, di as GElement, Zr as GlyphElement, fi as GradientElement, Oi as ImageElement, ai as LineElement, pi as LinearGradientElement, li as MarkerElement, Li as MaskElement, Ir as Matrix, xi as MissingGlyphElement, Er as Mouse, mr as PSEUDO_ZERO, Mr as Parser, Q as PathElement, Z as PathParser, ci as PatternElement, Y as Point, si as PolygonElement, oi as PolylineElement, J as Property, Sr as QB1, Cr as QB2, wr as QB3, mi as RadialGradientElement, ni as RectElement, Xr as RenderedElement, Pr as Rotate, ti as SVGElement, Ai as SVGFontLoader, Fr as Scale, kr as Screen, Lr as Skew, Rr as SkewX, zr as SkewY, hi as StopElement, ji as StyleElement, ki as SymbolElement, Si as TRefElement, $r as TSpanElement, Qr as TextElement, Ei as TextPathElement, Gi as TitleElement, Hr as Transform, Nr as Translate, Ur as UnknownElement, Mi as UseElement, Tr as ViewPort, Qn as compressSpaces, pr as getSelectorSpecificity, nr as normalizeAttributeName, ir as normalizeColor, rr as parseExternalUrl, Zn as presets, q as toNumbers, $n as trimLeft, er as trimRight, hr as vectorMagnitude, _r as vectorsAngle, gr as vectorsRatio };
