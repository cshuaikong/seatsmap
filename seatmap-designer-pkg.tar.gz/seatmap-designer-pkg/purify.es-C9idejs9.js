//#region node_modules/dompurify/dist/purify.es.mjs
function e(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function t(e) {
	if (Array.isArray(e)) return e;
}
function n(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t !== 0) for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
function r() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function i(e, i) {
	return t(e) || n(e, i) || a(e, i) || r();
}
function a(t, n) {
	if (t) {
		if (typeof t == "string") return e(t, n);
		var r = {}.toString.call(t).slice(8, -1);
		return r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set" ? Array.from(t) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? e(t, n) : void 0;
	}
}
var o = Object.entries, s = Object.setPrototypeOf, c = Object.isFrozen, l = Object.getPrototypeOf, u = Object.getOwnPropertyDescriptor, d = Object.freeze, f = Object.seal, p = Object.create, m = typeof Reflect < "u" && Reflect, h = m.apply, ee = m.construct;
d ||= function(e) {
	return e;
}, f ||= function(e) {
	return e;
}, h ||= function(e, t) {
	var n = [...arguments].slice(2);
	return e.apply(t, n);
}, ee ||= function(e) {
	return new e(...[...arguments].slice(1));
};
var g = T(Array.prototype.forEach), te = T(Array.prototype.lastIndexOf), ne = T(Array.prototype.pop), _ = T(Array.prototype.push), re = T(Array.prototype.splice), v = Array.isArray, ie = T(String.prototype.toLowerCase), ae = T(String.prototype.toString), oe = T(String.prototype.match), se = T(String.prototype.replace), ce = T(String.prototype.indexOf), le = T(String.prototype.trim), ue = T(Number.prototype.toString), de = T(Boolean.prototype.toString), y = typeof BigInt > "u" ? null : T(BigInt.prototype.toString), b = typeof Symbol > "u" ? null : T(Symbol.prototype.toString), x = T(Object.prototype.hasOwnProperty), S = T(Object.prototype.toString), C = T(RegExp.prototype.test), w = E(TypeError);
function T(e) {
	return function(t) {
		t instanceof RegExp && (t.lastIndex = 0);
		var n = [...arguments].slice(1);
		return h(e, t, n);
	};
}
function E(e) {
	return function() {
		return ee(e, [...arguments]);
	};
}
function D(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : ie;
	if (s && s(e, null), !v(t)) return e;
	let r = t.length;
	for (; r--;) {
		let i = t[r];
		if (typeof i == "string") {
			let e = n(i);
			e !== i && (c(t) || (t[r] = e), i = e);
		}
		e[i] = !0;
	}
	return e;
}
function O(e) {
	for (let t = 0; t < e.length; t++) x(e, t) || (e[t] = null);
	return e;
}
function k(e) {
	let t = p(null);
	for (let r of o(e)) {
		var n = i(r, 2);
		let a = n[0], o = n[1];
		x(e, a) && (t[a] = v(o) ? O(o) : o && typeof o == "object" && o.constructor === Object ? k(o) : o);
	}
	return t;
}
function fe(e) {
	switch (typeof e) {
		case "string": return e;
		case "number": return ue(e);
		case "boolean": return de(e);
		case "bigint": return y ? y(e) : "0";
		case "symbol": return b ? b(e) : "Symbol()";
		case "undefined": return S(e);
		case "function":
		case "object": {
			if (e === null) return S(e);
			let t = e, n = A(t, "toString");
			if (typeof n == "function") {
				let e = n(t);
				return typeof e == "string" ? e : S(e);
			}
			return S(e);
		}
		default: return S(e);
	}
}
function A(e, t) {
	for (; e !== null;) {
		let n = u(e, t);
		if (n) {
			if (n.get) return T(n.get);
			if (typeof n.value == "function") return T(n.value);
		}
		e = l(e);
	}
	function n() {
		return null;
	}
	return n;
}
function pe(e) {
	try {
		return C(e, ""), !0;
	} catch {
		return !1;
	}
}
var me = d(/* @__PURE__ */ "a.abbr.acronym.address.area.article.aside.audio.b.bdi.bdo.big.blink.blockquote.body.br.button.canvas.caption.center.cite.code.col.colgroup.content.data.datalist.dd.decorator.del.details.dfn.dialog.dir.div.dl.dt.element.em.fieldset.figcaption.figure.font.footer.form.h1.h2.h3.h4.h5.h6.head.header.hgroup.hr.html.i.img.input.ins.kbd.label.legend.li.main.map.mark.marquee.menu.menuitem.meter.nav.nobr.ol.optgroup.option.output.p.picture.pre.progress.q.rp.rt.ruby.s.samp.search.section.select.shadow.slot.small.source.spacer.span.strike.strong.style.sub.summary.sup.table.tbody.td.template.textarea.tfoot.th.thead.time.tr.track.tt.u.ul.var.video.wbr".split(".")), he = d(/* @__PURE__ */ "svg.a.altglyph.altglyphdef.altglyphitem.animatecolor.animatemotion.animatetransform.circle.clippath.defs.desc.ellipse.enterkeyhint.exportparts.filter.font.g.glyph.glyphref.hkern.image.inputmode.line.lineargradient.marker.mask.metadata.mpath.part.path.pattern.polygon.polyline.radialgradient.rect.stop.style.switch.symbol.text.textpath.title.tref.tspan.view.vkern".split(".")), ge = d([
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence"
]), _e = d([
	"animate",
	"color-profile",
	"cursor",
	"discard",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignobject",
	"hatch",
	"hatchpath",
	"mesh",
	"meshgradient",
	"meshpatch",
	"meshrow",
	"missing-glyph",
	"script",
	"set",
	"solidcolor",
	"unknown",
	"use"
]), ve = d(/* @__PURE__ */ "math.menclose.merror.mfenced.mfrac.mglyph.mi.mlabeledtr.mmultiscripts.mn.mo.mover.mpadded.mphantom.mroot.mrow.ms.mspace.msqrt.mstyle.msub.msup.msubsup.mtable.mtd.mtext.mtr.munder.munderover.mprescripts".split(".")), ye = d([
	"maction",
	"maligngroup",
	"malignmark",
	"mlongdiv",
	"mscarries",
	"mscarry",
	"msgroup",
	"mstack",
	"msline",
	"msrow",
	"semantics",
	"annotation",
	"annotation-xml",
	"mprescripts",
	"none"
]), be = d(["#text"]), xe = d(/* @__PURE__ */ "accept.action.align.alt.autocapitalize.autocomplete.autopictureinpicture.autoplay.background.bgcolor.border.capture.cellpadding.cellspacing.checked.cite.class.clear.color.cols.colspan.command.commandfor.controls.controlslist.coords.crossorigin.datetime.decoding.default.dir.disabled.disablepictureinpicture.disableremoteplayback.download.draggable.enctype.enterkeyhint.exportparts.face.for.headers.height.hidden.high.href.hreflang.id.inert.inputmode.integrity.ismap.kind.label.lang.list.loading.loop.low.max.maxlength.media.method.min.minlength.multiple.muted.name.nonce.noshade.novalidate.nowrap.open.optimum.part.pattern.placeholder.playsinline.popover.popovertarget.popovertargetaction.poster.preload.pubdate.radiogroup.readonly.rel.required.rev.reversed.role.rows.rowspan.spellcheck.scope.selected.shape.size.sizes.slot.span.srclang.start.src.srcset.step.style.summary.tabindex.title.translate.type.usemap.valign.value.width.wrap.xmlns".split(".")), Se = d(/* @__PURE__ */ "accent-height.accumulate.additive.alignment-baseline.amplitude.ascent.attributename.attributetype.azimuth.basefrequency.baseline-shift.begin.bias.by.class.clip.clippathunits.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.cx.cy.d.dx.dy.diffuseconstant.direction.display.divisor.dominant-baseline.dur.edgemode.elevation.end.exponent.fill.fill-opacity.fill-rule.filter.filterunits.flood-color.flood-opacity.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.fx.fy.g1.g2.glyph-name.glyphref.gradientunits.gradienttransform.height.href.id.image-rendering.in.in2.intercept.k.k1.k2.k3.k4.kerning.keypoints.keysplines.keytimes.lang.lengthadjust.letter-spacing.kernelmatrix.kernelunitlength.lighting-color.local.marker-end.marker-mid.marker-start.markerheight.markerunits.markerwidth.maskcontentunits.maskunits.max.mask.mask-type.media.method.mode.min.name.numoctaves.offset.operator.opacity.order.orient.orientation.origin.overflow.paint-order.path.pathlength.patterncontentunits.patterntransform.patternunits.points.preservealpha.preserveaspectratio.primitiveunits.r.rx.ry.radius.refx.refy.repeatcount.repeatdur.restart.result.rotate.scale.seed.shape-rendering.slope.specularconstant.specularexponent.spreadmethod.startoffset.stddeviation.stitchtiles.stop-color.stop-opacity.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke.stroke-width.style.surfacescale.systemlanguage.tabindex.tablevalues.targetx.targety.transform.transform-origin.text-anchor.text-decoration.text-orientation.text-rendering.textlength.type.u1.u2.unicode.values.viewbox.visibility.version.vert-adv-y.vert-origin-x.vert-origin-y.width.word-spacing.wrap.writing-mode.xchannelselector.ychannelselector.x.x1.x2.xmlns.y.y1.y2.z.zoomandpan".split(".")), Ce = d(/* @__PURE__ */ "accent.accentunder.align.bevelled.close.columnalign.columnlines.columnspacing.columnspan.denomalign.depth.dir.display.displaystyle.encoding.fence.frame.height.href.id.largeop.length.linethickness.lquote.lspace.mathbackground.mathcolor.mathsize.mathvariant.maxsize.minsize.movablelimits.notation.numalign.open.rowalign.rowlines.rowspacing.rowspan.rspace.rquote.scriptlevel.scriptminsize.scriptsizemultiplier.selection.separator.separators.stretchy.subscriptshift.supscriptshift.symmetric.voffset.width.xmlns".split(".")), we = d([
	"xlink:href",
	"xml:id",
	"xlink:title",
	"xml:space",
	"xmlns:xlink"
]), Te = f(/{{[\w\W]*|^[\w\W]*}}/g), Ee = f(/<%[\w\W]*|^[\w\W]*%>/g), De = f(/\${[\w\W]*/g), Oe = f(/^data-[\-\w.\u00B7-\uFFFF]+$/), ke = f(/^aria-[\-\w]+$/), Ae = f(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i), je = f(/^(?:\w+script|data):/i), Me = f(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g), Ne = f(/^html$/i), Pe = f(/^[a-z][.\w]*(-[.\w]+)+$/i), Fe = f(/<[/\w!]/g), Ie = f(/<[/\w]/g), Le = f(/<\/no(script|embed|frames)/i), Re = f(/\/>/i), j = {
	element: 1,
	attribute: 2,
	text: 3,
	cdataSection: 4,
	entityReference: 5,
	entityNode: 6,
	processingInstruction: 7,
	comment: 8,
	document: 9,
	documentType: 10,
	documentFragment: 11,
	notation: 12
}, ze = function() {
	return typeof window > "u" ? null : window;
}, Be = function(e, t) {
	if (typeof e != "object" || typeof e.createPolicy != "function") return null;
	let n = null, r = "data-tt-policy-suffix";
	t && t.hasAttribute(r) && (n = t.getAttribute(r));
	let i = "dompurify" + (n ? "#" + n : "");
	try {
		return e.createPolicy(i, {
			createHTML(e) {
				return e;
			},
			createScriptURL(e) {
				return e;
			}
		});
	} catch {
		return console.warn("TrustedTypes policy " + i + " could not be created."), null;
	}
}, Ve = function() {
	return {
		afterSanitizeAttributes: [],
		afterSanitizeElements: [],
		afterSanitizeShadowDOM: [],
		beforeSanitizeAttributes: [],
		beforeSanitizeElements: [],
		beforeSanitizeShadowDOM: [],
		uponSanitizeAttribute: [],
		uponSanitizeElement: [],
		uponSanitizeShadowNode: []
	};
}, M = function(e, t, n, r) {
	return x(e, t) && v(e[t]) ? D(r.base ? k(r.base) : {}, e[t], r.transform) : n;
};
function He() {
	let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ze(), t = (e) => He(e);
	if (t.version = "3.4.13", t.removed = [], !e || !e.document || e.document.nodeType !== j.document || !e.Element) return t.isSupported = !1, t;
	let n = e.document, r = n, i = r.currentScript;
	e.DocumentFragment;
	let a = e.HTMLTemplateElement, s = e.Node, c = e.Element, l = e.NodeFilter;
	e.NamedNodeMap === void 0 && (e.NamedNodeMap || e.MozNamedAttrMap), e.HTMLFormElement;
	let u = e.DOMParser, m = e.trustedTypes, h = c.prototype, ee = A(h, "cloneNode"), ue = A(h, "remove"), de = A(h, "nextSibling"), y = A(h, "childNodes"), b = A(h, "parentNode"), S = A(h, "shadowRoot"), T = A(h, "attributes"), E = s && s.prototype ? A(s.prototype, "nodeType") : null, O = s && s.prototype ? A(s.prototype, "nodeName") : null, Ue = s && s.prototype ? A(s.prototype, "ownerDocument") : null;
	if (typeof a == "function") {
		let e = n.createElement("template");
		e.content && e.content.ownerDocument && (n = e.content.ownerDocument);
	}
	let N, P = "", We, Ge = !1, Ke = 0, qe = function() {
		if (Ke > 0) throw w("A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the \"DOMPurify and Trusted Types\" section of the README.");
	}, F = function(e) {
		qe(), Ke++;
		try {
			return N.createHTML(e);
		} finally {
			Ke--;
		}
	}, Je = function(e) {
		qe(), Ke++;
		try {
			return N.createScriptURL(e);
		} finally {
			Ke--;
		}
	}, Ye = function() {
		return Ge ||= (We = Be(m, i), !0), We;
	}, Xe = n, Ze = Xe.implementation, Qe = Xe.createNodeIterator, $e = Xe.createDocumentFragment, et = Xe.getElementsByTagName, tt = r.importNode, I = Ve();
	t.isSupported = typeof o == "function" && typeof b == "function" && Ze && Ze.createHTMLDocument !== void 0;
	let nt = Te, rt = Ee, it = De, at = Oe, ot = ke, st = je, ct = Me, lt = Pe, ut = Ae, L = null, dt = D({}, [
		...me,
		...he,
		...ge,
		...ve,
		...be
	]), R = null, ft = D({}, [
		...xe,
		...Se,
		...Ce,
		...we
	]), z = Object.seal(p(null, {
		tagNameCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		attributeNameCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		allowCustomizedBuiltInElements: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: !1
		}
	})), pt = null, mt = null, B = Object.seal(p(null, {
		tagCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		attributeCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		}
	})), ht = !0, gt = !0, _t = !1, vt = !0, V = !1, H = !0, U = !1, yt = !1, bt = null, xt = null, St = !1, W = !1, Ct = !1, wt = !1, Tt = !0, Et = !1, Dt = "user-content-", Ot = !0, kt = !1, G = {}, K = null, At = D({}, /* @__PURE__ */ "annotation-xml.audio.colgroup.desc.foreignobject.head.iframe.math.mi.mn.mo.ms.mtext.noembed.noframes.noscript.plaintext.script.selectedcontent.style.svg.template.thead.title.video.xmp".split(".")), jt = null, Mt = D({}, [
		"audio",
		"video",
		"img",
		"source",
		"image",
		"track"
	]), Nt = null, Pt = D({}, [
		"alt",
		"class",
		"for",
		"id",
		"label",
		"name",
		"pattern",
		"placeholder",
		"role",
		"summary",
		"title",
		"value",
		"style",
		"xmlns"
	]), Ft = "http://www.w3.org/1998/Math/MathML", It = "http://www.w3.org/2000/svg", q = "http://www.w3.org/1999/xhtml", J = q, Lt = !1, Rt = null, zt = D({}, [
		Ft,
		It,
		q
	], ae), Bt = d([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	]), Vt = D({}, Bt), Ht = d(["annotation-xml"]), Ut = D({}, Ht), Wt = D({}, [
		"title",
		"style",
		"font",
		"a",
		"script"
	]), Gt = null, Kt = ["application/xhtml+xml", "text/html"], Y = null, X = null, qt = n.createElement("form"), Jt = function(e) {
		return e instanceof RegExp || e instanceof Function;
	}, Yt = function() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		if (X && X === e) return;
		(!e || typeof e != "object") && (e = {}), e = k(e), Gt = Kt.indexOf(e.PARSER_MEDIA_TYPE) === -1 ? "text/html" : e.PARSER_MEDIA_TYPE, Y = Gt === "application/xhtml+xml" ? ae : ie, L = M(e, "ALLOWED_TAGS", dt, { transform: Y }), R = M(e, "ALLOWED_ATTR", ft, { transform: Y }), Rt = M(e, "ALLOWED_NAMESPACES", zt, { transform: ae }), Nt = M(e, "ADD_URI_SAFE_ATTR", Pt, {
			transform: Y,
			base: Pt
		}), jt = M(e, "ADD_DATA_URI_TAGS", Mt, {
			transform: Y,
			base: Mt
		}), K = M(e, "FORBID_CONTENTS", At, { transform: Y }), pt = M(e, "FORBID_TAGS", k({}), { transform: Y }), mt = M(e, "FORBID_ATTR", k({}), { transform: Y }), G = x(e, "USE_PROFILES") ? e.USE_PROFILES && typeof e.USE_PROFILES == "object" ? k(e.USE_PROFILES) : e.USE_PROFILES : !1, ht = e.ALLOW_ARIA_ATTR !== !1, gt = e.ALLOW_DATA_ATTR !== !1, _t = e.ALLOW_UNKNOWN_PROTOCOLS || !1, vt = e.ALLOW_SELF_CLOSE_IN_ATTR !== !1, V = e.SAFE_FOR_TEMPLATES || !1, H = e.SAFE_FOR_XML !== !1, U = e.WHOLE_DOCUMENT || !1, W = e.RETURN_DOM || !1, Ct = e.RETURN_DOM_FRAGMENT || !1, wt = e.RETURN_TRUSTED_TYPE || !1, St = e.FORCE_BODY || !1, Tt = e.SANITIZE_DOM !== !1, Et = e.SANITIZE_NAMED_PROPS || !1, Ot = e.KEEP_CONTENT !== !1, kt = e.IN_PLACE || !1, ut = pe(e.ALLOWED_URI_REGEXP) ? e.ALLOWED_URI_REGEXP : Ae, J = typeof e.NAMESPACE == "string" ? e.NAMESPACE : q, Vt = x(e, "MATHML_TEXT_INTEGRATION_POINTS") && e.MATHML_TEXT_INTEGRATION_POINTS && typeof e.MATHML_TEXT_INTEGRATION_POINTS == "object" ? k(e.MATHML_TEXT_INTEGRATION_POINTS) : D({}, Bt), Ut = x(e, "HTML_INTEGRATION_POINTS") && e.HTML_INTEGRATION_POINTS && typeof e.HTML_INTEGRATION_POINTS == "object" ? k(e.HTML_INTEGRATION_POINTS) : D({}, Ht);
		let t = x(e, "CUSTOM_ELEMENT_HANDLING") && e.CUSTOM_ELEMENT_HANDLING && typeof e.CUSTOM_ELEMENT_HANDLING == "object" ? k(e.CUSTOM_ELEMENT_HANDLING) : p(null);
		if (z = p(null), x(t, "tagNameCheck") && Jt(t.tagNameCheck) && (z.tagNameCheck = t.tagNameCheck), x(t, "attributeNameCheck") && Jt(t.attributeNameCheck) && (z.attributeNameCheck = t.attributeNameCheck), x(t, "allowCustomizedBuiltInElements") && typeof t.allowCustomizedBuiltInElements == "boolean" && (z.allowCustomizedBuiltInElements = t.allowCustomizedBuiltInElements), f(z), V && (gt = !1), Ct && (W = !0), G && (L = D({}, be), R = p(null), G.html === !0 && (D(L, me), D(R, xe)), G.svg === !0 && (D(L, he), D(R, Se), D(R, we)), G.svgFilters === !0 && (D(L, ge), D(R, Se), D(R, we)), G.mathMl === !0 && (D(L, ve), D(R, Ce), D(R, we))), B.tagCheck = null, B.attributeCheck = null, x(e, "ADD_TAGS") && (typeof e.ADD_TAGS == "function" ? B.tagCheck = e.ADD_TAGS : v(e.ADD_TAGS) && (L === dt && (L = k(L)), D(L, e.ADD_TAGS, Y))), x(e, "ADD_ATTR") && (typeof e.ADD_ATTR == "function" ? B.attributeCheck = e.ADD_ATTR : v(e.ADD_ATTR) && (R === ft && (R = k(R)), D(R, e.ADD_ATTR, Y))), x(e, "ADD_URI_SAFE_ATTR") && v(e.ADD_URI_SAFE_ATTR) && D(Nt, e.ADD_URI_SAFE_ATTR, Y), x(e, "FORBID_CONTENTS") && v(e.FORBID_CONTENTS) && (K === At && (K = k(K)), D(K, e.FORBID_CONTENTS, Y)), x(e, "ADD_FORBID_CONTENTS") && v(e.ADD_FORBID_CONTENTS) && (K === At && (K = k(K)), D(K, e.ADD_FORBID_CONTENTS, Y)), Ot && (L["#text"] = !0), U && D(L, [
			"html",
			"head",
			"body"
		]), L.table && (D(L, ["tbody"]), delete pt.tbody), e.TRUSTED_TYPES_POLICY) {
			if (typeof e.TRUSTED_TYPES_POLICY.createHTML != "function") throw w("TRUSTED_TYPES_POLICY configuration option must provide a \"createHTML\" hook.");
			if (typeof e.TRUSTED_TYPES_POLICY.createScriptURL != "function") throw w("TRUSTED_TYPES_POLICY configuration option must provide a \"createScriptURL\" hook.");
			let t = N;
			N = e.TRUSTED_TYPES_POLICY;
			try {
				P = F("");
			} catch (e) {
				throw N = t, e;
			}
		} else e.TRUSTED_TYPES_POLICY === null ? (N = void 0, P = "") : (N === void 0 && (N = Ye()), N && typeof P == "string" && (P = F("")));
		d && d(e), X = e;
	}, Xt = D({}, [
		...he,
		...ge,
		..._e
	]), Zt = D({}, [...ve, ...ye]), Qt = function(e, t, n) {
		return t.namespaceURI === q ? e === "svg" : t.namespaceURI === Ft ? e === "svg" && (n === "annotation-xml" || Vt[n]) : !!Xt[e];
	}, $t = function(e, t, n) {
		return t.namespaceURI === q ? e === "math" : t.namespaceURI === It ? e === "math" && Ut[n] : !!Zt[e];
	}, en = function(e, t, n) {
		return t.namespaceURI === It && !Ut[n] || t.namespaceURI === Ft && !Vt[n] ? !1 : !Zt[e] && (Wt[e] || !Xt[e]);
	}, tn = function(e) {
		let t = b(e);
		(!t || !t.tagName) && (t = {
			namespaceURI: J,
			tagName: "template"
		});
		let n = ie(e.tagName), r = ie(t.tagName);
		return Rt[e.namespaceURI] ? e.namespaceURI === It ? Qt(n, t, r) : e.namespaceURI === Ft ? $t(n, t, r) : e.namespaceURI === q ? en(n, t, r) : !!(Gt === "application/xhtml+xml" && Rt[e.namespaceURI]) : !1;
	}, Z = function(e) {
		_(t.removed, { element: e });
		try {
			b(e).removeChild(e);
		} catch {
			if (ue(e), !b(e)) throw w("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
		}
	}, nn = function(e) {
		an(e);
		let t = y(e);
		if (t) {
			let e = [];
			g(t, (t) => {
				_(e, t);
			}), g(e, (e) => {
				try {
					ue(e);
				} catch {}
			});
		}
		let n = T(e);
		if (n) for (let t = n.length - 1; t >= 0; --t) {
			let r = n[t], i = r && r.name;
			if (typeof i == "string") try {
				e.removeAttribute(i);
			} catch {}
		}
	}, Q = function(e, n) {
		try {
			_(t.removed, {
				attribute: n.getAttributeNode(e),
				from: n
			});
		} catch {
			_(t.removed, {
				attribute: null,
				from: n
			});
		}
		if (n.removeAttribute(e), e === "is") if (W || Ct) try {
			Z(n);
		} catch {}
		else try {
			n.setAttribute(e, "");
		} catch {}
	}, rn = function(e) {
		let t = T(e);
		if (t) for (let n = t.length - 1; n >= 0; --n) {
			let r = t[n], i = r && r.name;
			if (!(typeof i != "string" || R[Y(i)])) try {
				e.removeAttribute(i);
			} catch {}
		}
	}, an = function(e) {
		let t = [e];
		for (; t.length > 0;) {
			let e = t.pop();
			(E ? E(e) : e.nodeType) === j.element && rn(e);
			let n = y(e);
			if (n) for (let e = n.length - 1; e >= 0; --e) t.push(n[e]);
		}
	}, on = function(e) {
		if (!H) return;
		let t = [e];
		for (; t.length > 0;) {
			let e = t.pop(), n = E ? E(e) : e.nodeType;
			if (n === j.processingInstruction || n === j.comment && C(Ie, e.data)) {
				try {
					ue(e);
				} catch {}
				continue;
			}
			if (n === j.element) {
				let t = e, n = Y(O ? O(e) : e.nodeName);
				try {
					t.hasAttribute && t.hasAttribute("patchsrc") && t.removeAttribute("patchsrc"), t.hasAttribute && t.hasAttribute("for") && n !== "label" && n !== "output" && t.removeAttribute("for");
				} catch {}
			}
			let r = y(e);
			if (r) for (let e = r.length - 1; e >= 0; --e) t.push(r[e]);
		}
	}, sn = function(e) {
		let t = null, r = null;
		if (St) e = "<remove></remove>" + e;
		else {
			let t = oe(e, /^[\r\n\t ]+/);
			r = t && t[0];
		}
		Gt === "application/xhtml+xml" && J === q && (e = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head></head><body>" + e + "</body></html>");
		let i = N ? F(e) : e;
		if (J === q) try {
			t = new u().parseFromString(i, Gt);
		} catch {}
		if (!t || !t.documentElement) {
			t = Ze.createDocument(J, "template", null);
			try {
				t.documentElement.innerHTML = Lt ? P : i;
			} catch {}
		}
		let a = t.body || t.documentElement;
		return e && r && a.insertBefore(n.createTextNode(r), a.childNodes[0] || null), J === q ? et.call(t, U ? "html" : "body")[0] : U ? t.documentElement : a;
	}, cn = function(e) {
		let t = Ue ? Ue(e) : e.ownerDocument;
		return Qe.call(t || e, e, l.SHOW_ELEMENT | l.SHOW_COMMENT | l.SHOW_TEXT | l.SHOW_PROCESSING_INSTRUCTION | l.SHOW_CDATA_SECTION, null);
	}, ln = function(e) {
		return e = se(e, nt, " "), e = se(e, rt, " "), e = se(e, it, " "), e;
	}, un = function(e) {
		e.normalize();
		let t = Ue ? Ue(e) : e.ownerDocument, n = Qe.call(t || e, e, l.SHOW_TEXT | l.SHOW_COMMENT | l.SHOW_CDATA_SECTION | l.SHOW_PROCESSING_INSTRUCTION, null), r = n.nextNode();
		for (; r;) r.data = ln(r.data), r = n.nextNode();
		let i = e.querySelectorAll?.call(e, "template");
		i && g(i, (e) => {
			fn(e.content) && un(e.content);
		});
	}, dn = function(e) {
		let t = O ? O(e) : null;
		return typeof t != "string" || Y(t) !== "form" ? !1 : typeof e.nodeName != "string" || typeof e.textContent != "string" || typeof e.removeChild != "function" || e.attributes !== T(e) || typeof e.removeAttribute != "function" || typeof e.setAttribute != "function" || typeof e.namespaceURI != "string" || typeof e.insertBefore != "function" || typeof e.hasChildNodes != "function" || e.nodeType !== E(e) || e.childNodes !== y(e);
	}, fn = function(e) {
		if (!E || typeof e != "object" || !e) return !1;
		try {
			return E(e) === j.documentFragment;
		} catch {
			return !1;
		}
	}, pn = function(e) {
		if (!E || typeof e != "object" || !e) return !1;
		try {
			return typeof E(e) == "number";
		} catch {
			return !1;
		}
	};
	function $(e, n, r) {
		e.length !== 0 && g(e, (e) => {
			e.call(t, n, r, X);
		});
	}
	let mn = function(e, t) {
		return !!(H && e.hasChildNodes() && !pn(e.firstElementChild) && C(Fe, e.textContent) && C(Fe, e.innerHTML) || H && e.namespaceURI === q && t === "style" && pn(e.firstElementChild) || e.nodeType === j.processingInstruction || H && e.nodeType === j.comment && C(Ie, e.data));
	}, hn = function(e, t, n) {
		if (!pt[t] && bn(t) && (z.tagNameCheck instanceof RegExp && C(z.tagNameCheck, t) || z.tagNameCheck instanceof Function && z.tagNameCheck(t))) return !1;
		if (Ot && !K[t]) {
			let t = b(e), r = y(e);
			if (r && t) {
				let i = r.length;
				for (let a = i - 1; a >= 0; --a) {
					let i = e === n ? ee(r[a], !0) : r[a];
					t.insertBefore(i, de(e));
				}
			}
		}
		return Z(e), !0;
	}, gn = function(e, t, n, r) {
		return e.length === 0 ? t : t === n || t === r ? k(t) : t;
	}, _n = function(e, n) {
		if ($(I.beforeSanitizeElements, e, null), e !== n && b(e) === null) return kt && an(e), !0;
		if (dn(e)) return Z(e), !0;
		let r = Y(O ? O(e) : e.nodeName);
		if (L = gn(I.uponSanitizeElement, L, dt, bt), $(I.uponSanitizeElement, e, {
			tagName: r,
			allowedTags: L
		}), e !== n && b(e) === null) return kt && an(e), !0;
		if (mn(e, r)) return Z(e), !0;
		if (pt[r] || !(B.tagCheck instanceof Function && B.tagCheck(r)) && !L[r]) {
			let t = hn(e, r, n);
			return t === !1 && $(I.afterSanitizeElements, e, null), t;
		}
		if ((E ? E(e) : e.nodeType) === j.element && !tn(e) || (r === "noscript" || r === "noembed" || r === "noframes") && C(Le, e.innerHTML)) return Z(e), !0;
		if (V && e.nodeType === j.text) {
			let n = ln(e.textContent);
			e.textContent !== n && (_(t.removed, { element: e.cloneNode() }), e.textContent = n);
		}
		return $(I.afterSanitizeElements, e, null), !1;
	}, vn = function(e, t, r) {
		if (mt[t] || H && t === "patchsrc" || H && t === "for" && e !== "label" && e !== "output" || Tt && (t === "id" || t === "name") && (r in n || r in qt)) return !1;
		let i = R[t] || B.attributeCheck instanceof Function && B.attributeCheck(t, e);
		if (!(gt && C(at, t)) && !(ht && C(ot, t))) {
			if (!i) {
				if (!(bn(e) && (z.tagNameCheck instanceof RegExp && C(z.tagNameCheck, e) || z.tagNameCheck instanceof Function && z.tagNameCheck(e)) && (z.attributeNameCheck instanceof RegExp && C(z.attributeNameCheck, t) || z.attributeNameCheck instanceof Function && z.attributeNameCheck(t, e)) || t === "is" && z.allowCustomizedBuiltInElements && (z.tagNameCheck instanceof RegExp && C(z.tagNameCheck, r) || z.tagNameCheck instanceof Function && z.tagNameCheck(r)))) return !1;
			} else if (!Nt[t] && !C(ut, se(r, ct, "")) && !((t === "src" || t === "xlink:href" || t === "href") && e !== "script" && ce(r, "data:") === 0 && jt[e]) && !(_t && !C(st, se(r, ct, ""))) && r) return !1;
		}
		return !0;
	}, yn = D({}, [
		"annotation-xml",
		"color-profile",
		"font-face",
		"font-face-format",
		"font-face-name",
		"font-face-src",
		"font-face-uri",
		"missing-glyph"
	]), bn = function(e) {
		return !yn[ie(e)] && C(lt, e);
	}, xn = function(e, t, n, r) {
		if (N && typeof m == "object" && typeof m.getAttributeType == "function" && !n) switch (m.getAttributeType(e, t)) {
			case "TrustedHTML": return F(r);
			case "TrustedScriptURL": return Je(r);
		}
		return r;
	}, Sn = function(e, n, r, i) {
		try {
			r ? e.setAttributeNS(r, n, i) : e.setAttribute(n, i), dn(e) ? Z(e) : ne(t.removed);
		} catch {
			Q(n, e);
		}
	}, Cn = function(e) {
		$(I.beforeSanitizeAttributes, e, null);
		let t = e.attributes;
		if (!t || dn(e)) return;
		R = gn(I.uponSanitizeAttribute, R, ft, xt);
		let n = {
			attrName: "",
			attrValue: "",
			keepAttr: !0,
			allowedAttributes: R,
			forceKeepAttr: void 0
		}, r = t.length, i = Y(e.nodeName);
		for (; r--;) {
			let a = t[r], o = a.name, s = a.namespaceURI, c = a.value, l = Y(o), u = c, d = o === "value" ? u : le(u);
			if (n.attrName = l, n.attrValue = d, n.keepAttr = !0, n.forceKeepAttr = void 0, $(I.uponSanitizeAttribute, e, n), d = n.attrValue, Et && (l === "id" || l === "name") && ce(d, Dt) !== 0 && (Q(o, e), d = Dt + d), H && C(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, d)) {
				Q(o, e);
				continue;
			}
			if (l === "attributename" && oe(d, "href")) {
				Q(o, e);
				continue;
			}
			if (!n.forceKeepAttr) {
				if (!n.keepAttr) {
					Q(o, e);
					continue;
				}
				if (!vt && C(Re, d)) {
					Q(o, e);
					continue;
				}
				if (V && (d = ln(d)), !vn(i, l, d)) {
					Q(o, e);
					continue;
				}
				d = xn(i, l, s, d), d !== u && Sn(e, o, s, d);
			}
		}
		$(I.afterSanitizeAttributes, e, null);
	}, wn = function(e) {
		let t = null, n = cn(e);
		for ($(I.beforeSanitizeShadowDOM, e, null); t = n.nextNode();) if ($(I.uponSanitizeShadowNode, t, null), _n(t, e), Cn(t), fn(t.content) && wn(t.content), (E ? E(t) : t.nodeType) === j.element) {
			let e = S(t);
			fn(e) && (Tn(e), wn(e));
		}
		$(I.afterSanitizeShadowDOM, e, null);
	}, Tn = function(e) {
		let t = [{
			node: e,
			shadow: null
		}];
		for (; t.length > 0;) {
			let e = t.pop();
			if (e.shadow) {
				wn(e.shadow);
				continue;
			}
			let n = e.node, r = (E ? E(n) : n.nodeType) === j.element, i = y(n);
			if (i) for (let e = i.length - 1; e >= 0; --e) t.push({
				node: i[e],
				shadow: null
			});
			if (r) {
				let e = O ? O(n) : null;
				if (typeof e == "string" && Y(e) === "template") {
					let e = n.content;
					fn(e) && t.push({
						node: e,
						shadow: null
					});
				}
			}
			if (r) {
				let e = S(n);
				fn(e) && t.push({
					node: null,
					shadow: e
				}, {
					node: e,
					shadow: null
				});
			}
		}
	};
	return t.sanitize = function(e) {
		let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = null, a = null, o = null, s = null;
		if (Lt = !e, Lt && (e = "<!-->"), typeof e != "string" && !pn(e) && (e = fe(e), typeof e != "string")) throw w("dirty is not a string, aborting");
		if (!t.isSupported) return e;
		yt ? (L = bt, R = xt) : Yt(n), (I.uponSanitizeElement.length > 0 || I.uponSanitizeAttribute.length > 0) && (L = k(L)), I.uponSanitizeAttribute.length > 0 && (R = k(R)), t.removed = [];
		let c = kt && typeof e != "string" && pn(e);
		if (c) {
			on(e);
			let t = O ? O(e) : e.nodeName;
			if (typeof t == "string") {
				let n = Y(t);
				if (!L[n] || pt[n]) throw nn(e), w("root node is forbidden and cannot be sanitized in-place");
			}
			if (dn(e)) throw nn(e), w("root node is clobbered and cannot be sanitized in-place");
			try {
				Tn(e);
			} catch (t) {
				throw nn(e), t;
			}
		} else if (pn(e)) i = sn("<!---->"), a = i.ownerDocument.importNode(e, !0), a.nodeType === j.element && a.nodeName === "BODY" || a.nodeName === "HTML" ? i = a : i.appendChild(a), Tn(a);
		else {
			if (!W && !V && !U && e.indexOf("<") === -1) return N && wt ? F(e) : e;
			if (i = sn(e), !i) return W ? null : wt ? P : "";
		}
		i && St && Z(i.firstChild);
		let l = c ? e : i;
		try {
			let e = cn(l);
			for (; o = e.nextNode();) _n(o, l), Cn(o), fn(o.content) && wn(o.content);
		} catch (n) {
			throw c && (nn(e), g(t.removed, (e) => {
				e.element && an(e.element);
			})), n;
		}
		if (c) return g(t.removed, (e) => {
			e.element && an(e.element);
		}), V && un(e), e;
		if (W) {
			if (V && un(i), Ct) for (s = $e.call(i.ownerDocument); i.firstChild;) s.appendChild(i.firstChild);
			else s = i;
			return (R.shadowroot || R.shadowrootmode) && (s = tt.call(r, s, !0)), s;
		}
		let u = U ? i.outerHTML : i.innerHTML;
		return U && L["!doctype"] && i.ownerDocument && i.ownerDocument.doctype && i.ownerDocument.doctype.name && C(Ne, i.ownerDocument.doctype.name) && (u = "<!DOCTYPE " + i.ownerDocument.doctype.name + ">\n" + u), V && (u = ln(u)), N && wt ? F(u) : u;
	}, t.setConfig = function() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		Yt(e), yt = !0, bt = L, xt = R;
	}, t.clearConfig = function() {
		X = null, yt = !1, bt = null, xt = null, N = We, P = "";
	}, t.isValidAttribute = function(e, t, n) {
		X || Yt({});
		let r = Y(e), i = Y(t);
		return vn(r, i, n);
	}, t.addHook = function(e, t) {
		typeof t == "function" && x(I, e) && _(I[e], t);
	}, t.removeHook = function(e, t) {
		if (x(I, e)) {
			if (t !== void 0) {
				let n = te(I[e], t);
				return n === -1 ? void 0 : re(I[e], n, 1)[0];
			}
			return ne(I[e]);
		}
	}, t.removeHooks = function(e) {
		x(I, e) && (I[e] = []);
	}, t.removeAllHooks = function() {
		I = Ve();
	}, t;
}
var Ue = He();
//#endregion
export { Ue as default };
